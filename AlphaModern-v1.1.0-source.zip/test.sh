#!/bin/sh
set -eu
cd "$(dirname "$0")"
sh build.sh
mkdir -p build/test-classes
javac -source 8 -target 8 -cp build/classes -d build/test-classes tests/alphamodern/*.java
java -cp build/classes:build/test-classes alphamodern.WorldLightSafetyTest "${ALPHA_JAR:-/mnt/data/minecraft-a1.0.15-client.jar}"
java -cp build/classes:build/test-classes alphamodern.TerrainRegressionTest
java -cp build/classes:build/test-classes alphamodern.ViewportTest
java -cp build/classes:build/test-classes alphamodern.CrashAndCompatibilityTest "${ALPHA_JAR:-}"
java -cp build/classes:build/test-classes alphamodern.TextComponentTest
java -cp build/classes:build/test-classes alphamodern.BridgeIntegrationTest
java -cp build/classes:build/test-classes alphamodern.TallWorldIntegrationTest
java -cp build/classes:build/test-classes alphamodern.AuthIntegrationTest
java -cp build/classes:build/test-classes alphamodern.SwitchAuthTest
java -cp build/classes:build/test-classes alphamodern.AuthOverlayTest
java -cp build/classes:build/test-classes alphamodern.AzureRegistrationTest

java -cp build/classes:build/test-classes alphamodern.EntityAndStatesTest

java -cp build/classes:build/test-classes alphamodern.RemotePredictionPatchTest "${ALPHA_JAR:-/mnt/data/minecraft-a1.0.15-client.jar}"
java -cp build/classes:build/test-classes alphamodern.ServerBlocksAuthorityTest
java -cp build/classes:build/test-classes alphamodern.BlockPacketIntegrationTest
java -cp build/classes:build/test-classes alphamodern.SpawnSafetyIntegrationTest "${ALPHA_JAR:-/mnt/data/minecraft-a1.0.15-client.jar}"

java -cp build/classes:build/test-classes alphamodern.InventoryBridgeTest "${ALPHA_JAR:-/mnt/data/minecraft-a1.0.15-client.jar}"

# Full JVM access check, not merely loading the transformed Minecraft class.
mkdir -p build/test-classes
javac -source 8 -target 8 -cp build/classes -d build/test-classes tests/external/InventoryAccessTest.java
java -Xverify:all -cp build/classes:build/test-classes external.InventoryAccessTest

java -Xverify:all -cp build/classes:build/test-classes alphamodern.TransferAndUiTest "${ALPHA_JAR:-/mnt/data/minecraft-a1.0.15-client.jar}"

java -Xverify:all -cp build/classes:build/test-classes alphamodern.SprintIntegrationTest "${ALPHA_JAR:-/mnt/data/minecraft-a1.0.15-client.jar}"
