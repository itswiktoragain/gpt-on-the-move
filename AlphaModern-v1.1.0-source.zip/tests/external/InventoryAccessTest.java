package external;

import alphamodern.InventoryMirror;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

/** Reproduces the cross-package INVOKESTATIC that crashed Alpha 1.0.15. */
public final class InventoryAccessTest {
    public static void main(String[] args) throws Exception {
        if (!Modifier.isPublic(InventoryMirror.class.getModifiers()))
            throw new AssertionError("InventoryMirror is not public");
        Method bind = InventoryMirror.class.getMethod("bind", Object.class);
        if (!Modifier.isPublic(bind.getModifiers()) || !Modifier.isStatic(bind.getModifiers()))
            throw new AssertionError("InventoryMirror.bind is not public static");
        Method click = InventoryMirror.class.getMethod("click", Object.class,int.class,int.class,int.class);
        if (!Modifier.isPublic(click.getModifiers()) || !Modifier.isStatic(click.getModifiers()))
            throw new AssertionError("InventoryMirror.click is not public static");

        // These calls compile to INVOKESTATIC from an unrelated package.
        // Java 8 runtime access checking previously threw IllegalAccessError here.
        InventoryMirror.bind(null);
        InventoryMirror.click(null, 0, 0, 0);
        System.out.println("PASS: cross-package public inventory hook INVOKESTATIC and JVM access checks");
    }
}
