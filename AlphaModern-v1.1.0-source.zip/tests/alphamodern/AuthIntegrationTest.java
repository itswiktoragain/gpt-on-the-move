package alphamodern;

import com.sun.net.httpserver.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermission;
import java.security.*;
import java.security.spec.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import javax.crypto.*;
import javax.crypto.spec.*;

public class AuthIntegrationTest {
    static final String APP="321f7654-0a99-4d0e-a99d-05bce8d9d7f1";
    static final String UUID_STRING="12345678-90ab-cdef-1234-567890abcdef";
    static final String NON_DASHED="1234567890abcdef1234567890abcdef";
    static final AtomicInteger deviceCalls=new AtomicInteger(),tokenCalls=new AtomicInteger(),joinCalls=new AtomicInteger(),refreshCalls=new AtomicInteger();
    static volatile String observedCode="";
    static final AtomicReference<Throwable> serverError=new AtomicReference<Throwable>();
    static void expect(boolean ok,String message){if(!ok)throw new AssertionError(message);}
    static void respond(HttpExchange x,int status,String body) throws IOException {
        byte[] bytes=body.getBytes(StandardCharsets.UTF_8);
        x.getResponseHeaders().set("Content-Type","application/json");
        if(status==204){x.sendResponseHeaders(204,-1);x.close();return;}
        x.sendResponseHeaders(status,bytes.length);
        try(OutputStream o=x.getResponseBody()){o.write(bytes);}
    }
    static String body(HttpExchange x) throws IOException {return new String(AlphaModernAgent.readAll(x.getRequestBody()),StandardCharsets.UTF_8);}
    static HttpServer fakeAccounts() throws Exception {
        HttpServer h=HttpServer.create(new InetSocketAddress(InetAddress.getLoopbackAddress(),0),4);
        h.createContext("/devicecode",x->{
            deviceCalls.incrementAndGet();String request=body(x);
            expect(request.contains("client_id="),"Missing app identifier in device request");
            expect(!request.contains("test%40example.com")&&!request.contains("test@example.com"),"Email leaked into device-code request");
            respond(x,200,"{\"device_code\":\"mock-device-secret\",\"user_code\":\"ABCD-EFGH\",\"verification_uri\":\"https://microsoft.com/devicelogin\",\"expires_in\":90,\"interval\":1}");
        });
        h.createContext("/token",x->{
            String b=body(x);tokenCalls.incrementAndGet();
            if(b.contains("grant_type=refresh_token")){
                refreshCalls.incrementAndGet();expect(b.contains("refresh_token=REFRESH_ONE"),"Wrong original refresh token");
                respond(x,200,"{\"access_token\":\"MS_ACCESS_REFRESHED\",\"refresh_token\":\"REFRESH_TWO\",\"expires_in\":3600}");
            }else{
                expect(b.contains("device_code=mock-device-secret"),"Missing device code");
                AuthOverlay.State state=AuthOverlay.state;
                if(state!=null&&"ABCD-EFGH".equals(state.code))observedCode=state.code;
                if(tokenCalls.get()==1)respond(x,400,"{\"error\":\"authorization_pending\"}");
                else respond(x,200,"{\"access_token\":\"MS_ACCESS_ONE\",\"refresh_token\":\"REFRESH_ONE\",\"expires_in\":3600}");
            }
        });
        h.createContext("/xbox",x->{
            String b=body(x);expect(b.contains("RpsTicket")&&b.contains("d=MS_ACCESS"),"Xbox request missing Microsoft access ticket");
            respond(x,200,"{\"Token\":\"XBOX_TICKET\"}");
        });
        h.createContext("/xsts",x->{
            String b=body(x);expect(b.contains("XBOX_TICKET"),"Wrong Xbox ticket");
            respond(x,200,"{\"Token\":\"XSTS_TICKET\",\"DisplayClaims\":{\"xui\":[{\"uhs\":\"12345\"}]}}");
        });
        h.createContext("/minecraft",x->{
            String b=body(x);expect(b.contains("XBL3.0 x=12345;XSTS_TICKET"),"Wrong Minecraft identityToken");
            respond(x,200,"{\"access_token\":\"MINECRAFT_ACCESS_TOKEN\",\"expires_in\":7200}");
        });
        h.createContext("/profile",x->{
            expect("Bearer MINECRAFT_ACCESS_TOKEN".equals(x.getRequestHeaders().getFirst("Authorization")),"Missing Minecraft bearer authorization");
            respond(x,200,"{\"name\":\"TestAccount\",\"id\":\""+NON_DASHED+"\"}");
        });
        h.createContext("/join",x->{
            String b=body(x);joinCalls.incrementAndGet();
            expect(b.contains("\"accessToken\":\"MINECRAFT_ACCESS_TOKEN\""),"Join request lacks real Java token");
            expect(b.contains("\"selectedProfile\":\""+NON_DASHED+"\""),"Join used wrong Java UUID");
            expect(b.contains("\"serverId\":"),"Missing online server digest");
            respond(x,204,"");
        });
        h.setExecutor(Executors.newCachedThreadPool(r->{Thread t=new Thread(r,"mock-auth");t.setDaemon(true);return t;}));
        h.start();return h;
    }
    static AuthManager.Endpoints urls(HttpServer server) {
        String b="http://localhost:"+server.getAddress().getPort();
        return new AuthManager.Endpoints(b+"/devicecode",b+"/token",b+"/xbox",b+"/xsts",b+"/minecraft",b+"/profile",b+"/join");
    }
    static void basicAuthTest(Path auth,AuthManager manager) throws Exception {
        expect(manager.peek()==null,"Unexpected saved credentials");
        AuthManager.Profile profile=manager.ensure(()->true);
        expect("ABCD-EFGH".equals(observedCode),"Verification code didn't appear on in-game overlay");
        expect(profile.name.equals("TestAccount"),"Wrong Minecraft Java name");
        expect(profile.uuid.equals(UUID_STRING),"Wrong Java UUID");
        expect(Files.exists(manager.path()),"Credentials were not persisted");
        expect(!new String(Files.readAllBytes(manager.path()),StandardCharsets.UTF_8).contains("MS_ACCESS_ONE"),"Microsoft access token incorrectly saved");
        expect(Files.readAllLines(manager.path()).toString().contains("REFRESH_ONE"),"Refresh token wasn't saved");
        try {
            Set<PosixFilePermission> perms=Files.getPosixFilePermissions(manager.path());
            expect(!perms.contains(PosixFilePermission.GROUP_READ)&&!perms.contains(PosixFilePermission.OTHERS_READ),"Secret cache is world-readable");
        }catch(UnsupportedOperationException ignored){}
        expect(tokenCalls.get()==2,"Expected one pending and one successful device-code poll");
        AuthManager.Profile cached=manager.ensure(()->true);
        expect(cached.valid()&&tokenCalls.get()==2,"Valid cached token was not reused");
        // Make the Minecraft access token expire; refresh should be silent with no new device code.
        Properties props=new Properties();
        try(InputStream in=Files.newInputStream(manager.path())){props.load(in);}
        props.setProperty("minecraftExpires","0");
        try(OutputStream out=Files.newOutputStream(manager.path())){props.store(out,"Forced expiry for test");}
        profile=manager.ensure(()->true);
        expect(profile.valid()&&refreshCalls.get()==1,"Background token refresh failed");
        expect(deviceCalls.get()==1,"Refreshing credentials incorrectly triggered a new device code");
        expect(Files.readAllLines(manager.path()).toString().contains("REFRESH_TWO"),"Rotated refresh token wasn't saved");
        System.out.println("PASS: Microsoft device code, in-game overlay state, pending/poll, Xbox/XSTS, Java profile, 0600 storage, cache, silent refresh");
    }
    static void loginHandshake(Wire net,String expectedName,String expectedUuid) throws Exception {
        Wire.Packet packet=net.recv();expect(packet.id==0,"Missing handshake");
        expect(Wire.var(packet.data)==776,"Incorrect protocol");
        Wire.str(packet.data);packet.data.readUnsignedShort();expect(Wire.var(packet.data)==2,"Wrong next state");
        packet=net.recv();expect(packet.id==0,"Missing login hello");
        String n=Wire.str(packet.data);expect(expectedName.equals(n),"Expected "+expectedName+" but got "+n);
        java.util.UUID u=new UUID(packet.data.readLong(),packet.data.readLong());
        expect(u.toString().equals(expectedUuid),"UUID mismatch: "+u);
    }
    static void modernServer(ServerSocket listener,boolean firstTime) {
        try {
            if(firstTime){
                // Unknown online mode: initial Alpha/offline hello gets an auth challenge.
                try(Socket first=listener.accept()){
                    first.setSoTimeout(15000);Wire preflight=new Wire(first);
                    UUID offline=UUID.nameUUIDFromBytes("OfflinePlayer:OldAlphaName".getBytes(StandardCharsets.UTF_8));
                    loginHandshake(preflight,"OldAlphaName",offline.toString());
                    KeyPairGenerator g=KeyPairGenerator.getInstance("RSA");g.initialize(1024);
                    byte[] key=g.generateKeyPair().getPublic().getEncoded();
                    preflight.send(1,o->{Wire.str(o,"");Wire.bytes(o,key);Wire.bytes(o,new byte[]{1,2,3});o.writeBoolean(true);});
                    Thread.sleep(500);
                }
            }
            // Cached or newly linked real Java profile gets used for the authenticated handshake.
            try(Socket s=listener.accept()) {
                s.setSoTimeout(15000);Wire modern=new Wire(s);
                loginHandshake(modern,"TestAccount",UUID_STRING);
                KeyPairGenerator gen=KeyPairGenerator.getInstance("RSA");gen.initialize(1024);KeyPair keys=gen.generateKeyPair();
                byte[] nonce={5,9,13,20};
                modern.send(1,o->{Wire.str(o,"");Wire.bytes(o,keys.getPublic().getEncoded());Wire.bytes(o,nonce);o.writeBoolean(true);});
                Wire.Packet p=modern.recv();expect(p.id==1,"Missing encrypted login response");
                byte[] encKey=Wire.bytes(p.data,2048),encNonce=Wire.bytes(p.data,2048);
                Cipher rsa=Cipher.getInstance("RSA/ECB/PKCS1Padding");rsa.init(Cipher.DECRYPT_MODE,keys.getPrivate());
                byte[] secret=rsa.doFinal(encKey);
                expect(Arrays.equals(nonce,rsa.doFinal(encNonce)),"Server verify token wasn't returned");
                modern.encrypt(new SecretKeySpec(secret,"AES"));
                modern.send(2,o->{Wire.uuid(o,UUID.fromString(UUID_STRING));Wire.str(o,"TestAccount");Wire.var(o,0);Wire.uuid(o,UUID.randomUUID());});
                boolean ack=false;
                for(int i=0;i<8&&!ack;i++){p=modern.recv();if(p.id==3)ack=true;}
                expect(ack,"No login acknowledgment after encrypted online-mode join");
                modern.send(14,o->Wire.var(o,0));
                boolean packs=false;
                for(int i=0;i<8&&!packs;i++){p=modern.recv();if(p.id==7)packs=true;}
                expect(packs,"Missing known packs response");
                modern.send(3,o->{});
                boolean config=false;
                for(int i=0;i<8&&!config;i++){p=modern.recv();if(p.id==3)config=true;}
                expect(config,"Missing configuration acknowledgment");
                modern.send(GameIds.CLIENTBOUND_LOGIN,o->{o.writeInt(404);o.writeBoolean(false);
                    Wire.var(o,1);Wire.str(o,"minecraft:overworld");Wire.var(o,20);Wire.var(o,8);Wire.var(o,6);
                    o.writeBoolean(false);o.writeBoolean(true);o.writeBoolean(false);Wire.var(o,0);Wire.str(o,"minecraft:overworld");
                });
                modern.send(GameIds.CLIENTBOUND_PLAYER_POSITION,o->{Wire.var(o,1);o.writeDouble(0);o.writeDouble(70);o.writeDouble(0);
                    o.writeDouble(0);o.writeDouble(0);o.writeDouble(0);o.writeFloat(0);o.writeFloat(0);o.writeInt(0);
                });
                // Modern sessions are not ready until the spawn chunk arrives.
                byte[] chunk=BridgeIntegrationTest.chunkData();
                modern.send(GameIds.CLIENTBOUND_LEVEL_CHUNK_WITH_LIGHT,o->{
                    o.writeInt(0);o.writeInt(0);Wire.var(o,0);Wire.var(o,chunk.length);o.write(chunk);
                });
                Thread.sleep(250);
            }
        }catch(Throwable t){serverError.set(t);}
    }
    static void simulatedAlpha(int port) throws Exception {
        try(Socket client=new BridgeSocket(InetAddress.getLoopbackAddress(),port)) {
            client.setSoTimeout(15000);
            DataOutputStream out=new DataOutputStream(client.getOutputStream());
            DataInputStream in=new DataInputStream(client.getInputStream());
            out.writeByte(1);out.writeInt(13);out.writeUTF("OldAlphaName");out.writeUTF("Password");out.flush();
            boolean login=false,position=false;
            for(int i=0;i<12&&!(login&&position);i++){
                int id=in.readUnsignedByte();
                if(id==1){expect(in.readInt()==404,"Incorrect online-mode entity");in.readUTF();in.readUTF();login=true;}
                else if(id==3){in.readUTF();}
                else if(id==13){in.readDouble();in.readDouble();in.readDouble();in.readDouble();in.readFloat();in.readFloat();in.readBoolean();position=true;}
                else if(id==50){in.readInt();in.readInt();in.readBoolean();}
                else if(id==51){in.readInt();in.readShort();in.readInt();in.readUnsignedByte();in.readUnsignedByte();in.readUnsignedByte();int len=in.readInt();byte[] b=new byte[len];in.readFully(b);}
                else if(id==255)throw new AssertionError("Online-mode login rejected: "+in.readUTF());
                else throw new AssertionError("Unrecognized Alpha packet "+id);
            }
            expect(login&&position,"Authenticated world login did not complete");
        }
    }
    public static void main(String[] args) throws Exception {
        System.setProperty("alpha.modern.noBrowser","true");
        AuthOverlay.setEmailForTests("test@example.com");
        Path temp=Files.createTempDirectory("alphamodern-auth-test");
        HttpServer service=fakeAccounts();
        AuthManager manager=new AuthManager(temp,APP,urls(service));
        AuthManager.setForTests(manager);
        try {
            basicAuthTest(temp,manager);
            ServerSocket listener=new ServerSocket(0,1,InetAddress.getLoopbackAddress());
            ExecutorService worker=Executors.newSingleThreadExecutor();
            Future<?> server=worker.submit(()->modernServer(listener,false));
            Gateway.start();
            simulatedAlpha(listener.getLocalPort());
            server.get(20,TimeUnit.SECONDS);
            expect(serverError.get()==null,"Mock modern online-mode server failed: "+serverError.get());
            expect(joinCalls.get()==1,"Expected one Mojang session join, got "+joinCalls.get());
            listener.close();
            System.out.println("PASS: cached-profile online-mode handshake, AES encryption and Minecraft session join");
            manager.logout();
            tokenCalls.set(0);
            observedCode="";
            serverError.set(null);
            ServerSocket firstTime=new ServerSocket(0,2,InetAddress.getLoopbackAddress());
            server=worker.submit(()->modernServer(firstTime,true));
            simulatedAlpha(firstTime.getLocalPort());
            server.get(20,TimeUnit.SECONDS);
            expect(serverError.get()==null,"First-time authenticated server failed: "+serverError.get());
            expect(joinCalls.get()==2,"First-time login did not join Mojang session");
            expect("ABCD-EFGH".equals(observedCode),"First-time in-game code was not displayed");
            expect(manager.peek()!=null&&manager.peek().valid(),"First-time login did not persist credentials");
            worker.shutdownNow();firstTime.close();
            System.out.println("PASS: first-time login triggers device code, relaunches modern handshake with actual Java UUID, and joins session");
            manager.logout();expect(manager.peek()==null,"Logout didn't delete credentials");
            System.out.println("PASS: credential logout and invalid-app configuration validation");
            System.out.println("ALL AUTHENTICATION TESTS PASSED");
        }finally {service.stop(0);AuthManager.setForTests(null);AuthOverlay.setEmailForTests(null);}
    }
}
