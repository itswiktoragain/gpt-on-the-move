package alphamodern;

import java.io.*;
import java.net.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

public final class SprintIntegrationTest {
    public static class InputParent { public float a,b;public boolean d; }
    public static class Input extends InputParent {}
    static void check(boolean ok,String why){if(!ok)throw new AssertionError(why);}
    static void field(Object o,String name,Object value)throws Exception {
        Field f=o.getClass().getDeclaredField(name);f.setAccessible(true);
        if(value instanceof Boolean)f.setBoolean(o,(Boolean)value);
        else if(value instanceof Integer)f.setInt(o,(Integer)value);
        else f.set(o,value);
    }
    private static void sprint()throws Exception{
        try(ServerSocket listen=new ServerSocket(0,1,InetAddress.getLoopbackAddress());
            Socket local=new Socket(InetAddress.getLoopbackAddress(),listen.getLocalPort());
            Socket remote=listen.accept()) {
            remote.setSoTimeout(4000);
            Gateway.Session s=new Gateway.Session(new DataInputStream(new ByteArrayInputStream(new byte[0])),
                new DataOutputStream(new ByteArrayOutputStream()),local,"Tester","localhost",25565);
            field(s,"playing",true);field(s,"spawnReady",true);field(s,"viewportReady",true);field(s,"localEntityId",142);
            SprintController.bind(s);
            Input i=new Input();
            i.b=1.0f;SprintController.update(i);
            check(!SprintController.isSprinting() && i.b==1.0f,"single tap must not sprint");
            i.b=0;SprintController.update(i);
            Thread.sleep(25);
            i.b=1;SprintController.update(i);
            check(SprintController.isSprinting(),"double tap should start sprint");
            check(Math.abs(i.b-1.3f)<0.01f,"sprint should increase Alpha's real forward input");
            Wire.Packet p=new Wire(remote).recv();
            check(p.id==GameIds.SERVERBOUND_PLAYER_COMMAND,"missing modern sprint start packet");
            check(Wire.var(p.data)==142&&Wire.var(p.data)==1&&Wire.var(p.data)==0,"sprint action fields invalid");
            SprintController.sendInputIfChanged(s);
            p=new Wire(remote).recv();check(p.id==GameIds.SERVERBOUND_PLAYER_INPUT && (p.data.readUnsignedByte()&65)==65,"sprint input bits missing");
            i.b=0;SprintController.update(i);
            check(!SprintController.isSprinting(),"releasing W must stop sprinting");
            p=new Wire(remote).recv();check(p.id==GameIds.SERVERBOUND_PLAYER_COMMAND && Wire.var(p.data)==142 && Wire.var(p.data)==2,"missing stop sprint packet");
            SprintController.clear(s);s.close();
        }
    }
    private static void verify(String path)throws Exception {
        final Map<String,byte[]> transformed=new HashMap<String,byte[]>();
        try(ZipFile jar=new ZipFile(path)){
            for(String n:new String[]{"fu","lj"}){
                byte[] data;try(InputStream i=jar.getInputStream(jar.getEntry(n+".class"))){data=AlphaModernAgent.readAll(i);}
                transformed.put(n,ClientUiPatch.patch(data,n));
            }
        }
        try(URLClassLoader loader=new URLClassLoader(new URL[]{Paths.get(path).toUri().toURL()},SprintIntegrationTest.class.getClassLoader()){
            @Override protected Class<?> findClass(String name)throws ClassNotFoundException{
                byte[] code=transformed.get(name);
                if(code!=null)return defineClass(name,code,0,code.length);
                return super.findClass(name);
            }
        }) {
            Class<?> input=Class.forName("fu",false,loader),hud=Class.forName("lj",false,loader);
            check(input.getDeclaredMethod("a",Class.forName("dg",false,loader))!=null,"missing sprint input method");
            check(hud.getDeclaredMethod("a",float.class,boolean.class,int.class,int.class)!=null,"missing HUD method");
        }
    }
    public static void main(String[] args)throws Exception{
        verify(args.length>0?args[0]:"/mnt/data/minecraft-a1.0.15-client.jar");sprint();
        System.out.println("PASS: JVM verified Alpha HUD and input hooks; double-W sprint start/stop with 26.2 action+input packets");
    }
}
