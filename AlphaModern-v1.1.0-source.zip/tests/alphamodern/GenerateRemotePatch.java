package alphamodern;
import java.io.*;
import java.util.zip.*;
public final class GenerateRemotePatch {
 public static void main(String[] a)throws Exception {
  try(ZipFile zip=new ZipFile(a[0]);InputStream in=zip.getInputStream(zip.getEntry("gj.class"));OutputStream out=new FileOutputStream(a[1])){
   out.write(RemoteWorldPatch.patch(AlphaModernAgent.readAll(in)));
  }
 }
}
