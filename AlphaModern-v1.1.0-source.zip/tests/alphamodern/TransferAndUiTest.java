package alphamodern;

import java.io.*;
import java.net.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.zip.*;

/** Local protocol test for transfer intent/cookie lifecycle and Java 5 hooks. */
public final class TransferAndUiTest {
    static void ok(boolean b,String msg){if(!b)throw new AssertionError(msg);}
    static byte[] payload(Wire.Writer writer)throws IOException{
        ByteArrayOutputStream b=new ByteArrayOutputStream();DataOutputStream o=new DataOutputStream(b);writer.write(o);o.flush();return b.toByteArray();
    }
    static void handshake(Wire remote,int intent)throws IOException{
        Wire.Packet p=remote.recv();ok(p.id==0,"missing handshake");ok(Wire.var(p.data)==776,"protocol mismatch");
        ok(!Wire.str(p.data).isEmpty(),"host missing");p.data.readUnsignedShort();ok(Wire.var(p.data)==intent,"transfer vs login intent wrong");
        p=remote.recv();ok(p.id==0,"login start missing");Wire.str(p.data);p.data.readLong();p.data.readLong();
    }
    static void acceptedLogin(Wire remote)throws IOException{
        remote.send(2,o->{Wire.uuid(o,UUID.randomUUID());Wire.str(o,"Tester");Wire.var(o,0);Wire.uuid(o,UUID.randomUUID());});
        for(int j=0;j<12;j++){if(remote.recv().id==3)return;}
        throw new IOException("No login acknowledgement");
    }
    static void registerTest()throws Exception{
        PluginChannels plugins=new PluginChannels();
        byte[] data=payload(o->{Wire.str(o,"minecraft:brand");Wire.str(o,"Velocity-Test");});
        plugins.received(new DataInputStream(new ByteArrayInputStream(data)));
        ok("Velocity-Test".equals(plugins.brand()),"server brand ignored");
        plugins.received(new DataInputStream(new ByteArrayInputStream(payload(o->{Wire.str(o,"example:optional");o.write(new byte[]{1,2,3});}))));
        ok(plugins.count()==2,"optional plugin messages not counted");
        plugins.received(new DataInputStream(new ByteArrayInputStream(payload(o->{Wire.str(o,"BungeeCord");o.writeByte(0x01);})))) ;
        ok(plugins.count()==3,"legacy BungeeCord custom payload must not crash");
        byte[] register=plugins.registrationPayload();ok(register.length==0,"must never claim unsupported plugin channel");
        System.setProperty("alpha.modern.pluginChannels","example:test,bad-channel");
        ok("example:test".equals(new String(plugins.registrationPayload(),"UTF-8")),"plugin registration validation broken");
        System.clearProperty("alpha.modern.pluginChannels");
        HudOverlay.title("Server Title");HudOverlay.subtitle("Server Subtitle");HudOverlay.actionBar("Next level");
        Field f=HudOverlay.class.getDeclaredField("subtitle");f.setAccessible(true);ok("Server Subtitle".equals(f.get(null)),"subtitle state missing");
        HudOverlay.clear();ok("".equals(f.get(null)),"title cleanup missing");
    }
    static void patchedClasses(String gameJar)throws Exception{
        try(ZipFile z=new ZipFile(gameJar)){
            for(String cls:new String[]{"fu","lj"}){
                byte[] original;try(InputStream in=z.getInputStream(z.getEntry(cls+".class"))){original=AlphaModernAgent.readAll(in);}
                byte[] changed=ClientUiPatch.patch(original,cls);
                ok(changed.length>original.length,"no hook in "+cls);
                String data=new String(changed,"ISO-8859-1");
                ok(data.contains(cls.equals("fu")?"alphamodern/SprintController":"alphamodern/HudOverlay"),"wrong hook in "+cls);
            }
        }
    }
    static void firstServer(ServerSocket socket,int secondPort)throws Exception{
        try(Socket client=socket.accept()){
            client.setSoTimeout(10000);Wire wire=new Wire(client);handshake(wire,2);acceptedLogin(wire);
            boolean gotSettings=false,gotBrand=false;
            for(int i=0;i<10&&!(gotSettings&&gotBrand);i++){
                Wire.Packet p=wire.recv();
                if(p.id==0)gotSettings=true;
                if(p.id==2)gotBrand=true;
            }
            ok(gotSettings&&gotBrand,"initial configuration messages missing");
            wire.send(10,o->{Wire.str(o,"example:transfer");Wire.bytes(o,new byte[]{1,3,7});});
            wire.send(11,o->{Wire.str(o,"127.0.0.1");Wire.var(o,secondPort);});
            Thread.sleep(180);
        }
    }
    static void secondServer(ServerSocket socket)throws Exception{
        try(Socket client=socket.accept()){
            client.setSoTimeout(10000);Wire wire=new Wire(client);handshake(wire,3);acceptedLogin(wire);
            wire.send(0,o->Wire.str(o,"example:transfer"));
            boolean answered=false;
            for(int j=0;j<20&&!answered;j++){
                Wire.Packet p=wire.recv();
                if(p.id==1){ok("example:transfer".equals(Wire.str(p.data)),"cookie key lost");
                    ok(p.data.readBoolean(),"transfer cookie lost");ok(Arrays.equals(Wire.bytes(p.data,5120),new byte[]{1,3,7}),"transfer cookie bytes lost");answered=true;}
            }
            ok(answered,"no transfer cookie response");
            wire.send(3,o->{});
            boolean finished=false;for(int i=0;i<20&&!finished;i++)if(wire.recv().id==3)finished=true;
            ok(finished,"configuration ack missing after transfer");
            wire.send(GameIds.CLIENTBOUND_LOGIN,o->{o.writeInt(902);o.writeBoolean(false);
                Wire.var(o,1);Wire.str(o,"minecraft:overworld");Wire.var(o,20);Wire.var(o,8);Wire.var(o,6);
                o.writeBoolean(false);o.writeBoolean(true);o.writeBoolean(false);
                Wire.var(o,0);Wire.str(o,"minecraft:overworld");
            });
            wire.send(GameIds.CLIENTBOUND_PLAYER_POSITION,o->{Wire.var(o,3);o.writeDouble(5);o.writeDouble(70);o.writeDouble(8);
                o.writeDouble(0);o.writeDouble(0);o.writeDouble(0);o.writeFloat(0);o.writeFloat(0);o.writeInt(0);
            });
            byte[] chunk=BridgeIntegrationTest.chunkData();
            wire.send(GameIds.CLIENTBOUND_LEVEL_CHUNK_WITH_LIGHT,o->{o.writeInt(0);o.writeInt(0);Wire.var(o,0);Wire.var(o,chunk.length);o.write(chunk);});
            boolean loaded=false;
            for(int i=0;i<70&&!loaded;i++)if(wire.recv().id==GameIds.SERVERBOUND_PLAYER_LOADED)loaded=true;
            ok(loaded,"Player Loaded not transmitted after transferred spawn chunk");
        }
    }
    static void alphaClient(int firstPort)throws Exception{
        try(Socket a=new BridgeSocket(InetAddress.getLoopbackAddress(),firstPort)){
            a.setSoTimeout(10000);DataInputStream in=new DataInputStream(a.getInputStream());DataOutputStream out=new DataOutputStream(a.getOutputStream());
            out.writeByte(1);out.writeInt(13);out.writeUTF("Tester");out.writeUTF("");out.flush();
            boolean sawLogin=false,sawPosition=false;
            for(int j=0;j<16&&!(sawLogin&&sawPosition);j++){
                int id=in.readUnsignedByte();
                if(id==1){ok(in.readInt()==902,"first server incorrectly loaded into Alpha");in.readUTF();in.readUTF();sawLogin=true;}
                else if(id==3){in.readUTF();}
                else if(id==50){in.readInt();in.readInt();in.readBoolean();}
                else if(id==51){in.readInt();in.readShort();in.readInt();in.readUnsignedByte();in.readUnsignedByte();in.readUnsignedByte();int n=in.readInt();byte[] d=new byte[n];in.readFully(d);}
                else if(id==13){in.readDouble();in.readDouble();in.readDouble();in.readDouble();in.readFloat();in.readFloat();in.readBoolean();sawPosition=true;}
                else if(id==255)throw new AssertionError("Server rejected transfer: "+in.readUTF());
                else throw new AssertionError("Unexpected Alpha packet "+id);
            }
            ok(sawLogin&&sawPosition,"Transfer did not produce Alpha world");
            Thread.sleep(500); // allow bridge to flush Player Loaded before closing Alpha socket
        }
    }
    static void transfer()throws Exception{
        Gateway.start();
        try(ServerSocket first=new ServerSocket(0,1,InetAddress.getLoopbackAddress());
            ServerSocket second=new ServerSocket(0,1,InetAddress.getLoopbackAddress())){
            ExecutorService es=Executors.newFixedThreadPool(2);
            Future<?> f=es.submit(()->{try{firstServer(first,second.getLocalPort());}catch(Exception e){throw new RuntimeException(e);}});
            Future<?> g=es.submit(()->{try{secondServer(second);}catch(Exception e){throw new RuntimeException(e);}});
            try{alphaClient(first.getLocalPort());f.get(15,TimeUnit.SECONDS);g.get(15,TimeUnit.SECONDS);}finally{es.shutdownNow();}
        }
    }
    public static void main(String[] args)throws Exception{
        registerTest();patchedClasses(args.length>0?args[0]:"/mnt/data/minecraft-a1.0.15-client.jar");transfer();
        System.out.println("PASS: plugin channels, server title/subtitle state, Java 5 hooks and full modern login transfer with cookie");
    }
}
