package alphamodern;

import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

public final class InventoryBridgeTest {
    private static void ok(boolean value,String message) {if(!value)throw new AssertionError(message);}
    private static byte[] data(Wire.Writer write)throws IOException {
        ByteArrayOutputStream buf=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(buf);
        write.write(out);out.flush();return buf.toByteArray();
    }
    private static void stack(DataOutputStream out,int count,int id)throws IOException {
        Wire.var(out,count);if(count>0){Wire.var(out,id);Wire.var(out,0);Wire.var(out,0);}
    }
    private static void codec()throws Exception {
        InventoryMirror.Stack iron=InventoryMirror.readSlot(new DataInputStream(new ByteArrayInputStream(
            data(o->stack(o,5,1)))));
        ok(iron.count==5&&iron.alphaId==1,"simple modern item stack not decoded");
        ok(InventoryMirror.readSlot(new DataInputStream(new ByteArrayInputStream(data(o->stack(o,0,0)))))==null,"air not empty");
        ok(ItemMapping.toAlpha(999999)==1,"unknown item ID must be registered stone instead of crashing Alpha");
        ok(ItemMapping.toAlpha(1)==1,"stone mapping invalid");
        // A server lobby item can have a custom name, lore, model ID,
        // enchantments and a removed component. Decode them without shifting
        // the next inventory slot's packet offset.
        byte[] rich=data(out->{
            Wire.var(out,6);Wire.var(out,1);Wire.var(out,6);Wire.var(out,1);
            Wire.var(out,6);out.writeByte(8);out.writeUTF("Lobby");
            Wire.var(out,11);Wire.var(out,1);out.writeByte(8);out.writeUTF("Click to teleport");
            Wire.var(out,17);Wire.var(out,1);out.writeFloat(0.75f);
            Wire.var(out,0);Wire.var(out,0);Wire.var(out,1);out.writeInt(123);
            Wire.var(out,0);out.writeByte(0); // empty anonymous NBT
            Wire.var(out,1);Wire.var(out,64); // max_stack_size component
            Wire.var(out,13);Wire.var(out,1);Wire.var(out,23);Wire.var(out,3);
            Wire.var(out,9); // removed item_name component ID
            stack(out,12,1); // next item must remain correctly aligned
        });
        DataInputStream richIn=new DataInputStream(new ByteArrayInputStream(rich));
        InventoryMirror.Stack one=InventoryMirror.readSlot(richIn),two=InventoryMirror.readSlot(richIn);
        ok(one!=null&&one.count==6&&one.alphaId==1,"rich lobby item did not decode");
        ok(two!=null&&two.count==12&&two.alphaId==1,"component parser shifted next inventory slot");
        ok(richIn.available()==0,"component data left unread");


    }
    private static void packets()throws Exception {
        try(ServerSocket listener=new ServerSocket(0,1,InetAddress.getLoopbackAddress());
            Socket local=new Socket(InetAddress.getLoopbackAddress(),listener.getLocalPort());
            Socket peer=listener.accept()) {
            peer.setSoTimeout(2000);
            Gateway.Session s=new Gateway.Session(new DataInputStream(new ByteArrayInputStream(new byte[0])),
                new DataOutputStream(new ByteArrayOutputStream()),local,"Tester","127.0.0.1",25565);
            InventoryMirror mirror=new InventoryMirror(s);
            byte[] snapshot=data(out->{
                Wire.var(out,0);Wire.var(out,7);Wire.var(out,46);
                for(int i=0;i<46;i++)stack(out,i==36?32:0,i==36?1:0);
                stack(out,0,0);
            });
            mirror.full(new DataInputStream(new ByteArrayInputStream(snapshot)));
            ok(mirror.hasSnapshot()&&mirror.stateId()==7,"server snapshot not applied");
            ok(mirror.item(36).alphaId==1&&mirror.item(36).count==32,"hotbar slot 0 was not saved");
            mirror.one(new DataInputStream(new ByteArrayInputStream(data(out->{
                Wire.var(out,0);Wire.var(out,8);out.writeShort(36);stack(out,0,0);
            }))));
            ok(mirror.item(36)==null&&mirror.stateId()==8,"server failed to clear hotbar");
            mirror.direct(new DataInputStream(new ByteArrayInputStream(data(out->{Wire.var(out,0);stack(out,5,1);})))) ;
            ok(mirror.item(36)!=null&&mirror.item(36).count==5,"direct hotbar packet not translated");
            java.lang.reflect.Field playing=Gateway.Session.class.getDeclaredField("playing");
            playing.setAccessible(true);playing.setBoolean(s,true);
            s.sendInventoryClick(36,0,8);
            Wire.Packet click=new Wire(peer).recv();
            ok(click.id==GameIds.SERVERBOUND_CONTAINER_CLICK,"no serverbound inventory click");
            ok(Wire.var(click.data)==0&&Wire.var(click.data)==8,"window/state mismatch");
            ok(click.data.readShort()==36&&click.data.readByte()==0&&Wire.var(click.data)==0,"click slot/button mismatch");
            ok(Wire.var(click.data)==0&&!click.data.readBoolean(),"predicted slot hash is not empty");
            s.close();
        }
    }
    private static void bytecode(String jar)throws Exception {
        final Map<String,byte[]> modified=new HashMap<String,byte[]>();
        try(ZipFile zip=new ZipFile(jar)) {
            for(String owner:new String[]{"dy","net/minecraft/client/Minecraft"}) {
                String path=owner+".class";
                byte[] old;try(InputStream in=zip.getInputStream(zip.getEntry(path))){old=AlphaModernAgent.readAll(in);}
                byte[] updated=AlphaInventoryPatch.patch(old,owner);
                ok(updated.length>old.length,"missing inventory JVM hook "+owner);
                ok(new String(updated,"ISO-8859-1").contains("alphamodern/InventoryMirror"),"hook class missing "+owner);
                modified.put(owner.replace('/','.'),updated);
            }
        }
        try(URLClassLoader loader=new URLClassLoader(new URL[]{Paths.get(jar).toUri().toURL()},InventoryBridgeTest.class.getClassLoader()){
            @Override protected Class<?> findClass(String name)throws ClassNotFoundException {
                byte[] code=modified.get(name);
                if(code!=null)return defineClass(name,code,0,code.length);
                return super.findClass(name);
            }
        }) {
            Class<?> gui=Class.forName("dy",false,loader);
            gui.getDeclaredMethod("a",int.class,int.class,int.class);
            Class<?> mc=Class.forName("net.minecraft.client.Minecraft",false,loader);
            ok(mc!=null,"patched Minecraft class did not load");
        }
    }
    public static void main(String[] args)throws Exception {
        codec();packets();bytecode(args.length>0?args[0]:"/mnt/data/minecraft-a1.0.15-client.jar");
        System.out.println("PASS: modern simple stack parsing, server slot snapshots, hotbar, cleared items, inventory click and original Alpha bytecode hooks");
    }
}
