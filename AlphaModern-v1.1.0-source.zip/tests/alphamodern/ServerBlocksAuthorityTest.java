package alphamodern;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.zip.*;

/** Verifies that only server updates mutate the projected chunk cache. */
public final class ServerBlocksAuthorityTest {
    private static void check(boolean b,String what){if(!b)throw new AssertionError(what);}
    public static void main(String[] args)throws Exception {
        ServerBlockAuthority auth=new ServerBlockAuthority();
        Map<Long,ChunkTranslator.LegacyChunk> chunks=new HashMap<Long,ChunkTranslator.LegacyChunk>();
        ChunkTranslator.LegacyChunk c=new ChunkTranslator.LegacyChunk(0,0,new byte[ChunkTranslator.OLD_LENGTH]);
        chunks.put(ServerBlockAuthority.key(0,0),c);
        check(auth.knownBlock(chunks,2,70,3,0)==0,"fixture initial air");
        int seq1=auth.sequence(2,70,3,-1),seq2=auth.sequence(2,70,3,1),seq3=auth.sequence(4,71,5,-1);
        check(seq1==1&&seq2==2&&seq3==3,"non-monotonic block sequences");
        check(auth.pendingCount()==3,"pending count");
        // Alpha never predicts a change here: network user actions must not alter block data.
        check(auth.knownBlock(chunks,2,70,3,0)==0,"actions mutated the server-owned cache");
        // Modern server sends a block update, then lighting repaints the entire cache.
        auth.record(new ServerBlockAuthority.Change(2,70,3,4|(7<<8)),chunks,0);
        check(auth.knownBlock(chunks,2,70,3,0)==(4|(7<<8)),"single block update failed to update cached chunk and metadata");
        // Simulate a reprojected chunk with a different 128-block slice.
        ChunkTranslator.LegacyChunk reprojected=new ChunkTranslator.LegacyChunk(0,0,new byte[ChunkTranslator.OLD_LENGTH]);
        auth.apply(reprojected,48);
        Map<Long,ChunkTranslator.LegacyChunk> newChunks=new HashMap<Long,ChunkTranslator.LegacyChunk>();
        newChunks.put(ServerBlockAuthority.key(0,0),reprojected);
        check(auth.knownBlock(newChunks,2,70,3,48)==(4|(7<<8)),"reprojection resurrected an old state");
        check(auth.knownBlock(newChunks,2,70,3,0)==0,"reprojected state has wrong location");
        // Clear old metadata when the server updates to air.
        auth.record(new ServerBlockAuthority.Change(2,70,3,0),chunks,0);
        check(auth.knownBlock(chunks,2,70,3,0)==0,"server air failed to clear old metadata");
        // Acknowledging a rejected placement restores server-sourced blocks, not predicted ones.
        try(ServerSocket listener=new ServerSocket(0,1,InetAddress.getLoopbackAddress());
            Socket client=new Socket(InetAddress.getLoopbackAddress(),listener.getLocalPort());
            Socket remote=listener.accept()) {
            ByteArrayOutputStream legacyBytes=new ByteArrayOutputStream();
            Gateway.Session session=new Gateway.Session(new DataInputStream(new ByteArrayInputStream(new byte[0])),
                new DataOutputStream(legacyBytes),client,"Tester","localhost",listener.getLocalPort());
            auth.acknowledge(seq2,session,chunks,0);
            check(auth.pendingCount()==1,"cumulative block change acknowledgement lost pending entries");
            check(auth.acknowledgedCount()==1,"ack counter not updated");
            check(auth.correctionCount()>=2,"server state was not resent after action ack");
            DataInputStream input=new DataInputStream(new ByteArrayInputStream(legacyBytes.toByteArray()));
            check(input.readUnsignedByte()==53,"missing legacy block correction");
            check(input.readInt()==2&&input.readUnsignedByte()==70&&input.readInt()==3,"wrong correction position");
            check(input.readUnsignedByte()==0&&input.readUnsignedByte()==0,"server rejected placement but client received a ghost");
            session.close();
        }
        auth.forget(0,0);
        ChunkTranslator.LegacyChunk newChunk=new ChunkTranslator.LegacyChunk(0,0,new byte[ChunkTranslator.OLD_LENGTH]);
        auth.apply(newChunk,0);
        check((newChunk.data[ServerBlockAuthority.atIndex(2,70,3)]&255)==0,"chunk unload kept stale overlay");
        auth.clear();check(auth.pendingCount()==0,"dimension change left pending block changes");
        // Collision mismatches that used to cause hidden walls.
        check(CollisionMapping.noCollision(27162),"powder snow not recognized as modern non-solid");
        check(CollisionMapping.correct(27162,80)==0,"powder snow became a solid snow cube");
        check(CollisionMapping.correct(12533,0)==20,"invisible solid barrier became air");
        check(CollisionMapping.correct(86,9)==9,"modern water must remain a liquid");
        System.out.println("PASS: server authority, client prediction ban, block update+metadata, chunk resync, sequence acknowledgement, collision mapping");
    }
}
