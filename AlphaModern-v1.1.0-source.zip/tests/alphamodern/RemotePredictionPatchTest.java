package alphamodern;

import java.io.*;
import java.util.zip.*;

/** Check the patch is truly isolated to the Alpha remote-world class. */
public final class RemotePredictionPatchTest {
    static void assertTrue(boolean b,String m){if(!b)throw new AssertionError(m);}
    public static void main(String[] args)throws Exception {
        String jar=args.length>0?args[0]:"/mnt/data/minecraft-a1.0.15-client.jar";
        byte[] original;
        try(ZipFile zip=new ZipFile(jar);InputStream in=zip.getInputStream(zip.getEntry("gj.class"))) {
            original=AlphaModernAgent.readAll(in);
        }
        byte[] patched=RemoteWorldPatch.patch(original);
        assertTrue(patched.length==original.length,"bytecode patch unexpectedly grew class");
        int count=0;
        for(int i=0;i<patched.length;i++)if(patched[i]!=original[i]){
            assertTrue(i+1<patched.length,"truncated patch");
            assertTrue(original[i]==(byte)0x2a&&original[i+1]==(byte)0x1b&&
                patched[i]==(byte)0x03&&patched[i+1]==(byte)0xac,"non-prediction bytecode changed at "+i);
            i++;count++;
        }
        assertTrue(count==3,"only the three speculative world methods may change; got "+count);
        assertTrue(original[0]==patched[0]&&original[1]==patched[1],"invalid class");
        System.out.println("PASS: patch changed precisely 3 speculative gj method prologues; server block updates remain untouched");
    }
}
