package alphamodern;
import java.io.*;
import java.net.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.zip.*;

/** Regression for a modern proxy lobby where teleport precedes player chunk. */
public final class SpawnSafetyIntegrationTest {
    static void check(boolean yes,String why){if(!yes)throw new AssertionError(why);}
    static void set(Gateway.Session s,String field,Object val)throws Exception{
        Field f=Gateway.Session.class.getDeclaredField(field);f.setAccessible(true);f.set(s,val);
    }
    static boolean get(Gateway.Session s,String field)throws Exception{
        Field f=Gateway.Session.class.getDeclaredField(field);f.setAccessible(true);return f.getBoolean(s);
    }
    static byte[] body(Wire.Writer writer)throws Exception{
        ByteArrayOutputStream b=new ByteArrayOutputStream();DataOutputStream o=new DataOutputStream(b);writer.write(o);o.flush();return b.toByteArray();
    }
    static void deliver(Gateway.Session s,int id,Wire.Writer writer)throws Exception{
        Method m=Gateway.Session.class.getDeclaredMethod("handlePlay",Wire.Packet.class);m.setAccessible(true);
        try{m.invoke(s,new Wire.Packet(id,new DataInputStream(new ByteArrayInputStream(body(writer)))));}
        catch(InvocationTargetException e){Throwable t=e.getCause();if(t instanceof Exception)throw (Exception)t;throw new RuntimeException(t);}
    }
    static byte[] makeChunk(int cx,int cz)throws Exception {
        byte[] payload=ViewportTest.packet(250,8);DataOutputStream out=new DataOutputStream(new ByteArrayOutputStream());
        payload[0]=(byte)(cx>>24);payload[1]=(byte)(cx>>16);payload[2]=(byte)(cx>>8);payload[3]=(byte)cx;
        payload[4]=(byte)(cz>>24);payload[5]=(byte)(cz>>16);payload[6]=(byte)(cz>>8);payload[7]=(byte)cz;
        return payload;
    }
    static void skipChunk(DataInputStream in)throws Exception{
        in.readInt();in.readShort();in.readInt();in.readUnsignedByte();in.readUnsignedByte();in.readUnsignedByte();
        int len=in.readInt();check(len>0&&len<200000,"Bad old chunk length");byte[] bytes=new byte[len];in.readFully(bytes);
    }
    static int[] legacyIds(byte[] data)throws Exception {
        ArrayList<Integer> ids=new ArrayList<Integer>();DataInputStream in=new DataInputStream(new ByteArrayInputStream(data));
        while(in.available()>0){int id=in.readUnsignedByte();ids.add(id);
            if(id==50){in.readInt();in.readInt();in.readBoolean();}
            else if(id==51)skipChunk(in);
            else if(id==13){in.readDouble();double stance=in.readDouble();double feet=in.readDouble();in.readDouble();in.readFloat();in.readFloat();in.readBoolean();
                check(stance==feet+1.62||Math.abs(stance-(feet+1.62))<1.e-6,"Invalid Alpha stance ordering");
            }else if(id==53){in.readInt();in.readUnsignedByte();in.readInt();in.readByte();in.readByte();}
            else throw new AssertionError("Unexpected Alpha packet "+id);
        }
        int[] out=new int[ids.size()];for(int i=0;i<out.length;i++)out[i]=ids.get(i);return out;
    }
    static boolean contains(int[] ids,int which){for(int id:ids)if(id==which)return true;return false;}
    public static void main(String[] args)throws Exception {
        ByteArrayOutputStream alphaBytes=new ByteArrayOutputStream();
        try(ServerSocket listener=new ServerSocket(0,1,InetAddress.getLoopbackAddress());
            Socket client=new Socket(InetAddress.getLoopbackAddress(),listener.getLocalPort());
            Socket peer=listener.accept()){
            peer.setSoTimeout(2500);Wire modern=new Wire(peer);
            Gateway.Session s=new Gateway.Session(new DataInputStream(new ByteArrayInputStream(new byte[0])),
                new DataOutputStream(alphaBytes),client,"Tester","localhost",listener.getLocalPort());
            set(s,"playing",true);set(s,"alphaLoggedIn",true);
            deliver(s,GameIds.CLIENTBOUND_PLAYER_POSITION,o->{Wire.var(o,77);o.writeDouble(64.5);o.writeDouble(250);
                o.writeDouble(-16.5);o.writeDouble(0);o.writeDouble(0);o.writeDouble(0);
                o.writeFloat(90);o.writeFloat(0);o.writeInt(0);});
            check(modern.recv().id==GameIds.SERVERBOUND_ACCEPT_TELEPORTATION,"Teleport ACK missing");
            check(modern.recv().id==GameIds.SERVERBOUND_MOVE_PLAYER_POS_ROT,"Immediate server-space sync missing");
            check(!get(s,"spawnReady"),"Spawn movement unlocked with no terrain");
            check(alphaBytes.size()==0,"Alpha was teleported before its spawn terrain was available");
            byte[] wrong=makeChunk(0,0);
            deliver(s,GameIds.CLIENTBOUND_LEVEL_CHUNK_WITH_LIGHT,o->o.write(wrong));
            check(!get(s,"spawnReady"),"Nearby-but-wrong chunk falsely unlocked spawn");
            check(!contains(legacyIds(alphaBytes.toByteArray()),13),"Wrong chunk triggered Alpha position");
            alphaBytes.reset();
            byte[] own=makeChunk(4,-2);
            deliver(s,GameIds.CLIENTBOUND_LEVEL_CHUNK_WITH_LIGHT,o->o.write(own));
            check(get(s,"spawnReady"),"Matching spawn chunk failed to unlock movement");
            int[] ids=legacyIds(alphaBytes.toByteArray());
            check(ids.length>=3&&ids[0]==50&&ids[1]==51&&ids[2]==13,
                "Initial Alpha position was sent before own chunk: "+Arrays.toString(ids));
            check(modern.recv().id==GameIds.SERVERBOUND_PLAYER_LOADED,"Player Loaded was not gated by true spawn chunk");
            alphaBytes.reset();
            // Hub switches: must evict old geometry, stop accepting movement, and
            // demand the destination's own spawn chunk before Player Loaded.
            deliver(s,GameIds.CLIENTBOUND_RESPAWN,o->{Wire.var(o,0);Wire.str(o,"minecraft:overworld");
                o.writeLong(0L);o.writeByte(0);o.writeByte(-1);o.writeBoolean(false);o.writeBoolean(false);
                o.writeBoolean(false);Wire.var(o,0);Wire.var(o,63);o.writeByte(3);
            });
            check(!get(s,"spawnReady"),"Respawn retained old spawn readiness");
            check(!get(s,"viewportReady"),"Respawn retained wrong vertical viewport");
            int[] unload=legacyIds(alphaBytes.toByteArray());
            check(unload.length==2&&unload[0]==50&&unload[1]==50,"Old hub chunks not unloaded");
            s.close();
        }
        // A real patched Alpha class must verify and link without touching the
        // user's original client JAR on disk.
        try(ZipFile zip=new ZipFile(args.length>0?args[0]:"/mnt/data/minecraft-a1.0.15-client.jar")) {
            byte[] original;try(InputStream in=zip.getInputStream(zip.getEntry("jw.class"))){original=AlphaModernAgent.readAll(in);}
            byte[] modified=SpawnCollisionPatch.patch(original);
            check(modified.length>original.length,"Expected injected constant pool entries");
            check(new String(modified,"ISO-8859-1").contains("alphamodern/SpawnCollisionGuard"),"Missing collision-shim reference");
        }
        Method overlap=SpawnCollisionGuard.class.getDeclaredMethod("overlapsSpawnBody",double[].class);overlap.setAccessible(true);
        SpawnCollisionGuard.arm(64.5,74.0,-16.5);
        check(!(Boolean)overlap.invoke(null,(Object)new double[]{64,73,-17,65,74,-16}),"Floor beneath feet must retain collision");
        check((Boolean)overlap.invoke(null,(Object)new double[]{64,74,-17,65,75,-16}),"Overlapping head block must be eligible for local shim");
        check(!(Boolean)overlap.invoke(null,(Object)new double[]{65,74,-17,66,75,-16}),"Neighbour wall beyond player should remain solid");
        SpawnCollisionGuard.clear();
        System.out.println("PASS: wrong chunk cannot unlock spawn, correct chunk precedes teleport, Player Loaded is gated, respawn evicts old hub, collision shim does not remove floor/nearby walls");
        System.out.println("ALL SPAWN SAFETY TESTS PASSED");
    }
}
