package alphamodern;

import java.util.Arrays;

/** Protocol 776 block-state metadata overlay generated from the 26.2 state ordering.
 * Alpha has no equivalents for upside-down/curved stair shapes, waterlogged blocks,
 * or many modern partial blocks; those are safely simplified.
 */
final class BlockStateMapper {
    private static int[] decode(String ids) {
        String[] parts=ids.split(",");int[] a=new int[parts.length];
        for(int i=0;i<parts.length;i++)a[i]=Integer.parseInt(parts[i],36);
        Arrays.sort(a);return a;
    }
    private static final int[] STAIRS=decode("30j,4fn,6p2,6ra,6ti,6vv,787,7bp,7i8,7kg,7mo,8qo,98k,9as,9d0,9f8,9hg,9jo,9lw,9qy,9t6,9ve,a82,bcs,bsw,bv4,bxc,bzk,c1s,c40,c68,c8g,cao,ccw,cf4,chc,cjk,cls,gfu,gi2,gug,h64,hhd,i3n,if2,iqi,j23,jdi,jox,k0d,kbs,kn7,lgg,lio,lkw,ln4,lpc,lrk,lts,lw0,nh0,nsf,o3u,of9");
    private static final int[] DOORS=decode("4d3,58t,auk,awc,ay4,azw,b1o,b3g,b58,b70,b8s,glm,gne,lzk,m1c,m34,m4w,m6o,m8g,ma8,mc0");
    private static final int[] SLABS=decode("6y3,9xm,9xs,9xy,aaa,aag,aam,aas,aay,ab4,aba,abg,abm,abs,aby,ac4,aca,acg,acm,acs,acy,ad4,ada,adg,adm,ads,ady,ae4,aea,co0,co6,coc,coi,coo,cou,cp0,cp6,cpc,cpi,cpo,cpu,cq0,g8a,g8g,h5o,h5y,hjl,i3h,iew,iqc,j1x,jdc,jor,k07,kbm,kn1,ly8,lye,lyk,lyq,lyw,lz2,lz8,lze,nj8,nun,o62,ohh");
    private static final int[] FURNACES=decode("43z,g0i,g0q");
    private static final int[] WALL_TORCHES=decode("2ln,5bb,5en");
    private static final int[] LADDERS=decode("4ev");
    private static final int[] CHESTS=decode("32r,7dz,8nb");
    private static final int[] FENCE_GATES=decode("6o6,aek,afg,agc,ah8,ai4,aj0,ajw,aks,alo,ge2,gey");
    private static final int[] TRAPDOORS=decode("5hm,5je,5l6,5my,5oq,5qi,5sa,5u2,5vu,5xm,9p3,gai,gca,mds,mfk,mhc,mj4,mkw,mmo,mog,mq8");

    private static int findStart(int state,int[] starts,int width) {
        int i=Arrays.binarySearch(starts,state);
        if(i<0)i=-i-2;
        return i>=0 && state-starts[i]<width?starts[i]:-1;
    }
    private static int horizontal(int i) {
        // 26.2 facing order: north,south,west,east.
        // Alpha stair metadata: east=0,west=1,south=2,north=3.
        return new int[]{3,2,1,0}[i&3];
    }
    private static int cardinal(int i) {
        // Legacy ladder, furnace, chest: north=2,south=3,west=4,east=5.
        return new int[]{2,3,4,5}[i&3];
    }
    private static int torch(int i) {
        return new int[]{4,3,2,1}[i&3];
    }
    /** Return Alpha id (low 8 bits) plus metadata (next nibble). */
    static int apply(int state,int baseline) {
        int start=findStart(state,STAIRS,80);
        if(start>=0){int facing=(state-start)/20;return (baseline&255)|(horizontal(facing)<<8);}
        start=findStart(state,DOORS,64);
        if(start>=0){int off=state-start;int facing=off/16,half=(off/8)%2,open=(off/2)%2;
            // Modern half order upper, lower. Alpha bit 3 = upper block.
            return (baseline&255)|((horizontal(facing)|(half==0?8:0)|(open==0?4:0))<<8);
        }
        start=findStart(state,SLABS,6);
        if(start>=0){int type=(state-start)/2;int base=type==2?43:44;return base | ((type==0?8:0)<<8);}
        start=findStart(state,FURNACES,8);
        if(start>=0)return (baseline&255)|(cardinal((state-start)/2)<<8);
        start=findStart(state,CHESTS,24);
        if(start>=0)return (baseline&255)|(cardinal((state-start)/6)<<8);
        start=findStart(state,LADDERS,8);
        if(start>=0)return 65|(cardinal((state-start)/2)<<8);
        start=findStart(state,WALL_TORCHES,8);
        if(start>=0){int face=(state-start)/2;return (baseline&255)|(torch(face)<<8);}
        start=findStart(state,FENCE_GATES,32);
        if(start>=0)return 1; // Alpha has no gate: deliberate full-cube collision fallback.
        start=findStart(state,TRAPDOORS,64);
        if(start>=0)return 1; // No legacy trapdoor: unregistered solid becomes stone.
        return baseline;
    }
    private BlockStateMapper(){}
}
