package alphamodern;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Small, safe plugin-channel transport, not a Bukkit/Velocity plugin runtime.
 * The agent remains compatible with server-side plugins through normal packets.
 * Arbitrary client-specific payloads require a client-side handler and are not
 * executed or acknowledged implicitly.
 */
final class PluginChannels {
    private static final int MAX_PAYLOAD=32767;
    private final Set<String> advertised=new HashSet<String>();
    private int packets,unknown;
    private String brand="";
    synchronized void received(DataInputStream in) throws IOException {
        String channel=Wire.str(in);
        if(channel.length()>256)throw new IOException("Plugin channel identifier too long");
        byte[] body=AlphaModernAgent.readAll(in);
        if(body.length>MAX_PAYLOAD)throw new IOException("Plugin message too large: "+body.length);
        packets++;
        if(!channel.matches("[a-z0-9_.\\-]+:[a-z0-9_./\\-]+") && !"BungeeCord".equals(channel)) {
            unknown++;return; // legacy/proprietary extension: ignore safely
        }
        if(channel.equals("minecraft:brand")) {
            DataInputStream b=new DataInputStream(new ByteArrayInputStream(body));
            brand=Wire.str(b);
            if(brand.length()>256)brand=brand.substring(0,256);
            System.out.println(AlphaModernAgent.PREFIX+"Server brand: "+brand);
        } else if(channel.equals("minecraft:register") || channel.equals("minecraft:unregister")) {
            String[] channels=new String(body,StandardCharsets.UTF_8).split("\\u0000");
            for(String c:channels)if(c.matches("[a-z0-9_.\\-]+:[a-z0-9_./\\-]+")){
                if(channel.endsWith("register") && !channel.endsWith("unregister"))advertised.add(c);
                else advertised.remove(c);
            }
        } else {
            unknown++;
            if(unknown<=2)System.out.println(AlphaModernAgent.PREFIX+"Ignored optional plugin payload "+channel+" ("+body.length+" bytes)");
        }
    }
    byte[] registrationPayload(){
        // No client-only channels are claimed by default. Server plugins can
        // still use vanilla transfer, title, actionbar, commands and chat.
        String channels=System.getProperty("alpha.modern.pluginChannels","").trim();
        if(channels.isEmpty())return new byte[0];
        StringBuilder b=new StringBuilder();
        for(String part:channels.split(",")){
            String c=part.trim();
            if(c.matches("[a-z0-9_.\\-]+:[a-z0-9_./\\-]+") && b.length()+c.length()+1<MAX_PAYLOAD){
                if(b.length()>0)b.append('\0');b.append(c);
            }
        }
        return b.toString().getBytes(StandardCharsets.UTF_8);
    }
    synchronized int count(){return packets;}
    synchronized String brand(){return brand;}
}
