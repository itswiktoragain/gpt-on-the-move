package alphamodern;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/** Modern 26.2 item registry id -> a real Alpha 1.0.15 item ID.
 * Unsupported IDs use the registered full-stone placeholder (1), never an
 * invalid Alpha item which would crash the GUI renderer.
 */
final class ItemMapping {
    private static final int[] ids=read();
    private static int[] read() {
        int[] result=new int[1537];
        Arrays.fill(result,1);
        result[0]=0;
        try(InputStream file=ItemMapping.class.getResourceAsStream("itemmap.rle")) {
            if(file==null)throw new IOException("Missing modern item registry mapping");
            String text=new String(AlphaModernAgent.readAll(file), StandardCharsets.US_ASCII).trim();
            for(String segment:text.split(",")) {
                String[] p=segment.split(":");
                if(p.length!=2)throw new IOException("Bad item mapping");
                int modern=Integer.parseInt(p[0],36),old=Integer.parseInt(p[1],36);
                if(modern<0||modern>=result.length||!(old==0||old>=1&&old<=84||old>=256&&old<=344))
                    throw new IOException("Invalid Alpha item mapping: "+segment);
                result[modern]=old;
            }
        }catch(Exception e){throw new ExceptionInInitializerError(e);}
        return result;
    }
    static int toAlpha(int modernId){return modernId>=0&&modernId<ids.length?ids[modernId]:1;}
}
