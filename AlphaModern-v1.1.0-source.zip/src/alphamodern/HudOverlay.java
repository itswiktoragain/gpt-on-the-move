package alphamodern;

import java.lang.reflect.*;

/** Item name captions, server titles, subtitles and action-bar messages.
 * Rendered by a hook at the end of Alpha's existing in-game HUD paint method.
 */
public final class HudOverlay {
    private static volatile String title="",subtitle="",action="";
    private static volatile long untilTitle,untilAction;
    private static volatile int titleStayMs=3000;
    private static int lastItem=-2;
    private static long itemUntil;
    private HudOverlay(){}
    static void title(String text){title=brief(text);untilTitle=System.currentTimeMillis()+titleStayMs;}
    static void subtitle(String text){subtitle=brief(text);untilTitle=System.currentTimeMillis()+titleStayMs;}
    static void actionBar(String text){action=brief(text);untilAction=System.currentTimeMillis()+2800;}
    static void timings(int fadeIn,int stay,int fadeOut){titleStayMs=Math.min(30000,Math.max(1500,(stay+fadeOut)*50));}
    static void clearTitles(){title="";subtitle="";action="";untilTitle=0;untilAction=0;}
    static void clear(){clearTitles();lastItem=-2;itemUntil=0;}
    private static String brief(String s){
        if(s==null)return "";
        s=TextComponent.sanitize(s);
        return s.length()>180?s.substring(0,180):s;
    }
    public static void render(Object hud){
        try {
            final long now=System.currentTimeMillis();
            final int currentItem=InventoryMirror.selectedItemId();
            if(currentItem!=lastItem){lastItem=currentItem;itemUntil=now+2600;}
            if(now>itemUntil&&now>untilTitle&&now>untilAction)return;
            Field game=hud.getClass().getDeclaredField("g");game.setAccessible(true);
            Object mc=game.get(hud);if(mc==null)return;
            Class<?> minecraft=mc.getClass();
            Object font=minecraft.getField("o").get(mc);
            if(font==null)return;
            ClassLoader loader=minecraft.getClassLoader();
            Class<?> sizeType=Class.forName("io",false,loader);
            Object size=sizeType.getConstructor(int.class,int.class).newInstance(minecraft.getField("c").getInt(mc),minecraft.getField("d").getInt(mc));
            int width=((Number)sizeType.getMethod("a").invoke(size)).intValue();
            int height=((Number)sizeType.getMethod("b").invoke(size)).intValue();
            Method textWidth=font.getClass().getMethod("a",String.class);
            Method draw=font.getClass().getMethod("b",String.class,int.class,int.class,int.class);
            if(now<=untilTitle){
                if(!title.isEmpty())paint(font,textWidth,draw,title,width/2,height/3,0xffffdd);
                if(!subtitle.isEmpty())paint(font,textWidth,draw,subtitle,width/2,height/3+17,0xffffff);
            }
            if(now<=untilAction&&!action.isEmpty())paint(font,textWidth,draw,action,width/2,height-64,0xffffaa);
            else if(now<=itemUntil&&currentItem>=0)paint(font,textWidth,draw,ItemNames.name(currentItem),width/2,height-66,0xffffff);
        } catch(ReflectiveOperationException | LinkageError | RuntimeException ignored) { /* HUD can change during dimension switches */ }
    }
    private static void paint(Object font,Method width,Method draw,String message,int center,int y,int color)throws ReflectiveOperationException{
        if(message.isEmpty())return;
        int w=((Number)width.invoke(font,message)).intValue();
        draw.invoke(font,message,Math.max(2,center-w/2),y,color);
    }
}
