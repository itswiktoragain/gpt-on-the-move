package alphamodern;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
/** User-facing item names for the modern item registry (not the fallback icon). */
final class ItemNames {
    private static final String[] NAMES=new String[4096];
    static {
        try(InputStream r=ItemNames.class.getResourceAsStream("/alphamodern/itemnames.txt")) {
            if(r!=null)try(BufferedReader br=new BufferedReader(new InputStreamReader(r,StandardCharsets.UTF_8))){
                String line;int n=0;while((line=br.readLine())!=null && n<NAMES.length)NAMES[n++]=line;
            }
        }catch(IOException ignored){}
    }
    static String name(int modernId){
        if(modernId<0)return "";
        if(modernId<NAMES.length&&NAMES[modernId]!=null)return NAMES[modernId];
        return "Item #"+modernId;
    }
}
