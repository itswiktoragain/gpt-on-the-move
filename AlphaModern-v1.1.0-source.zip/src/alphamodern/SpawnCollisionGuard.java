package alphamodern;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Field;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Only for the first server-authorized position after joining a modern world.
 * Leave block data and meshes unchanged. If old Alpha's collision approximation
 * puts the player INSIDE an occupied bounding box at the server's exact spawn,
 * suppress only the intersection with the ORIGINAL spawn body (not the floor,
 * and not blocks beyond it), for a short exit window. The server remains
 * authoritative: no server coordinates, block states or chunk caches are edited.
 */
public final class SpawnCollisionGuard {
    private static final AtomicLong OMITTED = new AtomicLong();
    private static volatile double sx, sy, sz;
    private static volatile long expires;
    private static volatile boolean armed;
    private static volatile boolean warned;

    private static final ClassValue<MethodHandle> WORLD_COLLISIONS = new ClassValue<MethodHandle>() {
        @Override protected MethodHandle computeValue(Class<?> worldType) {
            try {
                ClassLoader loader=worldType.getClassLoader();
                Class<?> entityType=Class.forName("jw",false,loader);
                Class<?> boxType=Class.forName("cb",false,loader);
                return MethodHandles.publicLookup().findVirtual(worldType,"a",
                        MethodType.methodType(List.class,entityType,boxType))
                    .asType(MethodType.methodType(List.class,Object.class,Object.class,Object.class));
            } catch(Exception e) {throw new IllegalStateException("Could not resolve original Alpha collision method",e);}
        }
    };
    private static final ClassValue<Field[]> BOX = new ClassValue<Field[]>() {
        @Override protected Field[] computeValue(Class<?> cls) {
            try {
                return new Field[]{cls.getField("a"),cls.getField("b"),cls.getField("c"),
                    cls.getField("d"),cls.getField("e"),cls.getField("f")};
            } catch(Exception e) {throw new IllegalStateException("Unknown Alpha AABB",e);}
        }
    };
    private static final ClassValue<Field[]> ENTITY = new ClassValue<Field[]>() {
        @Override protected Field[] computeValue(Class<?> cls) {
            try {
                return new Field[]{cls.getField("ah"),cls.getField("ai"),cls.getField("aj")};
            } catch(Exception e) {throw new IllegalStateException("Unknown Alpha entity center",e);}
        }
    };
    private SpawnCollisionGuard() {}

    static void arm(double x,double y,double z) {
        if(!Double.isFinite(x)||!Double.isFinite(y)||!Double.isFinite(z))return;
        sx=x;sy=y;sz=z;
        expires=System.nanoTime()+8_000_000_000L;
        warned=false;OMITTED.set(0);armed=true;
    }
    static void clear() {armed=false;expires=0;}
    static long omitted(){return OMITTED.get();}

    @SuppressWarnings({"unchecked","rawtypes"})
    public static List collisions(Object world,Object entity,Object box) {
        List results;
        try {results=(List)WORLD_COLLISIONS.get(world.getClass()).invokeExact(world,entity,box);}
        catch(Throwable e){throw new IllegalStateException("Alpha collision query failed",e);}
        if(!armed||WorldLightGuard.active()==0||!"be".equals(entity.getClass().getName())||System.nanoTime()>expires)
            return results;
        try {
            Field[] p=ENTITY.get(entity.getClass());
            double x=p[0].getDouble(entity),y=p[1].getDouble(entity),z=p[2].getDouble(entity);
            // If the player has escaped the spawn pocket, restore vanilla
            // collision immediately. This avoids phasing through nearby walls.
            if(Math.abs(x-sx)>1.4||Math.abs(z-sz)>1.4||Math.abs(y-sy)>2.2) {
                clear();return results;
            }
            if(results.isEmpty())return results;
            Iterator<?> iter=results.iterator();
            while(iter.hasNext()) {
                Object collision=iter.next();
                if(overlapsSpawnBody(boxValues(collision))) {
                    iter.remove();
                    if(OMITTED.incrementAndGet()==1&&!warned) {
                        warned=true;
                        System.out.println(AlphaModernAgent.PREFIX+
                            "Spawn collision compatibility: temporarily ignored a conflicting legacy box; server terrain unchanged");
                    }
                }
            }
        }catch(RuntimeException err){throw err;}
        catch(Exception error){throw new IllegalStateException("Alpha collision compatibility lookup failed",error);}
        return results;
    }
    private static double[] boxValues(Object box) throws IllegalAccessException {
        Field[] fields=BOX.get(box.getClass());double[] a=new double[6];
        for(int i=0;i<6;i++)a[i]=fields[i].getDouble(box);
        return a;
    }
    private static boolean overlapsSpawnBody(double[] b) {
        // Intentionally exclude the ground whose top is exactly at feet Y.
        // Include the 0.3-block horizontal radius and 1.8-block player body.
        return b[3]>sx-0.29&&b[0]<sx+0.29&&b[5]>sz-0.29&&b[2]<sz+0.29&&
               b[4]>sy+0.07&&b[1]<sy+1.75;
    }
}
