package alphamodern;

import java.io.IOException;
import java.lang.reflect.Field;

/** Double-tap forward (W by default) on Alpha's actual movement input.
 * Called by the injected hook at the end of fu.a(dg), before physics moves.
 */
public final class SprintController {
    private static volatile Gateway.Session session;
    private static boolean forwardPressed,sprinting;
    private static long lastPressTime;
    private static volatile byte flags;
    private static volatile int lastSentFlags=-1;
    private static final long DOUBLE_TAP_NS=350_000_000L;
    private SprintController(){}
    static synchronized void bind(Gateway.Session s){session=s;reset();}
    static synchronized void clear(Gateway.Session s){if(session==s){session=null;reset();}}
    static synchronized void reset(){forwardPressed=false;sprinting=false;lastPressTime=0;flags=0;lastSentFlags=-1;}
    /** Alpha forward is lh.b; fu is the input implementation of lh. */
    public static void update(Object movement) {
        Gateway.Session s=session;
        if(s==null || !s.isReadyToMove())return;
        try {
            Class<?> parent=movement.getClass().getSuperclass();
            Field forward=parent.getField("b"),strafe=parent.getField("a"),jump=parent.getField("d");
            float f=forward.getFloat(movement),side=strafe.getFloat(movement);
            boolean now=f>0.5f;
            boolean next;
            synchronized(SprintController.class){
                long when=System.nanoTime();
                if(now&&!forwardPressed) {
                    if(lastPressTime!=0 && when-lastPressTime>=0 && when-lastPressTime<=DOUBLE_TAP_NS)
                        next=true;
                    else next=sprinting;
                    lastPressTime=when;
                } else next=sprinting;
                if(!now)next=false;
                forwardPressed=now;
                if(next!=sprinting){sprinting=next;try{s.sendSprint(next);}catch(IOException ex){System.err.println(AlphaModernAgent.PREFIX+"Sprint toggle: "+ex);}}
                int bits=(f>0.5f?1:0)|(f<-.5f?2:0)|(side>0.5f?4:0)|(side<-.5f?8:0)|
                    (jump.getBoolean(movement)?16:0)|(sprinting?64:0);
                flags=(byte)bits;
                if(sprinting)forward.setFloat(movement, f*1.3f);
            }
        }catch(ReflectiveOperationException ex){
            // Older worlds or custom movement implementations lack these fields.
        }
    }
    static void sendInputIfChanged(Gateway.Session s)throws IOException {
        if(session!=s)return;
        byte value=flags;
        if((value&255)!=lastSentFlags){lastSentFlags=value&255;s.sendInput(value);}
    }
    static synchronized boolean isSprinting(){return sprinting;}
}
