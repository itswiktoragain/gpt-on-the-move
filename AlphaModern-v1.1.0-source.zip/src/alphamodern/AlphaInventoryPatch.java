package alphamodern;

import java.io.*;
import java.lang.instrument.ClassFileTransformer;
import java.nio.charset.StandardCharsets;
import java.security.ProtectionDomain;
import java.util.HashMap;
import java.util.Map;

/** Minimal Java 5 bytecode hooks into world-join and the existing Alpha inventory GUI.
 * Leave original rendering, input, and GUI layouts intact. Both targeted
 * handlers end in exactly one RETURN; this avoids rewriting branch offsets.
 */
final class AlphaInventoryPatch implements ClassFileTransformer {
    private static final String MINECRAFT="net/minecraft/client/Minecraft";
    @Override public byte[] transform(ClassLoader loader,String name,Class<?> cls,ProtectionDomain pd,byte[] bytes){
        if(!MINECRAFT.equals(name)&&!"dy".equals(name))return null;
        try{
            byte[] out=patch(bytes,name);
            System.out.println(AlphaModernAgent.PREFIX+"Installed server inventory hook ("+name+")");
            return out;
        }catch(Exception ex){System.err.println(AlphaModernAgent.PREFIX+"Inventory hook failed for "+name+": "+ex);return null;}
    }
    static byte[] patch(byte[] bytes,String owner) throws IOException {
        boolean isGame=MINECRAFT.equals(owner);
        if(!isGame&&!"dy".equals(owner))throw new IOException("Unsupported class");
        DataInputStream in=new DataInputStream(new ByteArrayInputStream(bytes));
        ByteArrayOutputStream raw=new ByteArrayOutputStream(bytes.length+100);
        DataOutputStream out=new DataOutputStream(raw);
        if(in.readInt()!=0xcafebabe)throw new IOException("Bad class magic");
        out.writeInt(0xcafebabe);out.writeShort(in.readUnsignedShort());int version=in.readUnsignedShort();
        if(version!=49)throw new IOException("Not original Alpha Java 5 class");out.writeShort(version);
        int count=in.readUnsignedShort();out.writeShort(count+6);
        Map<Integer,String> utf=new HashMap<Integer,String>();
        for(int i=1;i<count;i++) {
            int tag=in.readUnsignedByte();out.writeByte(tag);
            switch(tag) {
                case 1:{int n=in.readUnsignedShort();byte[] b=new byte[n];in.readFully(b);out.writeShort(n);out.write(b);utf.put(i,new String(b,StandardCharsets.UTF_8));break;}
                case 3:case 4:case 9:case 10:case 11:case 12:case 17:case 18:copy(in,out,4);break;
                case 5:case 6:copy(in,out,8);i++;break;
                case 7:case 8:case 16:case 19:case 20:copy(in,out,2);break;
                case 15:copy(in,out,3);break;
                default:throw new IOException("Unsupported pool tag "+tag);
            }
        }
        // Append UTF8 class, Class, method, desc, NameAndType, MethodRef.
        utf8(out,"alphamodern/InventoryMirror");out.writeByte(7);out.writeShort(count);
        utf8(out,isGame?"bind":"click");utf8(out,isGame?"(Ljava/lang/Object;)V":"(Ljava/lang/Object;III)V");
        out.writeByte(12);out.writeShort(count+2);out.writeShort(count+3);
        out.writeByte(10);out.writeShort(count+1);out.writeShort(count+4);
        int ref=count+5;
        copy(in,out,6);
        int interfaces=in.readUnsignedShort();out.writeShort(interfaces);copy(in,out,interfaces*2);
        int fields=in.readUnsignedShort();out.writeShort(fields);
        for(int i=0;i<fields;i++)member(in,out,utf,false,false,ref);
        int methods=in.readUnsignedShort();out.writeShort(methods);
        int hit=0;
        for(int i=0;i<methods;i++)hit+=member(in,out,utf,true,isGame,ref);
        if(hit!=1)throw new IOException("Expected exactly one method hook, got "+hit);
        int attrs=in.readUnsignedShort();out.writeShort(attrs);
        for(int i=0;i<attrs;i++)attribute(in,out,utf,false,isGame,ref);
        if(in.read()!=-1)throw new IOException("Unexpected trailing class bytes");
        out.flush();return raw.toByteArray();
    }
    private static int member(DataInputStream in,DataOutputStream out,Map<Integer,String> utf,boolean isMethod,boolean game,int ref)throws IOException{
        out.writeShort(in.readUnsignedShort());int name=in.readUnsignedShort(),desc=in.readUnsignedShort();out.writeShort(name);out.writeShort(desc);
        boolean hook=isMethod&&"a".equals(utf.get(name))&&
            (game?"(Lcj;)V":"(III)V").equals(utf.get(desc));
        int attrs=in.readUnsignedShort();out.writeShort(attrs);int added=0;
        for(int i=0;i<attrs;i++)added+=attribute(in,out,utf,hook,game,ref);
        if(hook&&added!=1)throw new IOException("Missing Code attribute for hook");
        return added;
    }
    private static int attribute(DataInputStream in,DataOutputStream out,Map<Integer,String> utf,boolean hook,boolean game,int ref)throws IOException{
        int name=in.readUnsignedShort(),len=in.readInt();
        if(len<0||len>10000000)throw new IOException("Invalid attribute length");
        byte[] data=new byte[len];in.readFully(data);
        boolean edit=hook&&"Code".equals(utf.get(name));
        byte[] output=edit?insert(data,game,ref):data;
        out.writeShort(name);out.writeInt(output.length);out.write(output);
        return edit?1:0;
    }
    private static byte[] insert(byte[] bytes,boolean game,int ref)throws IOException{
        DataInputStream in=new DataInputStream(new ByteArrayInputStream(bytes));
        int stack=in.readUnsignedShort(),locals=in.readUnsignedShort(),size=in.readInt();
        if(size<1||size>bytes.length||(!game&&size<700))throw new IOException("Unexpected Alpha handler length "+size);
        byte[] code=new byte[size];in.readFully(code);
        if((code[size-1]&255)!=0xb1)throw new IOException("Target does not end in RETURN");
        // Alpha GUI a(III)V has just one return; all existing gotos to that
        // end offset will now run the hook before returning.
        ByteArrayOutputStream buf=new ByteArrayOutputStream(bytes.length+9);DataOutputStream out=new DataOutputStream(buf);
        out.writeShort(Math.max(stack,game?1:4));out.writeShort(locals);
        out.writeInt(size+(game?4:7));out.write(code,0,size-1);
        out.writeByte(0x2a); // aload_0
        if(!game){out.writeByte(0x1b);out.writeByte(0x1c);out.writeByte(0x1d);} // iload_1..3
        out.writeByte(0xb8);out.writeShort(ref);
        out.writeByte(0xb1); // return
        out.write(AlphaModernAgent.readAll(in));out.flush();return buf.toByteArray();
    }
    private static void utf8(DataOutputStream o,String s)throws IOException{byte[] b=s.getBytes(StandardCharsets.UTF_8);o.writeByte(1);o.writeShort(b.length);o.write(b);}
    private static void copy(DataInputStream i,DataOutputStream o,int n)throws IOException{byte[] b=new byte[n];i.readFully(b);o.write(b);}
}
