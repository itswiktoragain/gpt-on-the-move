package alphamodern;

import java.io.IOException;
import java.util.*;

/**
 * The only source of block IDs is modern server chunk/block update data.
 * Pending interactions never mutate it. Overlays keep later server updates
 * authoritative when a cached chunk is reprojected at a different height.
 */
final class ServerBlockAuthority {
    static final class Change {
        final int x,worldY,z,packed;
        Change(int x,int y,int z,int packed){this.x=x;this.worldY=y;this.z=z;this.packed=packed;}
    }
    private static final class Pending {
        final int x,y,z,face;
        Pending(int x,int y,int z,int face){this.x=x;this.y=y;this.z=z;this.face=face;}
    }
    private static final int MAX_PENDING=512;
    private static final int MAX_OVERRIDES_PER_CHUNK=8192;
    private final Map<Long, LinkedHashMap<Integer,Integer>> overlays=new HashMap<Long, LinkedHashMap<Integer,Integer>>();
    private final LinkedHashMap<Integer,Pending> pending=new LinkedHashMap<Integer,Pending>();
    private int nextSequence;
    private int acks;
    private int corrections;
    static long key(int x,int z){return ((long)x<<32)|(z&0xffffffffL);}
    static int position(int x,int y,int z){return ((y&0xffff)<<8)|((x&15)<<4)|(z&15);}
    static int atIndex(int x,int alphaY,int z){return ((x&15)<<11)|((z&15)<<7)|alphaY;}
    synchronized void clear(){overlays.clear();pending.clear();nextSequence=0;acks=0;corrections=0;}
    synchronized void forget(int x,int z){overlays.remove(key(x,z));}
    synchronized int sequence(int x,int y,int z,int face){
        // The protocol requires an increasing sequence for each action, not 0.
        if(nextSequence==Integer.MAX_VALUE){nextSequence=0;pending.clear();}
        int n=++nextSequence;
        pending.put(n,new Pending(x,y,z,face));
        while(pending.size()>MAX_PENDING)pending.remove(pending.keySet().iterator().next());
        return n;
    }
    synchronized int pendingCount(){return pending.size();}
    synchronized int acknowledgedCount(){return acks;}
    synchronized int correctionCount(){return corrections;}
    synchronized List<Pending> acknowledged(int ack){
        List<Pending> ret=new ArrayList<Pending>();
        Iterator<Map.Entry<Integer,Pending>> i=pending.entrySet().iterator();
        while(i.hasNext()){
            Map.Entry<Integer,Pending> e=i.next();
            if(e.getKey()<=ack){ret.add(e.getValue());i.remove();}
        }
        acks++;
        return ret;
    }
    synchronized void record(Change change, Map<Long,ChunkTranslator.LegacyChunk> chunks,int baseY){
        long key=key(change.x>>4,change.z>>4);
        LinkedHashMap<Integer,Integer> changes=overlays.get(key);
        if(changes==null){changes=new LinkedHashMap<Integer,Integer>();overlays.put(key,changes);}
        int pos=position(change.x,change.worldY,change.z);
        // Reinsert to keep the most recent updates when bounding the cache.
        changes.remove(pos);changes.put(pos,change.packed);
        if(changes.size()>MAX_OVERRIDES_PER_CHUNK)changes.remove(changes.keySet().iterator().next());
        ChunkTranslator.LegacyChunk chunk=chunks.get(key);
        if(chunk!=null)write(chunk,change.x,change.worldY-baseY,change.z,change.packed);
    }
    synchronized void apply(ChunkTranslator.LegacyChunk chunk,int baseY){
        Map<Integer,Integer> changes=overlays.get(key(chunk.x,chunk.z));
        if(changes==null)return;
        for(Map.Entry<Integer,Integer> e:changes.entrySet()){
            int pos=e.getKey(),y=(pos>>>8)&65535;
            if(y>=32768)y-=65536;
            write(chunk,(chunk.x<<4)|((pos>>>4)&15),y-baseY,(chunk.z<<4)|(pos&15),e.getValue());
        }
    }
    static void write(ChunkTranslator.LegacyChunk chunk,int x,int alphaY,int z,int packed){
        if(alphaY<0||alphaY>=128)return;
        int idx=atIndex(x,alphaY,z);
        chunk.data[idx]=(byte)(packed&255);
        int offset=ChunkTranslator.META_OFFSET+(idx>>>1);
        if((idx&1)==0)chunk.data[offset]=(byte)((chunk.data[offset]&0xf0)|((packed>>>8)&15));
        else chunk.data[offset]=(byte)((chunk.data[offset]&0x0f)|(((packed>>>8)&15)<<4));
    }
    synchronized int knownBlock(Map<Long,ChunkTranslator.LegacyChunk> chunks,int x,int worldY,int z,int baseY){
        int alphaY=worldY-baseY;
        if(alphaY<0||alphaY>=128)return -1;
        ChunkTranslator.LegacyChunk chunk=chunks.get(key(x>>4,z>>4));
        if(chunk==null)return -1;
        int idx=atIndex(x,alphaY,z);
        int bytePos=ChunkTranslator.META_OFFSET+(idx>>>1);
        int meta=((chunk.data[bytePos]&255)>>>((idx&1)*4))&15;
        return (chunk.data[idx]&255)|(meta<<8);
    }
    void acknowledge(int sequence,Gateway.Session gateway,Map<Long,ChunkTranslator.LegacyChunk> chunks,int baseY)throws IOException {
        List<Pending> list=acknowledged(sequence);
        for(Pending p:list){
            correct(gateway,chunks,baseY,p.x,p.y,p.z);
            if(p.face>=0&&p.face<6){
                int x=p.x,y=p.y,z=p.z;
                switch(p.face){
                    case 0:y--;break;case 1:y++;break;case 2:z--;break;
                    case 3:z++;break;case 4:x--;break;case 5:x++;break;
                }
                correct(gateway,chunks,baseY,x,y,z);
            }
        }
    }
    private void correct(Gateway.Session gateway,Map<Long,ChunkTranslator.LegacyChunk> chunks,int baseY,int x,int y,int z)throws IOException{
        int packed=knownBlock(chunks,x,y,z,baseY),legacyY=y-baseY;
        if(packed<0||legacyY<0||legacyY>127)return;
        gateway.legacy(53,o->{o.writeInt(x);o.writeByte(legacyY);o.writeInt(z);
            o.writeByte(packed&255);o.writeByte((packed>>>8)&15);});
        synchronized(this){corrections++;}
    }
}
