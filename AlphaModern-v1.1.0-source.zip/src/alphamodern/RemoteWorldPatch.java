package alphamodern;

import java.io.*;
import java.lang.instrument.ClassFileTransformer;
import java.nio.charset.StandardCharsets;
import java.security.ProtectionDomain;
import java.util.HashMap;
import java.util.Map;

/**
 * Disable the three Alpha SMP client-prediction entry points in gj.class.
 *
 * Alpha's remote world extends cj. gj.a(IIII)Z, gj.a(IIIII)Z and
 * gj.c(IIII)Z optimistically alter the world then enqueue kq rollback jobs.
 * Protocol 776 has a separate prediction/ack protocol, so those stale local
 * mutations must not be made. Crucially, gj.c(IIIII)Z, used by packet gn.a(kw)
 * for authoritative server BLOCK_UPDATE, is NOT patched.
 *
 * This patch only affects Alpha's multiplayer subclass; offline cj is intact.
 */
final class RemoteWorldPatch implements ClassFileTransformer {
    @Override public byte[] transform(ClassLoader loader,String name,Class<?> cls,
                                      ProtectionDomain domain,byte[] bytes) {
        if(!"gj".equals(name))return null;
        try {
            byte[] patched=patch(bytes);
            System.out.println(AlphaModernAgent.PREFIX+
                "Disabled speculative block edits (gj); server chunk/block packets remain authoritative");
            return patched;
        }catch(Exception e) {
            System.err.println(AlphaModernAgent.PREFIX+"Remote world prediction patch refused: "+e);
            return null;
        }
    }
    static byte[] patch(byte[] original) throws IOException {
        DataInputStream in=new DataInputStream(new ByteArrayInputStream(original));
        ByteArrayOutputStream sink=new ByteArrayOutputStream(original.length);
        DataOutputStream out=new DataOutputStream(sink);
        int magic=in.readInt();if(magic!=0xcafebabe)throw new IOException("Bad class magic");
        out.writeInt(magic);out.writeShort(in.readUnsignedShort());out.writeShort(in.readUnsignedShort());
        int count=in.readUnsignedShort();out.writeShort(count);
        Map<Integer,String> utf8=new HashMap<Integer,String>();
        for(int i=1;i<count;i++) {
            int tag=in.readUnsignedByte();out.writeByte(tag);
            switch(tag) {
                case 1:{int n=in.readUnsignedShort();byte[] b=new byte[n];in.readFully(b);
                    utf8.put(i,new String(b,StandardCharsets.UTF_8));out.writeShort(n);out.write(b);break;}
                case 3:case 4:case 9:case 10:case 11:case 12:case 17:case 18:copy(in,out,4);break;
                case 5:case 6:copy(in,out,8);i++;break;
                case 7:case 8:case 16:case 19:case 20:copy(in,out,2);break;
                case 15:copy(in,out,3);break;
                default:throw new IOException("Unknown constant pool tag "+tag);
            }
        }
        copy(in,out,6); // flags, this class, superclass
        int interfaces=in.readUnsignedShort();out.writeShort(interfaces);copy(in,out,interfaces*2);
        int fields=in.readUnsignedShort();out.writeShort(fields);
        for(int j=0;j<fields;j++)member(in,out,utf8,false);
        int methods=in.readUnsignedShort();out.writeShort(methods);
        int patched=0;
        for(int j=0;j<methods;j++)patched+=member(in,out,utf8,true);
        if(patched!=3)throw new IOException("Expected 3 local prediction entry points, got "+patched);
        int attrs=in.readUnsignedShort();out.writeShort(attrs);
        for(int i=0;i<attrs;i++)attribute(in,out,false);
        if(in.read()!=-1)throw new IOException("Unexpected trailing bytes");
        out.flush();return sink.toByteArray();
    }
    private static int member(DataInputStream in,DataOutputStream out,Map<Integer,String> utf,boolean method)throws IOException {
        out.writeShort(in.readUnsignedShort());
        int name=in.readUnsignedShort(),desc=in.readUnsignedShort();out.writeShort(name);out.writeShort(desc);
        String n=utf.get(name), d=utf.get(desc);
        boolean target=method && ("a".equals(n)&&("(IIII)Z".equals(d)||"(IIIII)Z".equals(d)) ||
            "c".equals(n)&&"(IIII)Z".equals(d));
        int attrs=in.readUnsignedShort();out.writeShort(attrs);
        int hits=0;for(int i=0;i<attrs;i++)hits+=attribute(in,out,target);
        if(target&&hits!=1)throw new IOException("Cannot patch local method "+n+d);
        return hits;
    }
    private static int attribute(DataInputStream in,DataOutputStream out,boolean target)throws IOException {
        int name=in.readUnsignedShort(),size=in.readInt();
        if(size<0||size>10000000)throw new IOException("Invalid attribute");
        byte[] buf=new byte[size];in.readFully(buf);
        int hits=0;
        if(target&&size>10) {
            int len=((buf[4]&255)<<24)|((buf[5]&255)<<16)|((buf[6]&255)<<8)|(buf[7]&255);
            // Only patch Code bytes: both first two bytecodes are ALWAYS aload_0, iload_1.
            // The three targeted methods in the user's Alpha JAR all have exactly
            // one Code attribute; no other attribute begins with this signature.
            if(len>=32&&len+8<=size&&(buf[8]&255)==0x2a&&(buf[9]&255)==0x1b) {
                buf[8]=0x03;buf[9]=(byte)0xac; // iconst_0; ireturn
                hits=1;
            }
        }
        out.writeShort(name);out.writeInt(size);out.write(buf);
        return hits;
    }
    private static void copy(DataInputStream in,DataOutputStream out,int n)throws IOException {
        byte[] b=new byte[n];in.readFully(b);out.write(b);
    }
}
