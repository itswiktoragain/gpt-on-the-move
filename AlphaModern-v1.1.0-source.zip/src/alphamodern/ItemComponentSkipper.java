package alphamodern;

import java.io.*;

/** Bounded 26.2 (protocol 776) item-component reader for the common inventory
 *  components used by servers. Values are discarded because Alpha cannot
 *  represent custom names, lore or enchantments; the containing stack's base
 *  item ID and count are still synchronized from the server. All unsupported
 *  codecs fail CLOSED instead of misaligning subsequent inventory slots.
 *
 *  IDs and wire structures: minecraft-data-26.2 protocol.json SlotComponent.
 */
final class ItemComponentSkipper {
    private ItemComponentSkipper() {}
    static void skip(DataInputStream in,int type,int depth) throws IOException {
        if(depth>8)throw new IOException("Nested item components too deep");
        switch(type) {
            // Anonymous (nameless) NBT tags. The text-component parser reads
            // every NBT value completely and already enforces depth/size caps.
            case 0: case 6: case 9: case 47: case 57: case 59:
                TextComponent.readFormatted(in);return;
            // No payload.
            case 4: case 20: case 22: case 34:return;
            // VarInt enums, counters and item/color ID fields.
            case 1: case 2: case 3: case 12: case 19: case 31: case 41:
            case 43: case 46: case 48: case 63: case 73:
                Wire.var(in);return;
            // Float value.
            case 7: case 52:in.readFloat();return;
            // Booleans.
            case 21:in.readBoolean();return;
            // Fixed i32 color.
            case 44: case 45:in.readInt();return;
            // VarInt-prefixed UTF-8 strings.
            case 10:case 27:case 35:case 71:
                string(in);return;
            // Sprint/vibration flags and speed multiplier.
            case 5:in.readBoolean();in.readBoolean();in.readFloat();return;
            // Display lore array of anonymous NBT components.
            case 11:{int n=count(in);for(int i=0;i<n;i++)TextComponent.readFormatted(in);return;}
            // Enchantments: VarInt count of {type VarInt, level VarInt}.
            case 13:case 42:{int n=count(in);for(int i=0;i<n;i++){Wire.var(in);Wire.var(in);}return;}
            // Attribute modifiers: type, string id, value, operation, slot,
            // display mode and optional text-component override.
            case 16:{int n=count(in);for(int i=0;i<n;i++){
                Wire.var(in);string(in);in.readDouble();Wire.var(in);Wire.var(in);
                int display=Wire.var(in);if(display==2)TextComponent.readFormatted(in);
                else if(display!=0&&display!=1)throw new IOException("Unknown attribute display mode");
            }return;}
            // Custom model data: arrays of floats, booleans, strings and ARGB colors.
            case 17:{int n=count(in);for(int i=0;i<n;i++)in.readFloat();
                n=count(in);for(int i=0;i<n;i++)in.readBoolean();
                n=count(in);for(int i=0;i<n;i++)string(in);
                n=count(in);for(int i=0;i<n;i++)in.readInt();return;}
            // Tooltip display: hide tooltip bool, array of hidden component IDs.
            case 18:{in.readBoolean();int n=count(in);for(int i=0;i<n;i++)Wire.var(in);return;}
            // Food stats.
            case 23:Wire.var(in);in.readFloat();in.readBoolean();return;
            // Item returned after use is another Slot.
            case 25:InventoryMirror.readSlot(in,depth+1);return;
            // Use cooldown: float and optional string.
            case 26:in.readFloat();if(in.readBoolean())string(in);return;
            // Weapon attack cost and block cooldown.
            case 29:Wire.var(in);in.readFloat();return;
            // Attack range parameters: 6 floats.
            case 30:for(int i=0;i<6;i++)in.readFloat();return;
            // Attack animation type and duration.
            case 40:Wire.var(in);Wire.var(in);return;
            // Charged crossbow projectiles and bundle slots.
            case 49:case 50:{int n=count(in);for(int i=0;i<n;i++)InventoryMirror.readSlot(in,depth+1);return;}
            // Suspicious stew effects.
            case 53:{int n=count(in);for(int i=0;i<n;i++){Wire.var(in);Wire.var(in);}return;}
            // Map decorations and potion color use known component formats only.
            case 58:case 60:Wire.var(in);TextComponent.readFormatted(in);return;
            default:throw new IOException("Unsupported 26.2 item component type "+type);
        }
    }
    private static int count(DataInputStream in)throws IOException {
        int n=Wire.var(in);if(n<0||n>4096)throw new IOException("Invalid component list length "+n);return n;
    }
    private static void string(DataInputStream in)throws IOException {
        int n=Wire.var(in);if(n<0||n>32767)throw new IOException("Invalid component string length "+n);
        while(n>0){int skipped=in.skipBytes(n);if(skipped<=0)throw new EOFException("Component string truncated");n-=skipped;}
    }
}
