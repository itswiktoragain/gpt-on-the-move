package alphamodern;

import java.io.*;
import java.lang.instrument.ClassFileTransformer;
import java.nio.charset.StandardCharsets;
import java.security.ProtectionDomain;
import java.util.HashMap;
import java.util.Map;

/** Surgical Alpha jw.class patch, preserving bytecode lengths and stack depth.
 * Replace invokevirtual cj.a(jw,cb):List with invokestatic
 * SpawnCollisionGuard.collisions(Object,Object,Object):List in the four
 * entity collision queries. Vanilla world physics is delegated without changes
 * when the modern bridge's small initial-spawn protection is inactive.
 */
final class SpawnCollisionPatch implements ClassFileTransformer {
    @Override public byte[] transform(ClassLoader loader,String name,Class<?> cls,ProtectionDomain pd,byte[] bytes){
        if(!"jw".equals(name))return null;
        try {
            byte[] patched=patch(bytes);
            System.out.println(AlphaModernAgent.PREFIX+"Installed initial-spawn collision shim (jw)");
            return patched;
        }catch(Exception e){System.err.println(AlphaModernAgent.PREFIX+"Spawn shim patch rejected: "+e);return null;}
    }
    static byte[] patch(byte[] original) throws IOException {
        DataInputStream in=new DataInputStream(new ByteArrayInputStream(original));
        ByteArrayOutputStream buf=new ByteArrayOutputStream(original.length+128);DataOutputStream out=new DataOutputStream(buf);
        int magic=in.readInt();if(magic!=0xcafebabe)throw new IOException("Not a classfile");
        out.writeInt(magic);out.writeShort(in.readUnsignedShort());int major=in.readUnsignedShort();
        if(major!=49)throw new IOException("Expected Minecraft Alpha 1.0.15 Java 5 bytecode");out.writeShort(major);
        int count=in.readUnsignedShort();if(count>65525)throw new IOException("Constant pool exhausted");out.writeShort(count+6);
        Map<Integer,String> utf=new HashMap<Integer,String>();
        Map<Integer,int[]> names=new HashMap<Integer,int[]>();
        Map<Integer,int[]> refs=new HashMap<Integer,int[]>();
        for(int i=1;i<count;i++){
            int tag=in.readUnsignedByte();out.writeByte(tag);
            switch(tag){
                case 1:{int n=in.readUnsignedShort();byte[] bs=new byte[n];in.readFully(bs);utf.put(i,new String(bs,StandardCharsets.UTF_8));out.writeShort(n);out.write(bs);break;}
                case 9:case 10:case 11:case 12:{int a=in.readUnsignedShort(),b=in.readUnsignedShort();out.writeShort(a);out.writeShort(b);if(tag==12)names.put(i,new int[]{a,b});else refs.put(i,new int[]{tag,a,b});break;}
                case 3:case 4:case 17:case 18:copy(in,out,4);break;
                case 5:case 6:copy(in,out,8);i++;break;
                case 7:case 8:case 16:case 19:case 20:copy(in,out,2);break;
                case 15:copy(in,out,3);break;
                default:throw new IOException("Unknown CP tag "+tag);
            }
        }
        // In the supplied Alpha 1.0.15 client this is constant pool #172.
        int[] ref=refs.get(172);
        if(ref==null||ref[0]!=10)throw new IOException("Original collision methodref #172 missing");
        int[] nt=names.get(ref[2]);
        if(nt==null||!"a".equals(utf.get(nt[0]))||!"(Ljw;Lcb;)Ljava/util/List;".equals(utf.get(nt[1])))
            throw new IOException("Original collision method reference changed");
        utf8(out,"alphamodern/SpawnCollisionGuard");out.writeByte(7);out.writeShort(count);
        utf8(out,"collisions");utf8(out,"(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/List;");
        out.writeByte(12);out.writeShort(count+2);out.writeShort(count+3);
        out.writeByte(10);out.writeShort(count+1);out.writeShort(count+4);
        int shim=count+5;
        copy(in,out,6);int interfaces=in.readUnsignedShort();out.writeShort(interfaces);copy(in,out,2*interfaces);
        int fields=in.readUnsignedShort();out.writeShort(fields);for(int i=0;i<fields;i++)member(in,out,utf,shim,false);
        int methods=in.readUnsignedShort();out.writeShort(methods);int changed=0;
        for(int i=0;i<methods;i++)changed+=member(in,out,utf,shim,true);
        if(changed!=4)throw new IOException("Expected 4 entity collision sites, got "+changed);
        int attrs=in.readUnsignedShort();out.writeShort(attrs);for(int i=0;i<attrs;i++)attr(in,out,false,shim,utf);
        if(in.read()!=-1)throw new IOException("Trailing bytes");out.flush();return buf.toByteArray();
    }
    private static int member(DataInputStream in,DataOutputStream out,Map<Integer,String> utf,int shim,boolean isMethod) throws IOException {
        copy(in,out,6);int attrs=in.readUnsignedShort();out.writeShort(attrs);int changed=0;
        for(int i=0;i<attrs;i++)changed+=attr(in,out,isMethod,shim,utf);return changed;
    }
    private static int attr(DataInputStream in,DataOutputStream out,boolean method,int shim,Map<Integer,String> utf) throws IOException {
        int name=in.readUnsignedShort(),size=in.readInt();if(size<0||size>10000000)throw new IOException("Bad attribute");
        byte[] body=new byte[size];in.readFully(body);int changed=0;
        if(method&&"Code".equals(utf.get(name))&&size>12){
            int len=((body[4]&255)<<24)|((body[5]&255)<<16)|((body[6]&255)<<8)|(body[7]&255);
            if(len>0&&len+8<=size){
                for(int j=8;j+2<8+len;j++){
                    if((body[j]&255)==0xb6&&(body[j+1]&255)==0&&(body[j+2]&255)==172){
                        body[j]=(byte)0xb8;body[j+1]=(byte)(shim>>>8);body[j+2]=(byte)shim;changed++;j+=2;
                    }
                }
            }
        }
        out.writeShort(name);out.writeInt(size);out.write(body);return changed;
    }
    private static void utf8(DataOutputStream o,String s)throws IOException{byte[] b=s.getBytes(StandardCharsets.UTF_8);o.writeByte(1);o.writeShort(b.length);o.write(b);}
    private static void copy(DataInputStream i,DataOutputStream o,int n)throws IOException{byte[] b=new byte[n];i.readFully(b);o.write(b);}
}
