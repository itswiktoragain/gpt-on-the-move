package alphamodern;

/**
 * Collision-safe approximations for protocol-776 states.
 * The ranges come from 26.2 minecraft-data entries whose boundingBox is
 * "empty" (no normal collision shape). A full-cube fallback for those
 * states creates phantom walls. Retain liquids / Alpha non-solid shapes.
 * A barrier, conversely, collides on the server and cannot be mapped to air.
 */
final class CollisionMapping {
    private static final String EMPTY_RANGES=
        "0-0,t-2c,2e-39,1or-1q2,1qf-1qo,1s5-1sx,2lm-2zz,33f-43e,43j-43q,447-4d2,4f3-4fm,4hv-55e,"+
        "583-58s,5al-5b4,5b9-5ce,5cx-5cx,5cz-5de,5em-5ev,5ex-5ey,6fi-6o5,7af-7ai,7b0-7b0,"+
        "7e7-7i6,883-8f6,8nz-8ou,8sw-8tj,9o7-9p2,9yr-a7y,bf1-bf2,bfd-bfi,bfk-bfk,bgj-bgj,"+
        "bme-bn4,bor-bs2,bse-bse,bss-bsv,g5p-g5s,g66-g66,g68-g69,g6n-g6n,g6p-g87,g8m-g8p,"+
        "gka-gll,gp6-grd,hjr-hkg,kyi-kyi,lbw-lff,nc9-ndr,ndv-nf6,ng4-ngt,or8-or8,oyv-oyy,oz1-oz1";
    private static final int[] STARTS,ENDS;
    static {
        String[] ranges=EMPTY_RANGES.split(",");STARTS=new int[ranges.length];ENDS=new int[ranges.length];
        for(int i=0;i<ranges.length;i++){
            String[] pair=ranges[i].split("-");
            STARTS[i]=Integer.parseInt(pair[0],36);ENDS[i]=Integer.parseInt(pair[1],36);
        }
    }
    static boolean noCollision(int state){
        int low=0,high=STARTS.length-1;
        while(low<=high){int m=(low+high)>>>1;
            if(state<STARTS[m])high=m-1;
            else if(state>ENDS[m])low=m+1;
            else return true;
        }
        return false;
    }
    static int correct(int modernState,int alphaPacked){
        // Invisible Minecraft barriers are solid. Make them visible glass in
        // Alpha rather than an impossible-to-see server-side wall.
        if(modernState==12533||modernState==12534)return 20;
        if(!noCollision(modernState))return alphaPacked;
        int id=alphaPacked&255;
        // Minecraft Alpha's liquid and small non-colliding IDs keep their
        // appearance; only incompatible full-cube approximations become air.
        switch(id){
            case 0:case 6:case 8:case 9:case 10:case 11:
            case 30:case 31:case 32:case 37:case 38:case 39:case 40:
            case 50:case 51:case 55:case 59:case 63:case 65:case 66:
            case 69:case 70:case 72:case 75:case 76:case 77:case 78:
            case 83:case 90:
                return alphaPacked;
            default:return 0;
        }
    }
    private CollisionMapping(){}
}
