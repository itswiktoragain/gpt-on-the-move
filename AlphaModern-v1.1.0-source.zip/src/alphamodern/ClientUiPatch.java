package alphamodern;

import java.io.*;
import java.lang.instrument.ClassFileTransformer;
import java.nio.charset.StandardCharsets;
import java.security.ProtectionDomain;
import java.util.HashMap;
import java.util.Map;

/** Java 5-compatible hooks for HUD painting and movement input. Neither hook
 * modifies control flow or changes Minecraft's original world/player classes.
 */
final class ClientUiPatch implements ClassFileTransformer {
    @Override public byte[] transform(ClassLoader loader,String owner,Class<?> cls,ProtectionDomain pd,byte[] bytes) {
        if(!"lj".equals(owner)&&!"fu".equals(owner))return null;
        try {byte[] output=patch(bytes,owner);System.out.println(AlphaModernAgent.PREFIX+"Patched Alpha "+owner+" HUD/movement input");return output;}
        catch(Exception e){System.err.println(AlphaModernAgent.PREFIX+"Could not patch "+owner+": "+e);return null;}
    }
    static byte[] patch(byte[] original,String owner) throws IOException {
        boolean hud="lj".equals(owner);
        if(!hud&&!"fu".equals(owner))throw new IOException("Unexpected patch class "+owner);
        DataInputStream in=new DataInputStream(new ByteArrayInputStream(original));
        ByteArrayOutputStream bytes=new ByteArrayOutputStream(original.length+90);DataOutputStream out=new DataOutputStream(bytes);
        if(in.readInt()!=0xcafebabe)throw new IOException("Class magic mismatch");
        out.writeInt(0xcafebabe);out.writeShort(in.readUnsignedShort());int version=in.readUnsignedShort();
        if(version!=49)throw new IOException("Not an original Alpha Java 5 class");out.writeShort(version);
        int count=in.readUnsignedShort();out.writeShort(count+6);
        Map<Integer,String> utf=new HashMap<Integer,String>();
        for(int i=1;i<count;i++){
            int tag=in.readUnsignedByte();out.writeByte(tag);
            switch(tag){
                case 1:{int n=in.readUnsignedShort();byte[] b=new byte[n];in.readFully(b);out.writeShort(n);out.write(b);utf.put(i,new String(b,StandardCharsets.UTF_8));break;}
                case 3:case 4:case 9:case 10:case 11:case 12:case 17:case 18:copy(in,out,4);break;
                case 5:case 6:copy(in,out,8);i++;break;
                case 7:case 8:case 16:case 19:case 20:copy(in,out,2);break;
                case 15:copy(in,out,3);break;
                default:throw new IOException("Unexpected pool tag "+tag);
            }
        }
        utf(out,hud?"alphamodern/HudOverlay":"alphamodern/SprintController");out.writeByte(7);out.writeShort(count);
        utf(out,hud?"render":"update");utf(out,"(Ljava/lang/Object;)V");
        out.writeByte(12);out.writeShort(count+2);out.writeShort(count+3);
        out.writeByte(10);out.writeShort(count+1);out.writeShort(count+4);
        int ref=count+5;
        copy(in,out,6);int interfaces=in.readUnsignedShort();out.writeShort(interfaces);copy(in,out,2*interfaces);
        int fields=in.readUnsignedShort();out.writeShort(fields);for(int i=0;i<fields;i++)member(in,out,utf,false,hud,ref);
        int methods=in.readUnsignedShort();out.writeShort(methods);int hooks=0;
        for(int i=0;i<methods;i++)hooks+=member(in,out,utf,true,hud,ref);
        if(hooks!=1)throw new IOException("Expected exactly one method to patch, got "+hooks);
        int attrs=in.readUnsignedShort();out.writeShort(attrs);for(int i=0;i<attrs;i++)attribute(in,out,utf,false,ref);
        if(in.read()!=-1)throw new IOException("Trailing bytes");out.flush();return bytes.toByteArray();
    }
    private static int member(DataInputStream in,DataOutputStream out,Map<Integer,String> utf,boolean method,boolean hud,int ref)throws IOException{
        out.writeShort(in.readUnsignedShort());int name=in.readUnsignedShort(),desc=in.readUnsignedShort();out.writeShort(name);out.writeShort(desc);
        boolean target=method&&"a".equals(utf.get(name))&&(hud?"(FZII)V":"(Ldg;)V").equals(utf.get(desc));
        int count=in.readUnsignedShort();out.writeShort(count);int hit=0;
        for(int i=0;i<count;i++)hit+=attribute(in,out,utf,target,ref);
        if(target&&hit!=1)throw new IOException("Target has no Code attribute");
        return hit;
    }
    private static int attribute(DataInputStream in,DataOutputStream out,Map<Integer,String> utf,boolean target,int ref)throws IOException{
        int name=in.readUnsignedShort(),length=in.readInt();if(length<0||length>10_000_000)throw new IOException("Invalid attribute size");
        byte[] body=new byte[length];in.readFully(body);
        byte[] updated=target&&"Code".equals(utf.get(name))?inject(body,ref):body;
        out.writeShort(name);out.writeInt(updated.length);out.write(updated);
        return target&&"Code".equals(utf.get(name))?1:0;
    }
    private static byte[] inject(byte[] original,int ref)throws IOException{
        DataInputStream in=new DataInputStream(new ByteArrayInputStream(original));
        int stack=in.readUnsignedShort(),locals=in.readUnsignedShort(),length=in.readInt();
        if(length<10||length>original.length-8)throw new IOException("Unexpected method bytecode length "+length);
        byte[] code=new byte[length];in.readFully(code);
        if((code[length-1]&255)!=0xb1)throw new IOException("Target must finish with single RETURN");
        ByteArrayOutputStream b=new ByteArrayOutputStream(original.length+5);DataOutputStream o=new DataOutputStream(b);
        o.writeShort(Math.max(stack,1));o.writeShort(locals);o.writeInt(length+4);
        o.write(code,0,length-1);o.writeByte(0x2a);o.writeByte(0xb8);o.writeShort(ref);o.writeByte(0xb1);
        o.write(AlphaModernAgent.readAll(in));o.flush();return b.toByteArray();
    }
    private static void utf(DataOutputStream out,String s)throws IOException{byte[] b=s.getBytes(StandardCharsets.UTF_8);out.writeByte(1);out.writeShort(b.length);out.write(b);}
    private static void copy(DataInputStream in,DataOutputStream out,int n)throws IOException{byte[] b=new byte[n];in.readFully(b);out.write(b);}
}
