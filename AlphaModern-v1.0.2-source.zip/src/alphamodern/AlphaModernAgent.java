package alphamodern;

import java.io.*;
import java.lang.instrument.*;
import java.security.ProtectionDomain;
import java.util.*;
import java.nio.charset.StandardCharsets;

/** Minecraft Alpha 1.0.15 -> protocol 776 gateway (experimental). */
public final class AlphaModernAgent {
    static final String PREFIX = "[AlphaModern/776] ";
    public static void premain(String args, Instrumentation inst) {
        try {
            AuthOverlay.enableInGameInput();
            Gateway.start();
            inst.addTransformer(new PatchSocket());
            inst.addTransformer(new InGamePatch());
            inst.addTransformer(new FontRendererPatch());
            inst.addTransformer(new WorldLightPatch());
            inst.addTransformer(new RemoteWorldPatch());
            inst.addTransformer(new SpawnCollisionPatch());
            inst.addTransformer(new AlphaInventoryPatch());
            System.out.println(PREFIX + "Active; use Alpha's Multiplayer screen, enter a 26.2 server address.");
            System.out.println(PREFIX + "Online servers will ask for a Microsoft email, then request a device-link code when needed.");
            System.out.println(PREFIX + "Default device-code login no longer requires Azure CLI or Microsoft app registration.");
            System.out.println(PREFIX + "v1.0.2: unregistered block full collision; server-synced player inventory (experimental).");
        } catch (Throwable t) { throw new IllegalStateException("Unable to start AlphaModern agent", t); }
    }
    public static void main(String[] args) throws Exception {
        if (args.length >= 1 && args[0].equals("ping")) {
            String host = args.length >= 2 ? args[1] : "127.0.0.1";
            int port = args.length >= 3 ? Integer.parseInt(args[2]) : 25565;
            if (host.startsWith("[") && host.contains("]")) host = host.substring(1,host.indexOf(']'));
            System.out.println(StatusPing.ping(host, port));
        } else if (args.length == 2 && args[0].equals("configure")) {
            java.nio.file.Path path=AuthManager.configureClient(args[1]);
            System.out.println("Microsoft public application ID saved to "+path);
            System.out.println("Online servers will now offer Microsoft device-code login when needed.");
        } else if (args.length == 1 && args[0].equals("use-switch")) {
            java.nio.file.Path path=AuthManager.configureClient(AuthManager.SWITCH_CLIENT_ID);
            System.out.println("Xbox/Switch-style public client ID saved to " + path);
            System.out.println("On your next online-mode connection, AlphaModern will request a code from Microsoft without Azure CLI.");
        } else if (args.length == 1 && args[0].equals("register")) {
            String id=AuthManager.configuredClientId(AuthManager.defaultPath());
            if(id.isEmpty()) {
                AuthManager.Profile cached=AuthManager.shared().peek();
                if(cached!=null)id=cached.clientId;
            }
            if(id.isEmpty()) {
                id=AzureClientRegistrar.local().register(AuthManager.defaultPath(), ()->true);
                System.out.println("Registered and saved Microsoft public-client ID: " + id);
            } else {
                System.out.println("Reusing existing saved Microsoft public-client ID: " + id);
            }
            System.out.println("This account may still need Minecraft/Xbox service authorization.");
        } else if (args.length == 1 && args[0].equals("auth")) {
            AuthManager.Profile p=AuthManager.shared().ensure(()->true);
            System.out.println("Minecraft Java authenticated as "+p.name+" ("+p.uuid+")");
            System.out.println("Session stored at "+AuthManager.shared().path());
        } else if (args.length == 1 && args[0].equals("whoami")) {
            AuthManager.Profile p=AuthManager.shared().peek();
            System.out.println(p==null?"No saved account session.":"Minecraft Java profile: "+p.name+" ("+p.uuid+")"+(p.valid()?" / cached token valid":" / token needs refreshing"));
        } else if (args.length == 1 && args[0].equals("logout")) {
            AuthManager.shared().logout();
            System.out.println("Saved AlphaModern credentials deleted. You'll be prompted to link the account next time.");
        } else if (args.length == 3 && args[0].equals("patch-world-dump")) {
            try(java.util.zip.ZipFile zip=new java.util.zip.ZipFile(args[1])) {
                java.util.zip.ZipEntry e=zip.getEntry("cj.class");
                if(e==null)throw new IOException("Original Alpha world cj.class missing");
                byte[] original;
                try(InputStream src=zip.getInputStream(e)){original=readAll(src);}
                byte[] changed=WorldLightPatch.patch(original);
                try(OutputStream dest=new FileOutputStream(args[2])){dest.write(changed);}
                System.out.println("Patched Alpha world light class saved: "+args[2]);
            }
        } else if (args.length == 3 && args[0].equals("patch-font-dump")) {
            try(java.util.zip.ZipFile zip=new java.util.zip.ZipFile(args[1])) {
                java.util.zip.ZipEntry e=zip.getEntry("js.class");
                if(e==null)throw new IOException("Original Alpha font renderer js.class missing");
                byte[] original;
                try(InputStream src=zip.getInputStream(e)){original=readAll(src);}
                byte[] changed=FontRendererPatch.patch(original);
                try(OutputStream dest=new FileOutputStream(args[2])){dest.write(changed);}
                System.out.println("Patched Alpha font renderer saved: "+args[2]);
            }
        } else if (args.length == 3 && args[0].equals("patch-ui-dump")) {
            try(java.util.zip.ZipFile zip = new java.util.zip.ZipFile(args[1])) {
                java.util.zip.ZipEntry e=zip.getEntry("mb.class");
                if(e==null)throw new IOException("Alpha 1.0.15 connecting GUI mb.class not found");
                byte[] original;
                try(InputStream in=zip.getInputStream(e)){original=readAll(in);}
                byte[] updated=InGamePatch.patch(original);
                try(OutputStream out=new FileOutputStream(args[2])){out.write(updated);}
                System.out.println("Patched in-game UI class saved to "+args[2]);
            }
        } else if (args.length == 3 && args[0].equals("patch-dump")) {
            java.util.zip.ZipFile zip = new java.util.zip.ZipFile(args[1]);
            byte[] original;
            try { java.util.zip.ZipEntry e=zip.getEntry("gn.class"); if(e==null)throw new IOException("Not a compatible Alpha 1.0.15 JAR (gn.class missing)");
                try(InputStream in=zip.getInputStream(e)){ original=readAll(in); }
            } finally { zip.close(); }
            byte[] changed = PatchSocket.patch(original);
            try (FileOutputStream fout=new FileOutputStream(args[2])) { fout.write(changed); }
            System.out.println("Patched gn.class written to "+args[2]);
        } else {
            System.out.println("AlphaModern / Protocol 776 — Java agent for Minecraft Alpha 1.0.15");
            System.out.println("Usage: -javaagent:AlphaModern-776-agent.jar  (in Alpha JVM arguments)");
            System.out.println("       java -jar AlphaModern-776-agent.jar configure <MICROSOFT_PUBLIC_CLIENT_ID>");
            System.out.println("       java -jar AlphaModern-776-agent.jar use-switch (select default Xbox-style sign in)");
            System.out.println("       java -jar AlphaModern-776-agent.jar register (OPTIONAL own Entra app via Azure CLI)");
            System.out.println("       java -jar AlphaModern-776-agent.jar auth");
            System.out.println("       java -jar AlphaModern-776-agent.jar whoami | logout");
            System.out.println("       java -jar AlphaModern-776-agent.jar ping <host> [port]");
            System.out.println("       java -jar AlphaModern-776-agent.jar patch-dump <alpha.jar> <gn.class>");
            System.out.println("       java -jar AlphaModern-776-agent.jar patch-ui-dump <alpha.jar> <mb.class>");
            System.out.println("       java -jar AlphaModern-776-agent.jar patch-font-dump <alpha.jar> <js.class>");
            System.out.println("       java -jar AlphaModern-776-agent.jar patch-world-dump <alpha.jar> <cj.class>");
            System.out.println("By default, this version uses the documented public Xbox/Switch device-code flow.");
            System.out.println("'register' is optional and only for users who explicitly want their own Entra application.");
            System.out.println("The published first-party client ID may be blocked by Microsoft at any time.");
            System.out.println("26.2 connection is EXPERIMENTAL, not a complete modern multiplayer implementation.");
        }
    }
    static byte[] readAll(InputStream stream) throws IOException {
        ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;
        while((n=stream.read(buf))>=0) b.write(buf,0,n);return b.toByteArray();
    }
    static class PatchSocket implements ClassFileTransformer {
        @Override public byte[] transform(ClassLoader loader, String name, Class<?> cls, ProtectionDomain domain, byte[] data) {
            if (!"gn".equals(name)) return null;
            try { byte[] transformed=patch(data); System.out.println(PREFIX+"Patched Alpha multiplayer connection constructor (gn)"); return transformed; }
            catch (Throwable ex) { System.err.println(PREFIX+"Failed to transform gn: "+ex); return null; }
        }
        static byte[] patch(byte[] bytes) throws IOException {
            DataInputStream in = new DataInputStream(new ByteArrayInputStream(bytes));
            ByteArrayOutputStream raw = new ByteArrayOutputStream(bytes.length+64);
            DataOutputStream out = new DataOutputStream(raw);
            if(in.readInt()!=0xCAFEBABE) throw new IOException("Not a JVM class");
            out.writeInt(0xCAFEBABE);out.writeShort(in.readUnsignedShort());out.writeShort(in.readUnsignedShort());
            int count=in.readUnsignedShort();out.writeShort(count);
            boolean found=false, signature=false;
            for(int i=1;i<count;i++) {
                int tag=in.readUnsignedByte();out.writeByte(tag);
                switch(tag) {
                    case 1: {
                        int len=in.readUnsignedShort();byte[] utf=new byte[len];in.readFully(utf);
                        String s=new String(utf,StandardCharsets.UTF_8);
                        if("java/net/Socket".equals(s)) { utf="alphamodern/BridgeSocket".getBytes(StandardCharsets.UTF_8);found=true; }
                        if("net/minecraft/client/Minecraft".equals(s)) signature=true;
                        out.writeShort(utf.length);out.write(utf);break;
                    }
                    case 3:case 4:case 9:case 10:case 11:case 12:case 17:case 18: {byte[] tmp=new byte[4];in.readFully(tmp);out.write(tmp);break;}
                    case 5:case 6: {byte[] tmp=new byte[8];in.readFully(tmp);out.write(tmp);i++;break;}
                    case 7:case 8:case 16:case 19:case 20: out.writeShort(in.readUnsignedShort());break;
                    case 15: out.writeByte(in.readUnsignedByte());out.writeShort(in.readUnsignedShort());break;
                    default: throw new IOException("Unknown constant pool tag "+tag);
                }
            }
            if(!found||!signature) throw new IOException("Expected Minecraft Alpha 1.0.15 gn.class, mismatched bytecode");
            out.write(readAll(in));out.flush();return raw.toByteArray();
        }
    }
}
