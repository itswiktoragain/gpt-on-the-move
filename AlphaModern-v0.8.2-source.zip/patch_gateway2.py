from pathlib import Path
p=Path('/mnt/data/alphamodern-0.7-src/src/alphamodern/Gateway.java')
s=p.read_text()
def replace(a,b):
 global s
 if a not in s:raise ValueError('MISSING '+a[:140])
 s=s.replace(a,b)
replace('''        private final LinkedHashMap<Long,byte[]> chunkPackets=new LinkedHashMap<Long,byte[]>(128,0.75f,true);
''','''        private final LinkedHashMap<Long,byte[]> chunkPackets=new LinkedHashMap<Long,byte[]>(128,0.75f,true);
        private final HashMap<Long,ChunkTranslator.LegacyChunk> renderedChunks=new HashMap<Long,ChunkTranslator.LegacyChunk>();
''')
replace('''                    chunkPackets.clear();cachedBytes=0;''','''                    chunkPackets.clear();renderedChunks.clear();cachedBytes=0;''')
replace('''            }else if(id==GameIds.CLIENTBOUND_FORGET_LEVEL_CHUNK) {
                final int x=in.readInt(),z=in.readInt();
                removeCachedChunk(x,z);''','''            }else if(id==GameIds.CLIENTBOUND_FORGET_LEVEL_CHUNK) {
                // 26.2 ChunkPos is a packed long with X in low 32 and Z in high 32.
                // v0.6.0 accidentally swapped them, leaving old chunks rendered.
                long packed=in.readLong();
                final int x=(int)packed,z=(int)(packed>>>32);
                removeCachedChunk(x,z);''')
replace('''                if(viewportReady&&alphaY>=0&&alphaY<128)legacy(53,o->{o.writeInt(x);o.writeByte(alphaY);o.writeInt(z);o.writeByte(oldId);o.writeByte(meta);});
            }else if(id==GameIds.CLIENTBOUND_SYSTEM_CHAT) {''','''                if(viewportReady&&alphaY>=0&&alphaY<128)legacy(53,o->{o.writeInt(x);o.writeByte(alphaY);o.writeInt(z);o.writeByte(oldId);o.writeByte(meta);});
            }else if(id==GameIds.CLIENTBOUND_SECTION_BLOCKS_UPDATE) {
                handleSectionBlockUpdates(in);
            }else if(id==GameIds.CLIENTBOUND_LIGHT_UPDATE) {
                handleLightUpdate(in);
            }else if(id==GameIds.CLIENTBOUND_SYSTEM_CHAT) {''')
replace('''            if(removed!=null)cachedBytes-=removed.length;
''','''            if(removed!=null)cachedBytes-=removed.length;
            renderedChunks.remove(chunkKey(x,z));
''')
replace('''                cachedBytes-=eldest.getValue().length;chunkPackets.remove(eldest.getKey());''','''                cachedBytes-=eldest.getValue().length;chunkPackets.remove(eldest.getKey());
                renderedChunks.remove(eldest.getKey());''')
replace('''                ChunkTranslator.sendChunk(new DataInputStream(new ByteArrayInputStream(bytes)),this,worldMinY,worldHeight,viewportBaseY);
                chunks++;''','''                ChunkTranslator.LegacyChunk chunk=ChunkTranslator.sendChunk(new DataInputStream(new ByteArrayInputStream(bytes)),this,worldMinY,worldHeight,viewportBaseY);
                renderedChunks.put(chunkKey(chunk.x,chunk.z),chunk);
                chunks++;''')
replace('''        private void unloadCachedChunks() throws IOException {
            for(Long key:chunkPackets.keySet()) {''','''        private void unloadCachedChunks() throws IOException {
            renderedChunks.clear();
            for(Long key:chunkPackets.keySet()) {''')
replace('''        private void sendLegacyChat(String modern) throws IOException {''','''        private void handleLightUpdate(DataInputStream in) throws IOException {
            int cx=Wire.var(in),cz=Wire.var(in);
            ChunkTranslator.LegacyChunk chunk=renderedChunks.get(chunkKey(cx,cz));
            if(!viewportReady || chunk==null)return;
            try {
                ChunkTranslator.updateLight(cx,cz,in,chunk,worldMinY,worldHeight,viewportBaseY);
                ChunkTranslator.sendOldChunk(chunk,this,false);
            }catch(IOException e){System.err.println(AlphaModernAgent.PREFIX+"Ignored incompatible light update "+cx+","+cz+": "+e.getMessage());}
        }
        private void handleSectionBlockUpdates(DataInputStream in) throws IOException {
            long section=in.readLong();
            int sx=(int)(section>>42), sz=(int)(section<<22>>42), sy=(int)(section<<44>>44);
            int count=Wire.var(in);
            if(count<0||count>4096)throw new IOException("Invalid section block update count "+count);
            for(int i=0;i<count;i++) {
                long entry=Wire.varLong(in);
                int state=(int)(entry>>>12),local=(int)(entry&4095);
                int x=(sx<<4)|((local>>>8)&15);
                int z=(sz<<4)|((local>>>4)&15);
                int y=(sy<<4)|(local&15);
                int projected=y-viewportBaseY;
                if(!viewportReady||projected<0||projected>=128)continue;
                int oldId=ChunkTranslator.toOld(state),meta=ChunkTranslator.toMeta(state);
                legacy(53,o->{o.writeInt(x);o.writeByte(projected);o.writeInt(z);o.writeByte(oldId);o.writeByte(meta);});
                ChunkTranslator.LegacyChunk chunk=renderedChunks.get(chunkKey(sx,sz));
                if(chunk!=null) {
                    int localIndex=(((local>>>8)&15)<<11)|(((local>>>4)&15)<<7)|projected;
                    chunk.data[localIndex]=(byte)oldId;
                    int pos=ChunkTranslator.META_OFFSET+(localIndex>>>1);
                    if((localIndex&1)==0)chunk.data[pos]=(byte)((chunk.data[pos]&0xf0)|(meta&15));
                    else chunk.data[pos]=(byte)((chunk.data[pos]&15)|((meta&15)<<4));
                }
            }
        }
        private void sendLegacyChat(String modern) throws IOException {''')
p.write_text(s)
