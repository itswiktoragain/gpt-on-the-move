from pathlib import Path
p=Path('/mnt/data/alphamodern-0.7-src/src/alphamodern/Gateway.java')
s=p.read_text()
def replace(old, new):
    global s
    if old not in s:
        raise ValueError('MISSING REPLACE: '+old[:160])
    s=s.replace(old,new)

replace('o.writeUTF("26.2 bridge: "+shorten(problem,210));','o.writeUTF("AlphaModern: "+shorten(problem,210));')
replace('        private long chunks;\n', '''        private long chunks;
        // Modern 26.2 dimensions are taller than Alpha's 128-block renderer.
        // Keep a small cache so changing vertical windows can reproject chunks.
        private static final int MAX_CACHED_CHUNKS=192, MAX_CACHE_BYTES=32*1024*1024;
        private final LinkedHashMap<Long,byte[]> chunkPackets=new LinkedHashMap<Long,byte[]>(128,0.75f,true);
        private long cachedBytes;
        private volatile boolean viewportReady;
        private volatile int viewportBaseY;
''')
replace('                    System.out.println(AlphaModernAgent.PREFIX+"Dimension "+dimension+" height="+worldHeight+" minY="+worldMinY);', '''                    System.out.println(AlphaModernAgent.PREFIX+"Dimension "+dimension+" height="+worldHeight+" minY="+worldMinY);
                    viewportReady=false;
                    chunkPackets.clear();cachedBytes=0;
''')
replace('''                posX=x;posY=y;posZ=z;yaw=yrot;pitch=xrot;
                wire.send(GameIds.SERVERBOUND_ACCEPT_TELEPORTATION,o->Wire.var(o,teleport));
                final double fx=x,fy=y,fz=z;final float fyaw=yrot,fpitch=xrot;
                if(alphaLoggedIn)legacy(13,o->{o.writeDouble(fx);o.writeDouble(fy);o.writeDouble(fy+1.62);o.writeDouble(fz);o.writeFloat(fyaw);o.writeFloat(fpitch);o.writeBoolean(false);});''', '''                posX=x;posY=y;posZ=z;yaw=yrot;pitch=xrot;
                wire.send(GameIds.SERVERBOUND_ACCEPT_TELEPORTATION,o->Wire.var(o,teleport));
                if(!viewportReady || VerticalViewport.shouldRecenter(y,viewportBaseY,worldMinY,worldHeight)) {
                    int newBase=VerticalViewport.chooseBase(y,worldMinY,worldHeight);
                    boolean changed=viewportReady && viewportBaseY!=newBase;
                    viewportBaseY=newBase;viewportReady=true;
                    System.out.println(AlphaModernAgent.PREFIX+"Vertical viewport: server Y="+y+" Alpha Y="+(y-newBase)+" range="+newBase+".."+(newBase+127));
                    if(changed)unloadCachedChunks();
                    resendCachedChunks();
                }
                final double fx=x,fy=y-viewportBaseY,fz=z;final float fyaw=yrot,fpitch=xrot;
                if(alphaLoggedIn)legacy(13,o->{o.writeDouble(fx);o.writeDouble(fy);o.writeDouble(fy+1.62);o.writeDouble(fz);o.writeFloat(fyaw);o.writeFloat(fpitch);o.writeBoolean(false);});''')
replace('''            }else if(id==GameIds.CLIENTBOUND_LEVEL_CHUNK_WITH_LIGHT) {
                if(alphaLoggedIn){
                    try {ChunkTranslator.sendChunk(in,this,worldMinY,worldHeight);chunks++;}
                    catch(Exception e){System.err.println(AlphaModernAgent.PREFIX+"Skipped incompatible chunk: "+e.getMessage());}
                }
            }else if(id==GameIds.CLIENTBOUND_FORGET_LEVEL_CHUNK) {
                final int x=in.readInt(),z=in.readInt();if(alphaLoggedIn)legacy(50,o->{o.writeInt(x);o.writeInt(z);o.writeBoolean(false);});''', '''            }else if(id==GameIds.CLIENTBOUND_LEVEL_CHUNK_WITH_LIGHT) {
                if(alphaLoggedIn)receiveChunk(in);
            }else if(id==GameIds.CLIENTBOUND_FORGET_LEVEL_CHUNK) {
                final int x=in.readInt(),z=in.readInt();
                removeCachedChunk(x,z);
                if(alphaLoggedIn&&viewportReady)legacy(50,o->{o.writeInt(x);o.writeInt(z);o.writeBoolean(false);});''')
replace('''                if(y>=0&&y<128)legacy(53,o->{o.writeInt(x);o.writeByte(y);o.writeInt(z);o.writeByte(oldId);o.writeByte(meta);});
            }else if(id==GameIds.CLIENTBOUND_SYSTEM_CHAT) {
                if(alphaLoggedIn)legacy(3,o->o.writeUTF(shorten("[26.2] "+debugText(in),220)));''', '''                final int alphaY=y-viewportBaseY;
                if(viewportReady&&alphaY>=0&&alphaY<128)legacy(53,o->{o.writeInt(x);o.writeByte(alphaY);o.writeInt(z);o.writeByte(oldId);o.writeByte(meta);});
            }else if(id==GameIds.CLIENTBOUND_SYSTEM_CHAT) {
                if(alphaLoggedIn) {
                    final String message=TextComponent.readFormatted(in);
                    boolean overlay=in.available()>0 && in.readBoolean();
                    if(!overlay)sendLegacyChat(message);
                }
            }else if(id==GameIds.CLIENTBOUND_DISGUISED_CHAT) {
                if(alphaLoggedIn)sendLegacyChat(TextComponent.readFormatted(in));''')
replace('''        synchronized void legacy(int id,Wire.Writer writer) throws IOException {''','''        private long chunkKey(int x,int z) {return ((long)x<<32)|(z&0xffffffffL);}
        private void removeCachedChunk(int x,int z) {
            byte[] removed=chunkPackets.remove(chunkKey(x,z));
            if(removed!=null)cachedBytes-=removed.length;
        }
        private void receiveChunk(DataInputStream in) throws IOException {
            final byte[] bytes=AlphaModernAgent.readAll(in);
            if(bytes.length<8 || bytes.length>1024*1024) {
                System.err.println(AlphaModernAgent.PREFIX+"Discarded oversized/invalid chunk packet: "+bytes.length);
                return;
            }
            DataInputStream head=new DataInputStream(new ByteArrayInputStream(bytes));
            int x=head.readInt(),z=head.readInt();
            removeCachedChunk(x,z);
            long key=chunkKey(x,z);
            chunkPackets.put(key,bytes);cachedBytes+=bytes.length;
            while(chunkPackets.size()>MAX_CACHED_CHUNKS || cachedBytes>MAX_CACHE_BYTES) {
                Map.Entry<Long,byte[]> eldest=chunkPackets.entrySet().iterator().next();
                cachedBytes-=eldest.getValue().length;chunkPackets.remove(eldest.getKey());
            }
            if(viewportReady)publishChunk(bytes);
        }
        private void publishChunk(byte[] bytes) throws IOException {
            try {
                ChunkTranslator.sendChunk(new DataInputStream(new ByteArrayInputStream(bytes)),this,worldMinY,worldHeight,viewportBaseY);
                chunks++;
            } catch(Exception e) {
                System.err.println(AlphaModernAgent.PREFIX+"Skipped incompatible chunk: "+e.getMessage());
            }
        }
        private void unloadCachedChunks() throws IOException {
            for(Long key:chunkPackets.keySet()) {
                final int x=(int)(key>>32),z=(int)(long)key;
                legacy(50,o->{o.writeInt(x);o.writeInt(z);o.writeBoolean(false);});
            }
        }
        private void resendCachedChunks() throws IOException {
            for(byte[] b:new ArrayList<byte[]>(chunkPackets.values()))publishChunk(b);
        }
        private void sendLegacyChat(String modern) throws IOException {
            if(modern==null || modern.trim().isEmpty())return;
            String[] lines=modern.split("\\n",-1);
            for(String line:lines) {
                if(line.length()==0)continue;
                int offset=0;
                // Keep packets small enough for the Alpha renderer and MUTF-8 framing.
                while(offset<line.length()) {
                    int last=Math.min(offset+300,line.length());
                    if(last<line.length() && last>offset && line.charAt(last-1)=='\\u00a7')last--;
                    final String part=line.substring(offset,last);
                    legacy(3,o->o.writeUTF(part));
                    offset=last;
                }
            }
        }
        synchronized void legacy(int id,Wire.Writer writer) throws IOException {''')
replace('''                        case 3: {String chat=alphaIn.readUTF();if(playing)sendChat(chat);break;}''','''                        case 3: {String chat=alphaIn.readUTF();
                            if(chat.equalsIgnoreCase("/amdebug")){
                                String info="AlphaModern: server Y="+String.format(java.util.Locale.ROOT,"%.1f",posY)+
                                    ", Alpha Y="+String.format(java.util.Locale.ROOT,"%.1f",posY-viewportBaseY)+
                                    ", shown="+viewportBaseY+".."+(viewportBaseY+127)+", chunks="+chunkPackets.size();
                                sendLegacyChat(info);
                            }else if(playing)sendChat(chat);
                            break;}''')
replace('''                        case 10: {boolean ground=alphaIn.readBoolean();if(playing)wire.send(GameIds.SERVERBOUND_MOVE_PLAYER_STATUS_ONLY,o->o.writeByte(ground?1:0));break;}''','''                        case 10: {boolean ground=alphaIn.readBoolean();if(playing&&viewportReady)wire.send(GameIds.SERVERBOUND_MOVE_PLAYER_STATUS_ONLY,o->o.writeByte(ground?1:0));break;}''')
replace('''                        case 11: {double x=alphaIn.readDouble(),y=alphaIn.readDouble(),stance=alphaIn.readDouble(),z=alphaIn.readDouble();boolean ground=alphaIn.readBoolean();
                            posX=x;posY=y;posZ=z;
                            if(playing)wire.send(GameIds.SERVERBOUND_MOVE_PLAYER_POS,o->{o.writeDouble(x);o.writeDouble(y);o.writeDouble(z);o.writeByte(ground?1:0);});break;}''','''                        case 11: {double x=alphaIn.readDouble(),y=alphaIn.readDouble(),stance=alphaIn.readDouble(),z=alphaIn.readDouble();boolean ground=alphaIn.readBoolean();
                            double serverY=y+viewportBaseY;
                            posX=x;posY=serverY;posZ=z;
                            if(playing&&viewportReady)wire.send(GameIds.SERVERBOUND_MOVE_PLAYER_POS,o->{o.writeDouble(x);o.writeDouble(serverY);o.writeDouble(z);o.writeByte(ground?1:0);});break;}''')
replace('''                            if(playing)wire.send(GameIds.SERVERBOUND_MOVE_PLAYER_ROT,o->{o.writeFloat(yrot);o.writeFloat(xrot);o.writeByte(ground?1:0);});break;}''','''                            if(playing&&viewportReady)wire.send(GameIds.SERVERBOUND_MOVE_PLAYER_ROT,o->{o.writeFloat(yrot);o.writeFloat(xrot);o.writeByte(ground?1:0);});break;}''')
replace('''                        case 13: {double x=alphaIn.readDouble(),y=alphaIn.readDouble(),stance=alphaIn.readDouble(),z=alphaIn.readDouble();float yrot=alphaIn.readFloat(),xrot=alphaIn.readFloat();boolean ground=alphaIn.readBoolean();
                            posX=x;posY=y;posZ=z;yaw=yrot;pitch=xrot;
                            if(playing)wire.send(GameIds.SERVERBOUND_MOVE_PLAYER_POS_ROT,o->{o.writeDouble(x);o.writeDouble(y);o.writeDouble(z);o.writeFloat(yrot);o.writeFloat(xrot);o.writeByte(ground?1:0);});break;}''','''                        case 13: {double x=alphaIn.readDouble(),y=alphaIn.readDouble(),stance=alphaIn.readDouble(),z=alphaIn.readDouble();float yrot=alphaIn.readFloat(),xrot=alphaIn.readFloat();boolean ground=alphaIn.readBoolean();
                            double serverY=y+viewportBaseY;
                            posX=x;posY=serverY;posZ=z;yaw=yrot;pitch=xrot;
                            if(playing&&viewportReady)wire.send(GameIds.SERVERBOUND_MOVE_PLAYER_POS_ROT,o->{o.writeDouble(x);o.writeDouble(serverY);o.writeDouble(z);o.writeFloat(yrot);o.writeFloat(xrot);o.writeByte(ground?1:0);});break;}''')
replace('''                                wire.send(GameIds.SERVERBOUND_PLAYER_ACTION,o->{Wire.var(o,modernAction);o.writeLong(Wire.pos(x,y,z));o.writeByte(face<6?face:1);Wire.var(o,0);});''','''                                final int serverY=y+viewportBaseY;
                                wire.send(GameIds.SERVERBOUND_PLAYER_ACTION,o->{Wire.var(o,modernAction);o.writeLong(Wire.pos(x,serverY,z));o.writeByte(face<6?face:1);Wire.var(o,0);});''')
replace('''                        case 18: {alphaIn.readInt();alphaIn.readUnsignedByte();break;}''','''                        case 18: {alphaIn.readInt();alphaIn.readUnsignedByte();break;}''')
p.write_text(s)
