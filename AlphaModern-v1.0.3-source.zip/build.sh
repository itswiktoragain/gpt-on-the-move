#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p build/classes
javac -source 8 -target 8 -d build/classes src/alphamodern/*.java
cp src/alphamodern/blockmap.rle build/classes/alphamodern/blockmap.rle
cp src/alphamodern/itemmap.rle build/classes/alphamodern/itemmap.rle
jar cfm AlphaModern-776-agent.jar MANIFEST.MF -C build/classes .
if command -v sha256sum >/dev/null 2>&1; then sha256sum AlphaModern-776-agent.jar; fi
