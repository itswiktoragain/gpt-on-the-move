package alphamodern;

import java.io.*;
import java.lang.reflect.*;
import java.util.*;

/** Partial server-authoritative 26.2 player inventory adapter for Alpha 1.0.15.
 * Server equipment/slot snapshots are the source of truth. The original Alpha
 * survival inventory UI is used; IDs that do not exist in Alpha are displayed
 * using a registered stone placeholder to avoid invalid item renderer IDs.
 * Supports common custom names, lore, model data and enchantment component
 * payloads by safely skipping them; exotic components and arbitrary container
 * menus are still unsupported.
 */
public final class InventoryMirror {
    static final class Stack {
        final int modernId,alphaId,count;
        Stack(int id,int count){this.modernId=id;this.alphaId=ItemMapping.toAlpha(id);this.count=count;}
    }
    private static final class UnsupportedComponent extends IOException {
        final Stack approximate;
        UnsupportedComponent(Stack stack){super("unsupported modern item data component (only simple stacks can be decoded)");approximate=stack;}
    }
    private static volatile Object client;
    private static volatile InventoryMirror active;
    private final Gateway.Session session;
    private final Stack[] contents = new Stack[46]; // Window 0: crafting, armor, main, hotbar, offhand
    private int stateId;
    private int selected=-1;
    private int sentSelected=-1;
    private Stack cursor;
    private boolean received;
    private int snapshots;
    private int unsupported;
    private int translatedSlots;
    InventoryMirror(Gateway.Session session){this.session=session;}
    public static void bind(Object mc) {
        client=mc;
        InventoryMirror inv=active;
        if(inv!=null)inv.apply();
    }
    void activate(){active=this;apply();}
    void deactivate(){if(active==this)active=null;}

    static Stack readSlot(DataInputStream in) throws IOException {return readSlot(in,0);}
    static Stack readSlot(DataInputStream in,int depth) throws IOException {
        if(depth>8)throw new IOException("Nested item slot too deep");
        int count=Wire.var(in);
        if(count<=0)return null;
        if(count>999)throw new IOException("Invalid item count "+count);
        int id=Wire.var(in);
        if(id<0||id>100000)throw new IOException("Invalid item id "+id);
        Stack result=new Stack(id,Math.min(count,64));
        int adds=Wire.var(in),removals=Wire.var(in);
        if(adds<0||adds>256||removals<0||removals>256)throw new IOException("Invalid component counts");
        for(int j=0;j<adds;j++) {
            int componentId=Wire.var(in);
            try {ItemComponentSkipper.skip(in,componentId,depth);} 
            catch(IOException unsupported){throw new UnsupportedComponent(result);}
        }
        for(int j=0;j<removals;j++)Wire.var(in); // Removed IDs are only VarInts.
        return result;
    }
    synchronized void full(DataInputStream in) throws IOException {
        int window=Wire.var(in),state=Wire.var(in),count=Wire.var(in);
        if(count<0||count>1024)throw new IOException("Invalid inventory slot count "+count);
        if(window!=0)return; // Not yet a supported legacy container screen.
        Stack[] incoming=new Stack[count];
        try {
            for(int j=0;j<count;j++)incoming[j]=readSlot(in);
            Stack newCursor=readSlot(in);
            Arrays.fill(contents,null);
            System.arraycopy(incoming,0,contents,0,Math.min(contents.length,incoming.length));
            stateId=state;cursor=newCursor;received=true;snapshots++;translatedSlots+=count;
            apply();
        }catch(UnsupportedComponent unsup){
            unsupported++;
            if(unsupported<=3)System.err.println(AlphaModernAgent.PREFIX+
                "Player inventory contains an unsupported modern component; skipping full snapshot safely (no slot misalignment)");
        }
    }
    synchronized void one(DataInputStream in) throws IOException {
        int window=Wire.var(in),state=Wire.var(in),slot=in.readShort();
        if(window!=0)return;
        Stack value;
        try {value=readSlot(in);}catch(UnsupportedComponent e){value=e.approximate;unsupported++;}
        stateId=state;
        if(slot>=0&&slot<contents.length){contents[slot]=value;received=true;translatedSlots++;apply();}
    }
    synchronized void direct(DataInputStream in) throws IOException {
        // Direct player inventory order: hotbar 0-8, main 9-35, armor 36-39, offhand 40.
        int slot=Wire.var(in);
        Stack value;
        try {value=readSlot(in);}catch(UnsupportedComponent e){value=e.approximate;unsupported++;}
        int mapped=slot>=0&&slot<=8?slot+36:slot>=9&&slot<=35?slot:slot>=36&&slot<=39?slot-31:slot==40?45:-1;
        if(mapped>=0){contents[mapped]=value;received=true;translatedSlots++;apply();}
    }
    synchronized void carried(DataInputStream in) throws IOException {
        try {cursor=readSlot(in);}catch(UnsupportedComponent e){cursor=e.approximate;unsupported++;}
        apply();
    }
    synchronized void selected(DataInputStream in) throws IOException {
        int index=Wire.var(in);
        if(index>=0&&index<9){selected=index;sentSelected=index;apply();}
    }
    synchronized int stateId(){return stateId;}
    synchronized int updates(){return translatedSlots;}
    synchronized int unsupported(){return unsupported;}
    synchronized boolean hasSnapshot(){return received;}
    synchronized Stack item(int slot){return contents[slot];}
    private static Object inventory() throws ReflectiveOperationException {
        Object mc=client;
        if(mc==null)return null;
        Object player=mc.getClass().getField("g").get(mc);
        return player==null?null:player.getClass().getField("b").get(player);
    }
    private static Object create(Object inv,Stack item) throws ReflectiveOperationException {
        if(item==null||item.alphaId==0)return null;
        Class<?> eo=Class.forName("eo",false,inv.getClass().getClassLoader());
        return eo.getConstructor(int.class,int.class,int.class).newInstance(item.alphaId,item.count,0);
    }
    synchronized void apply() {
        if(!received)return;
        try {
            Object inv=inventory();if(inv==null)return;
            Object[] main=(Object[])inv.getClass().getField("a").get(inv);
            Object[] armor=(Object[])inv.getClass().getField("b").get(inv);
            Object[] craft=(Object[])inv.getClass().getField("c").get(inv);
            for(int i=0;i<36;i++)main[i]=create(inv,contents[i<9?36+i:i]);
            for(int i=0;i<4;i++)armor[i]=create(inv,contents[8-i]);
            for(int i=0;i<4;i++)craft[i]=create(inv,contents[1+i]);
            if(selected>=0)inv.getClass().getField("d").setInt(inv,selected);
        }catch(ReflectiveOperationException ex){
            if(unsupported++==0)System.err.println(AlphaModernAgent.PREFIX+"Could not mirror Alpha inventory: "+ex);
        }
    }
    /** Polling the selected hotbar index is required: Alpha protocol 13 sends
     * the selected item ID (not a slot), so its 0x10 packet cannot be forwarded. */
    void pollHotbar() throws IOException {
        if(!received)return;
        try {
            Object inv=inventory();if(inv==null)return;
            int actual=inv.getClass().getField("d").getInt(inv);
            if(actual>=0&&actual<=8 && actual!=sentSelected) {
                sentSelected=actual;
                final int send=actual;
                session.sendHotbar(send);
            }
        }catch(ReflectiveOperationException ex){/* UI might be changing worlds; retry later */}
    }
    /** Called on Alpha's original inventory click handler, AFTER the local
     * action. Let the server evaluate the click and immediately restore the
     * server snapshot, preventing a locally invented item from persisting. */
    public static void click(Object gui,int mouseX,int mouseY,int button) {
        InventoryMirror m=active;
        if(m==null||!m.received||button<0||button>1)return;
        try {
            if(!"lc".equals(gui.getClass().getName()))return;
            Class<?> type=gui.getClass().getSuperclass();
            Field listField=type.getDeclaredField("i");listField.setAccessible(true);
            @SuppressWarnings("unchecked") List<Object> slots=(List<Object>)listField.get(gui);
            Object playerInventory=inventory();
            if(playerInventory==null)return;
            Field owned=Class.forName("dl",false,gui.getClass().getClassLoader()).getField("d");
            for(Object slot:slots) {
                Object owner=owned.get(slot);
                if(owner!=playerInventory)continue;
                Method hit=slot.getClass().getMethod("a",int.class,int.class);
                if(!Boolean.TRUE.equals(hit.invoke(slot,mouseX,mouseY)))continue;
                int internal=slot.getClass().getField("a").getInt(slot);
                int modern=internal<36?(internal<9?36+internal:internal):44-internal; // armor 36..39 maps 8..5
                if(modern<0||modern>=45)break;
                m.session.sendInventoryClick(modern,button,m.stateId());
                break;
            }
        }catch(Exception error){
            if(m.unsupported++<3)System.err.println(AlphaModernAgent.PREFIX+"Inventory click adapter: "+error);
        }finally{
            m.apply();
            // Alpha uses its own cursor object; clear a speculative cursor when
            // server has none. Server may issue Set Cursor Item after the click.
            try {
                Class<?> dy=Class.forName("dy",false,gui.getClass().getClassLoader());
                Field held=dy.getDeclaredField("l");held.setAccessible(true);
                held.set(gui,m.cursor==null?null:create(inventory(),m.cursor));
            }catch(Exception ignored){}
        }
    }
}
