#!/bin/sh
set -eu
cd "$(dirname "$0")"
sh build.sh
mkdir -p build/test-classes
javac -source 8 -target 8 -cp build/classes -d build/test-classes tests/alphamodern/*.java
java -cp build/classes:build/test-classes alphamodern.TerrainRegressionTest
java -cp build/classes:build/test-classes alphamodern.ViewportTest
java -cp build/classes:build/test-classes alphamodern.CrashAndCompatibilityTest "${ALPHA_JAR:-}"
java -cp build/classes:build/test-classes alphamodern.TextComponentTest
java -cp build/classes:build/test-classes alphamodern.BridgeIntegrationTest
java -cp build/classes:build/test-classes alphamodern.TallWorldIntegrationTest
java -cp build/classes:build/test-classes alphamodern.AuthIntegrationTest
java -cp build/classes:build/test-classes alphamodern.SwitchAuthTest
java -cp build/classes:build/test-classes alphamodern.AuthOverlayTest
java -cp build/classes:build/test-classes alphamodern.AzureRegistrationTest
