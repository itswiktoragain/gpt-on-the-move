package alphamodern;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.Deflater;

/**
 * Minecraft 26.2 (protocol 776) paletted sections -> Alpha 1.0.15 map chunks.
 *
 * The key 26.x difference: every section has BOTH nonEmptyBlockCount and fluidCount
 * (unsigned shorts). Reading only the first shifted the palette by two bytes and
 * caused the floating black blocks in v0.5.0.
 *
 * Coordinate conversion: modern sections are YZX with X fastest, Alpha's on-wire
 * block arrays are XZY with Y fastest. Alpha can only represent 128 blocks at once, so the caller supplies a vertical window.
 */
final class ChunkTranslator {
    static final int HEIGHT = 128, BLOCKS = 16*16*HEIGHT, OLD_LENGTH = BLOCKS*5/2;
    static final int META_OFFSET = BLOCKS;
    static final int BLOCKLIGHT_OFFSET = BLOCKS + BLOCKS/2;
    static final int SKYLIGHT_OFFSET = BLOCKS + BLOCKS;
    static final int UNKNOWN = Integer.getInteger("alpha.modern.unknownBlock", 1);
    private static final int[] STATE_MAP = loadStates();
    private static int lightingWarnings;
    private static int fallbackWarnings;
    // A modern server can render with more elaborate lighting than Alpha 1.0.15.
    // Prevent pitch-black silhouettes in custom lobbies; configurable to 0.
    private static final int AMBIENT_SKY=Math.max(0,Math.min(15,Integer.getInteger("alpha.modern.ambientLight",8)));

    private ChunkTranslator() {}

    /** Packed value: lower byte is Alpha block ID, next nibble is metadata. */
    static int toOldPacked(int globalState) {
        if (globalState >= 0 && globalState < STATE_MAP.length)
            return CollisionMapping.correct(globalState,BlockStateMapper.apply(globalState,STATE_MAP[globalState]));
        return Math.max(0, Math.min(255, UNKNOWN));
    }
    static int toOld(int globalState) {return toOldPacked(globalState) & 255;}
    static int toMeta(int globalState) {return (toOldPacked(globalState) >>> 8) & 15;}

    /** Checked-in state-ID intervals from minecraft-data-26.2 (protocol 776).
     *  All unspecified states default to stone. Air/vegetation map to air.
     *  See README for dataset attribution and how the approximations work.
     */
    private static int[] loadStates() {
        int[] values = new int[32366];
        Arrays.fill(values, 1);
        try (InputStream in = ChunkTranslator.class.getResourceAsStream("blockmap.rle")) {
            if (in == null) throw new IOException("Missing state map resource blockmap.rle");
            byte[] bytes = AlphaModernAgent.readAll(in);
            String text = new String(bytes, StandardCharsets.US_ASCII).trim();
            for (String part : text.split(",")) {
                int dash = part.indexOf('-'), colon = part.indexOf(':');
                if (dash < 1 || colon < dash+2) throw new IOException("Malformed block map range: " + part);
                int start = Integer.parseInt(part.substring(0,dash),36);
                int end = Integer.parseInt(part.substring(dash+1,colon),36);
                int mapped = Integer.parseInt(part.substring(colon+1),36);
                if (start < 0 || end < start || end >= values.length || (mapped & ~0xfff) != 0)
                    throw new IOException("Invalid mapping interval: " + part);
                // Fences were added after Alpha 1.0.15: show a safe planks block.
                if ((mapped & 255) == 85) mapped = 5;
                Arrays.fill(values, start, end+1, mapped);
            }
            return values;
        } catch (Exception e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    static final class LegacyChunk {
        final int x,z;
        final byte[] data;
        LegacyChunk(int x,int z,byte[] data){this.x=x;this.z=z;this.data=data;}
    }
    static LegacyChunk sendChunk(DataInputStream input, Gateway.Session dest, int minY, int fullHeight, int viewBaseY) throws IOException {
        LegacyChunk chunk = decodeChunk(input,minY,fullHeight,viewBaseY);
        sendOldChunk(chunk,dest,true);
        return chunk;
    }
    static void sendOldChunk(LegacyChunk chunk, Gateway.Session dest, boolean preChunk) throws IOException {
        byte[] zip = compress(chunk.data);
        if(preChunk)dest.legacy(50,o->{o.writeInt(chunk.x);o.writeInt(chunk.z);o.writeBoolean(true);});
        dest.legacy(51,o->{o.writeInt(chunk.x*16);o.writeShort(0);o.writeInt(chunk.z*16);
            o.writeByte(15);o.writeByte(127);o.writeByte(15);o.writeInt(zip.length);o.write(zip);});
    }
    static LegacyChunk decodeChunk(DataInputStream input, int minY, int fullHeight) throws IOException {
        return decodeChunk(input,minY,fullHeight,0);
    }
    static LegacyChunk decodeChunk(DataInputStream input, int minY, int fullHeight, int viewBaseY) throws IOException {
        int cx = input.readInt(), cz = input.readInt();
        int hm = Wire.var(input);
        if (hm < 0 || hm > 32) throw new IOException("Invalid heightmap count " + hm);
        for (int h=0;h<hm;h++) {
            Wire.var(input); // numeric heightmap registry type
            int len = Wire.var(input);
            if (len < 0 || len > 2048) throw new IOException("Invalid heightmap long count " + len);
            for (int i=0;i<len;i++) input.readLong();
        }
        int encodedLen = Wire.var(input);
        if (encodedLen < 0 || encodedLen > 2*1024*1024) throw new IOException("Invalid chunk length " + encodedLen);
        byte[] raw = new byte[encodedLen];
        try {input.readFully(raw);}
        catch(EOFException e) {throw new IOException("Truncated chunk ("+cx+","+cz+") data: expected "+encodedLen+
            " bytes after heightmaps",e);}
        if (fullHeight < 128 || fullHeight > 1024 || (fullHeight & 15) != 0 || (minY & 15) != 0 ||
            (viewBaseY & 15) != 0 || viewBaseY < minY || viewBaseY + HEIGHT > minY + fullHeight)
            throw new IOException("Invalid dimension minY=" + minY + " height=" + fullHeight);

        // A genuine 26.2 server uses two unsigned shorts per section and
        // no packed-long array length. Some multi-version servers/proxies send
        // older section variants even after advertising protocol 776. Probe
        // alternative layouts only after exact-byte-accounted vanilla parsing
        // fails. Never publish a partially decoded chunk.
        IOException standardError=null;
        byte[] old=null;
        int[][] profiles={
            {sectionCount(fullHeight),minY,1,0},          // vanilla 26.2
            {sectionCount(fullHeight),minY,0,0},          // pre-26.1 sections via proxy
            {sectionCount(fullHeight),minY,1,1},          // old palette long count
            {sectionCount(fullHeight),minY,0,1},
        };
        if(fullHeight!=256 && minY!=0) {
            // Some proxies send fixed 256-high chunks for a legacy backend.
            int[][] extended=Arrays.copyOf(profiles,profiles.length+4);
            extended[4]=new int[]{16,0,1,0};
            extended[5]=new int[]{16,0,0,0};
            extended[6]=new int[]{16,0,1,1};
            extended[7]=new int[]{16,0,0,1};
            profiles=extended;
        }
        int selected=0;
        for(int i=0;i<profiles.length;i++) {
            int[] mode=profiles[i];
            try {
                old=decodeSections(raw,mode[0],mode[1],viewBaseY,mode[2]!=0,mode[3]!=0);
                selected=i;break;
            } catch(IOException e) {
                if(i==0)standardError=e;
            }
        }
        if(old==null)throw new IOException("chunk ("+cx+","+cz+") could not decode "+
            sectionCount(fullHeight)+" sections of "+raw.length+" bytes; standard layout: "+standardError,standardError);
        if(selected!=0 && fallbackWarnings++<6) {
            int[] mode=profiles[selected];
            System.err.println(AlphaModernAgent.PREFIX+"Using compatibility chunk layout for "+cx+","+cz+
                ": sections="+mode[0]+" sourceMinY="+mode[1]+" fluidCount="+(mode[2]!=0)+" paletteSizePrefix="+(mode[3]!=0));
        }

        // Block entities and 26.2 light data follow the section blob. If they are
        // malformed, keep the (safe, daylight) fallback, not corrupt geometry.
        if (input.available()>0) {
            try {
                byte[] lightOld=new byte[BLOCKS]; // 16K block + 16K sky
                Arrays.fill(lightOld, BLOCKS/2, lightOld.length, (byte)0xff);
                readLighting(input,lightOld,minY,sectionCount(fullHeight),viewBaseY);
                System.arraycopy(lightOld,0,old,BLOCKLIGHT_OFFSET,lightOld.length);
            } catch(Exception e) {
                synchronized(ChunkTranslator.class) {
                    if(lightingWarnings++<3)
                        System.err.println(AlphaModernAgent.PREFIX+"Light data unavailable; using daylight fallback: "+e.getMessage());
                }
            }
        }
        return new LegacyChunk(cx,cz,old);
    }
    private static int sectionCount(int height) {return height / 16;}
    private static boolean isAirState(int state) {return state==0||state==15292||state==15293;}
    private static byte[] decodeSections(byte[] raw,int sectionCount,int sourceMinY,int viewBaseY,
                                         boolean hasFluidCount,boolean prefixedLongs) throws IOException {
        DataInputStream sections = new DataInputStream(new ByteArrayInputStream(raw));
        byte[] old=new byte[OLD_LENGTH];
        Arrays.fill(old,SKYLIGHT_OFFSET,old.length,(byte)0xff);
        for(int s=0;s<sectionCount;s++) {
            int before=raw.length-sections.available();
            String stage="section header";
            try {
                int nonEmpty=sections.readUnsignedShort();
                int fluids=hasFluidCount?sections.readUnsignedShort():0;
                if(nonEmpty>4096 || fluids>4096)throw new IOException("Invalid counters "+nonEmpty+","+fluids);
                stage="block palette";
                int[] states=readPalette(sections,4096,8,18,prefixedLongs);
                // Refuse a deceptively aligned but incorrectly interpreted fallback.
                // A homogeneous section must have either 0 non-air blocks or 4096.
                // This rejects older no-fluid/prefixed data that accidentally looks
                // like a modern two-counter section but decodes to air everywhere.
                int first=states[0];
                boolean homogeneous=true;
                for(int j=1;j<states.length;j++)if(states[j]!=first){homogeneous=false;break;}
                if(homogeneous) {
                    int expected=isAirState(first)?0:4096;
                    if(nonEmpty!=expected)throw new IOException("Homogeneous block palette "+first+
                        " contradicts nonEmptyBlockCount="+nonEmpty+" (expected "+expected+")");
                }
                stage="biome palette";
                readPalette(sections,64,3,12,prefixedLongs);
                int baseY=sourceMinY+s*16-viewBaseY;
                if(baseY>=HEIGHT||baseY+16<=0)continue;
                for(int y=0;y<16;y++) {
                    int yy=baseY+y;if(yy<0||yy>=HEIGHT)continue;
                    for(int z=0;z<16;z++)for(int x=0;x<16;x++) {
                        int state=states[(y<<8)|(z<<4)|x];
                        int packed=toOldPacked(state);
                        int index=(x<<11)|(z<<7)|yy;
                        old[index]=(byte)packed;
                        int metadata=(packed>>>8)&15;
                        if(metadata!=0)setNibble(old,META_OFFSET,index,metadata);
                    }
                }
            } catch(IOException e) {
                throw new IOException("section="+s+"/"+sectionCount+" at offset="+before+"/"+raw.length+
                    " stage="+stage+" remaining="+sections.available()+" cause="+e.getClass().getSimpleName()+
                    (e.getMessage()==null?"":": "+e.getMessage()),e);
            }
        }
        int remaining=sections.available();
        if(remaining!=0)throw new IOException("26.2 section data length mismatch ("+remaining+
            " bytes left after "+sectionCount+" sections of "+raw.length+")");
        return old;
    }

    private static byte[] compress(byte[] old) throws IOException {
        Deflater compressor=new Deflater(4);
        compressor.setInput(old);
        compressor.finish();
        ByteArrayOutputStream compressed=new ByteArrayOutputStream(32768);
        byte[] buffer=new byte[8192];
        try {
            while(!compressor.finished()) {
                int count=compressor.deflate(buffer);
                if(count<=0)throw new IOException("zlib stalled while encoding Alpha chunk");
                compressed.write(buffer,0,count);
            }
        } finally {compressor.end();}
        return compressed.toByteArray();
    }

    private static int[] readPalette(DataInputStream in,int entryCount,int maxPaletteBits,int globalBits,boolean prefixedLongs) throws IOException {
        int bits=in.readUnsignedByte();
        if(bits>globalBits || (entryCount==4096 && bits>0 && bits<4))
            throw new IOException("Invalid palette width " + bits + " for " + entryCount + " entries");
        int[] palette=null;
        if(bits==0) {
            palette=new int[]{Wire.var(in)};
        } else if(bits<=maxPaletteBits) {
            int n=Wire.var(in);
            if(n<1||n>entryCount||(long)n>(1L<<bits))throw new IOException("Invalid palette size " + n);
            palette=new int[n];
            for(int j=0;j<n;j++)palette[j]=Wire.var(in);
        }
        int[] states=new int[entryCount];
        if(bits==0){
            if(prefixedLongs) {int count=Wire.var(in);if(count!=0)throw new IOException("Single-value palette expected zero longs, found "+count);}
            Arrays.fill(states,palette[0]);return states;
        }
        int perLong=64/bits, longCount=(entryCount+perLong-1)/perLong;
        if(longCount>4096)throw new IOException("Invalid packed state long count " + longCount);
        if(prefixedLongs) {
            int count=Wire.var(in);
            if(count!=longCount)throw new IOException("Packed long count "+count+" instead of "+longCount);
        }
        long mask=(1L<<bits)-1;
        int i=0;
        for(int j=0;j<longCount;j++) {
            long word=in.readLong();
            for(int e=0;e<perLong&&i<entryCount;e++,i++) {
                int index=(int)((word >>> (e*bits))&mask);
                if(palette!=null && index>=palette.length) throw new IOException("Palette index " + index + " >= " + palette.length);
                states[i]=palette==null?index:palette[index];
            }
        }
        return states;
    }

    private static void setNibble(byte[] dst,int offset,int pos,int v) {
        int at=offset+(pos>>>1),mask=(pos&1)==0?0xf0:0x0f;
        dst[at]=(byte)((dst[at]&mask)|((v&15)<<((pos&1)*4)));
    }
    private static BitSet readMask(DataInputStream in,int sectionCount) throws IOException {
        int longs=Wire.var(in);
        if(longs<0||longs>32)throw new IOException("Invalid light mask length " + longs);
        long[] word=new long[longs];for(int i=0;i<longs;i++)word[i]=in.readLong();
        BitSet bits=BitSet.valueOf(word);
        if(bits.length()>sectionCount+2)throw new IOException("Light mask exceeds dimension section count");
        return bits;
    }
    private static byte[][] readLightArrays(DataInputStream in, BitSet mask) throws IOException {
        int count=Wire.var(in);
        if(count!=mask.cardinality())throw new IOException("Light array count "+count+" != mask bits "+mask.cardinality());
        byte[][] result=new byte[mask.length()][];
        for(int bit=mask.nextSetBit(0);bit>=0;bit=mask.nextSetBit(bit+1)) {
            int len=Wire.var(in);
            if(len!=2048) throw new IOException("Light section must be 2048 bytes, got " + len);
            byte[] bytes=new byte[2048];in.readFully(bytes);result[bit]=bytes;
        }
        return result;
    }
    private static void readLighting(DataInputStream input,byte[] lights,int minY,int sections,int viewBaseY) throws IOException {
        int entities=Wire.var(input);
        if(entities<0||entities>8192)throw new IOException("Invalid block entity count " + entities);
        for(int i=0;i<entities;i++) {
            input.readUnsignedByte(); // X/Z nibble coordinates
            input.readShort(); // Y coordinate
            Wire.var(input); // registry block entity type
            int nbtType=input.readUnsignedByte();
            if(nbtType!=0)skipNbt(input,nbtType,0);
        }
        applyLightingPayload(input,lights,minY,sections,viewBaseY);
    }
    static void updateLight(int chunkX,int chunkZ,DataInputStream input,LegacyChunk chunk,int minY,int height,int viewBaseY) throws IOException {
        if(chunk.x!=chunkX||chunk.z!=chunkZ)throw new IOException("Light update for wrong chunk");
        if(height<128 || height%16!=0)throw new IOException("Invalid dimension");
        // The standalone LIGHT_UPDATE packet is just the light masks and layers.
        byte[] lights=new byte[BLOCKS];
        System.arraycopy(chunk.data,BLOCKLIGHT_OFFSET,lights,0,BLOCKS);
        applyLightingPayload(input,lights,minY,height/16,viewBaseY);
        System.arraycopy(lights,0,chunk.data,BLOCKLIGHT_OFFSET,BLOCKS);
    }
    private static void applyLightingPayload(DataInputStream input,byte[] lights,int minY,int sections,int viewBaseY) throws IOException {
        BitSet sky=readMask(input,sections),block=readMask(input,sections);
        BitSet emptySky=readMask(input,sections),emptyBlock=readMask(input,sections);
        if(sky.intersects(emptySky)||block.intersects(emptyBlock))throw new IOException("Overlapping light masks");
        byte[][] skyData=readLightArrays(input,sky),blockData=readLightArrays(input,block);
        for(int s=0;s<sections;s++) {
            int yBase=minY+s*16-viewBaseY;
            if(yBase>=HEIGHT||yBase+16<=0)continue;
            int lightBit=s+1; // bit 0 is the section *below* the world.
            if(emptySky.get(lightBit))copyLightSection(null,lights,BLOCKS/2,yBase,AMBIENT_SKY,AMBIENT_SKY);
            if(emptyBlock.get(lightBit))copyLightSection(null,lights,0,yBase,0,0);
            if(sky.get(lightBit))copyLightSection(skyData[lightBit],lights,BLOCKS/2,yBase,0,AMBIENT_SKY);
            if(block.get(lightBit))copyLightSection(blockData[lightBit],lights,0,yBase,0,0);
        }
    }
    private static void copyLightSection(byte[] src, byte[] dst,int destOffset,int yBase,int zero,int floor) {
        for(int y=0;y<16;y++) {
            int yy=yBase+y;
            if(yy<0||yy>=HEIGHT)continue;
            for(int z=0;z<16;z++)for(int x=0;x<16;x++) {
                int sourceIndex=(y<<8)|(z<<4)|x;
                int level=src==null?zero:(src[sourceIndex>>>1] >>> ((sourceIndex&1)*4))&15;
                setNibble(dst,destOffset,(x<<11)|(z<<7)|yy,Math.max(floor,level));
            }
        }
    }
    private static void skipNbt(DataInputStream in,int type,int depth) throws IOException {
        if(depth>64)throw new IOException("NBT nested too deep");
        switch(type) {
            case 1:in.readByte();break;
            case 2:in.readShort();break;
            case 3:in.readInt();break;
            case 4:in.readLong();break;
            case 5:in.readFloat();break;
            case 6:in.readDouble();break;
            case 7:{int n=in.readInt();skipBytes(in,n,8*1024*1024);break;}
            case 8:skipBytes(in,in.readUnsignedShort(),65535);break;
            case 9:{int item=in.readUnsignedByte(),n=in.readInt();if(n<0||n>1_000_000||item>12)throw new IOException("Invalid NBT list");for(int j=0;j<n;j++)skipNbt(in,item,depth+1);break;}
            case 10:{while(true){int tag=in.readUnsignedByte();if(tag==0)break;skipBytes(in,in.readUnsignedShort(),65535);skipNbt(in,tag,depth+1);}break;}
            case 11:{int n=in.readInt();if(n<0||n>1_000_000)throw new IOException("Invalid NBT int array");skipBytes(in,n*4,4_000_000);break;}
            case 12:{int n=in.readInt();if(n<0||n>1_000_000)throw new IOException("Invalid NBT long array");skipBytes(in,n*8,8_000_000);break;}
            default:throw new IOException("Unknown NBT tag " + type);
        }
    }
    private static void skipBytes(DataInputStream in,int count,int maximum) throws IOException {
        if(count<0||count>maximum)throw new IOException("Oversized NBT payload");
        byte[] buffer=new byte[Math.min(8192,count)];
        while(count>0){int n=Math.min(count,buffer.length);in.readFully(buffer,0,n);count-=n;}
    }
}
