package alphamodern;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.*;
import java.math.BigInteger;
import java.util.*;
import javax.crypto.*;
import javax.crypto.spec.*;
import java.util.concurrent.atomic.AtomicInteger;

/** Loopback-only, session-isolated protocol translator; no external proxy process. */
final class Gateway {
    private static ServerSocket listener;
    private static final AtomicInteger clients = new AtomicInteger();
    static synchronized void start() throws IOException {
        if(listener!=null)return;
        listener=new ServerSocket(0,32,InetAddress.getLoopbackAddress());
        Thread accept = new Thread(()->{
            while(!listener.isClosed()) {
                try {
                    final Socket legacy=listener.accept();
                    Thread worker = new Thread(()->session(legacy),"AlphaModern-session-"+clients.incrementAndGet());
                    worker.setDaemon(true);worker.start();
                }catch(IOException e){if(!listener.isClosed())System.err.println(AlphaModernAgent.PREFIX+e);}
            }
        },"AlphaModern-listener");accept.setDaemon(true);accept.start();
    }
    static synchronized int port() throws IOException {start();return listener.getLocalPort();}
    private static void session(Socket legacy) {
        Socket remote=null;
        Session bridge=null;
        boolean kicked=false;
        try {
            legacy.setTcpNoDelay(true); legacy.setSoTimeout(60000);
            DataInputStream lin=new DataInputStream(new BufferedInputStream(legacy.getInputStream()));
            DataOutputStream lout=new DataOutputStream(new BufferedOutputStream(legacy.getOutputStream()));
            String host=lin.readUTF();int port=lin.readInt();
            if(host.length()>255||port<1||port>65535)throw new IOException("Invalid host/port");
            int loginPacket=lin.readUnsignedByte();
            if(loginPacket!=1)throw new IOException("Alpha must send login packet 1, found "+loginPacket);
            int alphaProtocol=lin.readInt();String username=lin.readUTF();lin.readUTF();
            if(username.isEmpty()||username.length()>16)throw new IOException("Alpha username must be 1-16 characters");
            legacy.setSoTimeout(0); // Device-code authorization can take longer than a minute.
            if(alphaProtocol!=13)System.out.println(AlphaModernAgent.PREFIX+"Warning: unexpected Alpha protocol "+alphaProtocol);
            System.out.println(AlphaModernAgent.PREFIX+username+" -> "+host+":"+port+" (protocol 776)");
            remote=new Socket();remote.connect(new InetSocketAddress(host,port),10000);remote.setTcpNoDelay(true);remote.setSoTimeout(60000);
            bridge = new Session(lin,lout,remote,username,host,port);
            bridge.execute();
            kicked=true;
        }catch(Exception e) {
            String problem=e.getMessage()==null?e.toString():e.getMessage();
            System.err.println(AlphaModernAgent.PREFIX+"Session: "+problem);
            if(!kicked) {
                try{DataOutputStream o=new DataOutputStream(legacy.getOutputStream());o.writeByte(255);o.writeUTF("AlphaModern: "+shorten(problem,210));o.flush();}catch(Exception ignored){}
            }
        }finally{
            try{if(bridge!=null)bridge.close();else if(remote!=null)remote.close();}catch(Exception ignored){}
            try{legacy.close();}catch(Exception ignored){}
            AuthOverlay.clear();
        }
    }
    static String shorten(String str,int max){return str.length()>max?str.substring(0,max):str;}

    static final class Session {
        private final DataInputStream alphaIn;
        private final DataOutputStream alphaOut;
        private Socket server;
        private Wire wire;
        private final String name, host;
        private final int port;
        private volatile boolean playing;
        private volatile boolean active=true;
        private boolean alphaLoggedIn;
        private boolean playerLoadedSent;
        private volatile int localEntityId=-1;
        private final EntityTranslator entities = new EntityTranslator(this);
        private boolean lightGuardEnabled;
        private int compression=-1;
        private double posX,posY=68,posZ;
        private float yaw,pitch;
        private int teleports;
        private long chunks;
        // Modern 26.2 dimensions are taller than Alpha's 128-block renderer.
        // Keep a small cache so changing vertical windows can reproject chunks.
        private static final int MAX_CACHED_CHUNKS=192, MAX_CACHE_BYTES=32*1024*1024;
        private final LinkedHashMap<Long,byte[]> chunkPackets=new LinkedHashMap<Long,byte[]>(128,0.75f,true);
        private final java.util.concurrent.ConcurrentHashMap<Long,ChunkTranslator.LegacyChunk> renderedChunks=
            new java.util.concurrent.ConcurrentHashMap<Long,ChunkTranslator.LegacyChunk>();
        private final ServerBlockAuthority authority=new ServerBlockAuthority();
        private long cachedBytes;
        private int rejectedChunks;
        private boolean captureWritten;
        private volatile boolean viewportReady;
        private volatile long lastServerKeepAliveAt;
        private volatile long lastPongAt;
        private volatile int ticksSent;
        private volatile int viewportBaseY;
        int worldMinY = Integer.getInteger("alpha.modern.worldMinY", -64);
        int worldHeight = Integer.getInteger("alpha.modern.worldHeight", 384);
        Session(DataInputStream in,DataOutputStream out,Socket remote,String n,String h,int p) throws IOException {
            alphaIn=in;alphaOut=out;server=remote;wire=new Wire(remote);name=n;host=h;port=p;
        }
        int localEntityId(){return localEntityId;}
        int baseY(){return viewportBaseY;}
        boolean ready(){return viewportReady&&alphaLoggedIn;}
        void execute() throws Exception {
            // Minecraft 26.2 expects client tick markers even when Alpha has paused
            // and is no longer producing movement packets.
            Thread ticker = new Thread(()->pumpTicks(),"AlphaModern-modern-ticks");
            ticker.setDaemon(true);ticker.start();
            Thread fromAlpha = new Thread(()->pumpAlpha(),"AlphaModern-alpha-in");
            fromAlpha.setDaemon(true);fromAlpha.start();
            int attempts=0;
            while(active) {
                AuthManager.Profile stored=AuthManager.shared().peek();
                final String loginName=stored==null?name:stored.name;
                final java.util.UUID uuid=stored==null?profileUUID():stored.id();
                // Modern protocol 776 login must use the Java profile's real name and UUID.
                wire.send(0,o->{Wire.var(o,776);Wire.str(o,host);o.writeShort(port);Wire.var(o,2);});
                wire.send(0,o->{Wire.str(o,loginName);Wire.uuid(o,uuid);});
                boolean reconnect=false;
                int phase=0; // 0 login, 1 configuration, 2 game
                while(active) {
                    Wire.Packet packet=wire.recv();
                    if(phase==0) {
                        switch(packet.id) {
                            case 0: throw new IOException("Login rejected by 26.2: "+debugText(packet.data));
                            case 1:
                                if(handleEncryption(packet.data,loginName,uuid)){reconnect=true;}
                                break;
                            case 2:
                                wire.send(3,o->{});
                                phase=1;
                                sendSettings(false);
                                break;
                            case 3: wire.compression(Wire.var(packet.data));break;
                            case 4: {final int tx=Wire.var(packet.data);wire.send(2,o->{Wire.var(o,tx);o.writeBoolean(false);});break;}
                            case 5: replyCookie(packet.data,4);break;
                            default: throw new IOException("Unknown login packet id "+packet.id);
                        }
                    } else if(phase==1) {
                        switch(packet.id) {
                            case 0: replyCookie(packet.data,1);break;
                            case 2: throw new IOException("Configuration rejected: "+debugText(packet.data));
                            case 3: wire.send(3,o->{}); phase=2;playing=true;AuthOverlay.clear();break;
                            case 4: {final long keep=packet.data.readLong();wire.send(4,o->o.writeLong(keep));break;}
                            case 5: {final int ping=packet.data.readInt();wire.send(5,o->o.writeInt(ping));break;}
                            case 9: respondResourcePack(packet.data);break;
                            case 14: wire.send(7,o->Wire.var(o,0));break;
                            case 19: wire.send(9,o->{});break;
                            case 11: throw new IOException("Server transferred this connection to another host");
                            default: break;
                        }
                    } else {
                        handlePlay(packet);
                        if(packet.id==GameIds.CLIENTBOUND_START_CONFIGURATION) {
                            phase=1;playing=false;wire.send(16,o->{});sendSettings(false);
                        }
                    }
                    if(reconnect)break;
                }
                if(!reconnect||!active)return;
                if(++attempts>2)throw new IOException("Could not establish modern session after Microsoft authentication");
                try{server.close();}catch(Exception ignored){}
                Socket next=new Socket();
                next.connect(new InetSocketAddress(host,port),10000);
                next.setTcpNoDelay(true);next.setSoTimeout(60000);
                server=next;wire=new Wire(next);
                System.out.println(AlphaModernAgent.PREFIX+"Reconnecting as authenticated Java profile");
            }
        }
        private void pumpTicks(){
            while(active){
                try{
                    Thread.sleep(50L);
                    if(playing && wire!=null){
                        wire.send(GameIds.SERVERBOUND_CLIENT_TICK_END,o->{});
                        ticksSent++;
                    }
                }catch(InterruptedException e){Thread.currentThread().interrupt();return;}
                catch(IOException e){if(active)System.err.println(AlphaModernAgent.PREFIX+"Client tick send failure: "+e);return;}
            }
        }
        void close() throws IOException {
            if(lightGuardEnabled){lightGuardEnabled=false;WorldLightGuard.endBridge();}
            if(server!=null)server.close();
        }
        private java.util.UUID profileUUID() {
            String override=System.getProperty("alpha.modern.uuid","").trim();
            if(!override.isEmpty()) {
                try {return java.util.UUID.fromString(override);}catch(Exception e){ throw new IllegalArgumentException("-Dalpha.modern.uuid must be a UUID"); }
            }
            return java.util.UUID.nameUUIDFromBytes(("OfflinePlayer:"+name).getBytes(StandardCharsets.UTF_8));
        }
        private void replyCookie(DataInputStream packet,int id) throws IOException {
            final String key=Wire.str(packet);
            wire.send(id,o->{Wire.str(o,key);o.writeBoolean(false);});
        }
        /** Returns true when the server login must restart with a new Java profile. */
        private boolean handleEncryption(DataInputStream in,String loginName,java.util.UUID loginUuid) throws Exception {
            String serverId=Wire.str(in);byte[] pub=Wire.bytes(in,8192);byte[] challenge=Wire.bytes(in,8192);
            boolean requiresAuthentication=in.readBoolean();
            AuthManager.Profile account=null;
            boolean legacyOverride=!System.getProperty("alpha.modern.accessToken","").trim().isEmpty();
            if(requiresAuthentication&&!legacyOverride) {
                account=AuthManager.shared().ensure(()->active);
                if(!account.name.equals(loginName)||!account.id().equals(loginUuid))return true;
            }
            PublicKey key=KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(pub));
            KeyGenerator keygen=KeyGenerator.getInstance("AES");keygen.init(128);SecretKey secret=keygen.generateKey();
            if(requiresAuthentication)authenticate(serverId,secret.getEncoded(),pub,account);
            Cipher rsa=Cipher.getInstance("RSA/ECB/PKCS1Padding");rsa.init(Cipher.ENCRYPT_MODE,key);
            byte[] secretEncrypted=rsa.doFinal(secret.getEncoded());byte[] challengeEncrypted=rsa.doFinal(challenge);
            wire.send(1,o->{Wire.bytes(o,secretEncrypted);Wire.bytes(o,challengeEncrypted);});
            wire.encrypt(secret);
            return false;
        }
        private void authenticate(String serverId,byte[] key,byte[] publicKey,AuthManager.Profile account) throws Exception {
            MessageDigest sha=MessageDigest.getInstance("SHA-1");sha.update(serverId.getBytes(StandardCharsets.UTF_8));sha.update(key);sha.update(publicKey);
            String digest=new BigInteger(sha.digest()).toString(16);
            if(account!=null){AuthManager.shared().join(account,digest);return;}
            // Compatibility with older manual-token launches; automatic auth never puts tokens on JVM command lines.
            String token=System.getProperty("alpha.modern.accessToken","").trim();
            String profile=System.getProperty("alpha.modern.uuid","").trim().replace("-","");
            if(token.isEmpty()||profile.isEmpty())throw new IOException("Missing authenticated Minecraft Java session");
            URL url=new URL("https://sessionserver.mojang.com/session/minecraft/join");
            HttpURLConnection c=(HttpURLConnection)url.openConnection();c.setRequestMethod("POST");c.setConnectTimeout(12000);c.setReadTimeout(12000);
            c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");
            String payload="{\"accessToken\":"+AuthJson.quote(token)+",\"selectedProfile\":"+AuthJson.quote(profile)+",\"serverId\":"+AuthJson.quote(digest)+"}";
            try(OutputStream o=c.getOutputStream()){o.write(payload.getBytes(StandardCharsets.UTF_8));}
            int code=c.getResponseCode();c.disconnect();
            if(code!=204)throw new IOException("Minecraft session join failed (HTTP "+code+")");
        }
        private void sendSettings(boolean game) throws IOException {
            int id=game?GameIds.SERVERBOUND_CLIENT_INFORMATION:0;
            wire.send(id,o->{Wire.str(o,"en_us");o.writeByte(6);Wire.var(o,0);o.writeBoolean(true);o.writeByte(127);Wire.var(o,1);o.writeBoolean(false);o.writeBoolean(true);Wire.var(o,0);});
            // Send client brand payload, as an optional plugin message.
            int brandPacket=game?GameIds.SERVERBOUND_CUSTOM_PAYLOAD:2;
            wire.send(brandPacket,o->{Wire.str(o,"minecraft:brand");Wire.str(o,"alpha-modern-agent");});
        }
        private void respondResourcePack(DataInputStream in) throws IOException {
            java.util.UUID id=new java.util.UUID(in.readLong(),in.readLong());
            // Resource pack is optional to Alpha renderer, indicate decline.
            wire.send(6,o->{Wire.uuid(o,id);Wire.var(o,1);});
        }
        private void handlePlay(Wire.Packet packet) throws Exception {
            DataInputStream in=packet.data;
            int id=packet.id;
            if(id==GameIds.CLIENTBOUND_LOGIN){
                int entityId=in.readInt();localEntityId=entityId;
                entities.reset();
                // Dimension selection from 26.2 play-login packet; world format is otherwise not remapped.
                try {
                    in.readBoolean();
                    int dimensions=Wire.var(in);
                    if(dimensions<0||dimensions>128)throw new IOException("Invalid dimensions count");
                    for(int d=0;d<dimensions;d++)Wire.str(in);
                    Wire.var(in);Wire.var(in);Wire.var(in);
                    in.readBoolean();in.readBoolean();in.readBoolean();
                    Wire.var(in); // dimension-type holder registry index
                    String dimension=Wire.str(in);
                    if(System.getProperty("alpha.modern.worldMinY")==null) {
                        worldMinY=dimension.equals("minecraft:overworld")?-64:0;
                    }
                    if(System.getProperty("alpha.modern.worldHeight")==null) {
                        worldHeight=dimension.equals("minecraft:overworld")?384:256;
                    }
                    System.out.println(AlphaModernAgent.PREFIX+"Dimension "+dimension+" height="+worldHeight+" minY="+worldMinY);
                    viewportReady=false;
                    chunkPackets.clear();renderedChunks.clear();authority.clear();cachedBytes=0;

                } catch(Exception ignored) { // Some custom servers have varying registries: retain safe defaults.
                }
                if(!alphaLoggedIn){
                    if(!lightGuardEnabled){WorldLightGuard.beginBridge();lightGuardEnabled=true;}
                    legacy(1,o->{o.writeInt(entityId);o.writeUTF("");o.writeUTF("");});
                    alphaLoggedIn=true;playerLoadedSent=false;
                    legacy(3,o->o.writeUTF("[AlphaModern] Session established (experimental translator)."));
                }
            }else if(id==GameIds.CLIENTBOUND_PLAYER_POSITION) {
                int teleport=Wire.var(in);
                double x=in.readDouble(),y=in.readDouble(),z=in.readDouble();
                in.readDouble();in.readDouble();in.readDouble(); // velocity delta
                float yrot=in.readFloat(),xrot=in.readFloat();int relative=in.readInt();
                if((relative&1)!=0)x+=posX;if((relative&2)!=0)y+=posY;if((relative&4)!=0)z+=posZ;
                if((relative&8)!=0)yrot+=yaw;if((relative&16)!=0)xrot+=pitch;
                posX=x;posY=y;posZ=z;yaw=yrot;pitch=xrot;
                wire.send(GameIds.SERVERBOUND_ACCEPT_TELEPORTATION,o->Wire.var(o,teleport));
                // Acknowledging the teleport does not replace a movement sync.
                // Send the exact server-space position immediately, independently
                // of Alpha's next render/game tick, to avoid stale server positions.
                if(Double.isFinite(x)&&Double.isFinite(y)&&Double.isFinite(z)) {
                    final double serverX=x,serverY=y,serverZ=z;
                    final float serverYaw=yrot,serverPitch=xrot;
                    wire.send(GameIds.SERVERBOUND_MOVE_PLAYER_POS_ROT,o->{
                        o.writeDouble(serverX);o.writeDouble(serverY);o.writeDouble(serverZ);
                        o.writeFloat(serverYaw);o.writeFloat(serverPitch);o.writeByte(0);
                    });
                }
                if(!viewportReady || VerticalViewport.shouldRecenter(y,viewportBaseY,worldMinY,worldHeight)) {
                    int newBase=VerticalViewport.chooseBase(y,worldMinY,worldHeight);
                    boolean changed=viewportReady && viewportBaseY!=newBase;
                    viewportBaseY=newBase;viewportReady=true;
                    System.out.println(AlphaModernAgent.PREFIX+"Vertical viewport: server Y="+y+" Alpha Y="+(y-newBase)+" range="+newBase+".."+(newBase+127));
                    if(changed)unloadCachedChunks();
                    resendCachedChunks();
                    if(changed)entities.reprojection();
                }
                final double fx=x,fy=y-viewportBaseY,fz=z;final float fyaw=yrot,fpitch=xrot;
                if(alphaLoggedIn)legacy(13,o->{
                    // Alpha protocol 13 server-to-client 0x0D swaps the two Y fields:
                    // stance (eye height) BEFORE feet Y. Client-to-server reverses them.
                    o.writeDouble(fx);o.writeDouble(fy+1.62);o.writeDouble(fy);
                    o.writeDouble(fz);o.writeFloat(fyaw);o.writeFloat(fpitch);o.writeBoolean(false);
                });
            }else if(id==GameIds.CLIENTBOUND_KEEP_ALIVE) {
                final long keep=in.readLong();
                lastServerKeepAliveAt=System.currentTimeMillis();
                wire.send(GameIds.SERVERBOUND_KEEP_ALIVE,o->o.writeLong(keep));
            }else if(id==GameIds.CLIENTBOUND_PING) {
                final int challenge=in.readInt();
                wire.send(GameIds.SERVERBOUND_PONG,o->o.writeInt(challenge));
                lastPongAt=System.currentTimeMillis();
            }else if(id==GameIds.CLIENTBOUND_ANIMATE) {
                int entity=Wire.var(in),animation=in.readUnsignedByte();
                if(animation==0)legacy(18,o->{o.writeInt(entity);o.writeByte(1);});
            }else if(id==GameIds.CLIENTBOUND_PLAYER_INFO_UPDATE) {
                entities.playerInfo(in);
            }else if(id==GameIds.CLIENTBOUND_PLAYER_INFO_REMOVE) {
                entities.playerInfoRemove(in);
            }else if(id==GameIds.CLIENTBOUND_ADD_ENTITY) {
                entities.addEntity(in);
            }else if(id==GameIds.CLIENTBOUND_MOVE_ENTITY_POS ||
                     id==GameIds.CLIENTBOUND_MOVE_ENTITY_POS_ROT ||
                     id==GameIds.CLIENTBOUND_MOVE_ENTITY_ROT) {
                entities.relative(in,id);
            }else if(id==GameIds.CLIENTBOUND_TELEPORT_ENTITY) {
                entities.absoluteSync(in,true);
            }else if(id==GameIds.CLIENTBOUND_ENTITY_POSITION_SYNC) {
                entities.absoluteSync(in,false);
            }else if(id==GameIds.CLIENTBOUND_REMOVE_ENTITIES) {
                entities.removeEntities(in);
            }else if(id==GameIds.CLIENTBOUND_ROTATE_HEAD) {
                entities.head(in);
            }else if(id==GameIds.CLIENTBOUND_PONG_RESPONSE) {
                // No response necessary.
            }else if(id==GameIds.CLIENTBOUND_DISCONNECT) {
                throw new IOException("Server disconnected: "+debugText(in));
            }else if(id==GameIds.CLIENTBOUND_CHUNK_BATCH_FINISHED) {
                final float chunksPerTick=1.0f;wire.send(GameIds.SERVERBOUND_CHUNK_BATCH_RECEIVED,o->o.writeFloat(chunksPerTick));
            }else if(id==GameIds.CLIENTBOUND_LEVEL_CHUNK_WITH_LIGHT) {
                if(alphaLoggedIn)receiveChunk(in);
            }else if(id==GameIds.CLIENTBOUND_FORGET_LEVEL_CHUNK) {
                // 26.2 ChunkPos is a packed long with X in low 32 and Z in high 32.
                // v0.6.0 accidentally swapped them, leaving old chunks rendered.
                long packed=in.readLong();
                final int x=(int)packed,z=(int)(packed>>>32);
                removeCachedChunk(x,z);
                if(alphaLoggedIn&&viewportReady)legacy(50,o->{o.writeInt(x);o.writeInt(z);o.writeBoolean(false);});
            }else if(id==GameIds.CLIENTBOUND_BLOCK_CHANGED_ACK) {
                // Modern acknowledgements are cumulative. They are not proof of
                // success: the cached server blocks remain authoritative.
                final int acknowledged=Wire.var(in);
                authority.acknowledge(acknowledged,this,renderedChunks,viewportBaseY);
            }else if(id==GameIds.CLIENTBOUND_BLOCK_UPDATE) {
                long where=in.readLong();int modernState=Wire.var(in);
                final int x=Wire.unpackX(where),y=Wire.unpackY(where),z=Wire.unpackZ(where);
                final int packed=ChunkTranslator.toOldPacked(modernState),alphaY=y-viewportBaseY;
                authority.record(new ServerBlockAuthority.Change(x,y,z,packed),renderedChunks,viewportBaseY);
                if(viewportReady&&alphaY>=0&&alphaY<128)legacy(53,o->{
                    o.writeInt(x);o.writeByte(alphaY);o.writeInt(z);
                    o.writeByte(packed&255);o.writeByte((packed>>>8)&15);
                });
            }else if(id==GameIds.CLIENTBOUND_SECTION_BLOCKS_UPDATE) {
                handleSectionBlockUpdates(in);
            }else if(id==GameIds.CLIENTBOUND_LIGHT_UPDATE) {
                handleLightUpdate(in);
            }else if(id==GameIds.CLIENTBOUND_PLAYER_CHAT) {
                receivePlayerChat(in);
            }else if(id==GameIds.CLIENTBOUND_SYSTEM_CHAT) {
                if(alphaLoggedIn) {
                    try {
                        final String message=TextComponent.readFormatted(in);
                        boolean overlay=in.available()>0 && in.readBoolean();
                        if(!overlay)sendLegacyChat(message);
                    }catch(IOException bad){System.err.println(AlphaModernAgent.PREFIX+"Unrenderable server chat component: "+bad.getMessage());}
                }
            }else if(id==GameIds.CLIENTBOUND_DISGUISED_CHAT) {
                if(alphaLoggedIn) {
                    try{sendLegacyChat(TextComponent.readFormatted(in));}
                    catch(IOException bad){System.err.println(AlphaModernAgent.PREFIX+"Unrenderable disguised chat: "+bad.getMessage());}
                }
            }else if(id==GameIds.CLIENTBOUND_SET_CHUNK_CACHE_CENTER) {
                // no Alpha counterpart
            }else if(id==GameIds.CLIENTBOUND_START_CONFIGURATION) {
                // handled in execute()
            }
            // The remaining modern play packets are safely ignored because each packet is framed.
        }
        private long chunkKey(int x,int z) {return ((long)x<<32)|(z&0xffffffffL);}
        private void removeCachedChunk(int x,int z) {
            byte[] removed=chunkPackets.remove(chunkKey(x,z));
            if(removed!=null)cachedBytes-=removed.length;
            renderedChunks.remove(chunkKey(x,z));
            authority.forget(x,z);
        }
        private void receiveChunk(DataInputStream in) throws IOException {
            final byte[] bytes=AlphaModernAgent.readAll(in);
            if(bytes.length<8 || bytes.length>1024*1024) {
                System.err.println(AlphaModernAgent.PREFIX+"Discarded oversized/invalid chunk packet: "+bytes.length);
                return;
            }
            DataInputStream head=new DataInputStream(new ByteArrayInputStream(bytes));
            int x=head.readInt(),z=head.readInt();
            removeCachedChunk(x,z);
            long key=chunkKey(x,z);
            chunkPackets.put(key,bytes);cachedBytes+=bytes.length;
            while(chunkPackets.size()>MAX_CACHED_CHUNKS || cachedBytes>MAX_CACHE_BYTES) {
                Map.Entry<Long,byte[]> eldest=chunkPackets.entrySet().iterator().next();
                cachedBytes-=eldest.getValue().length;chunkPackets.remove(eldest.getKey());
                renderedChunks.remove(eldest.getKey());
            }
            if(viewportReady)publishChunk(bytes);
        }
        private void publishChunk(byte[] bytes) throws IOException {
            try {
                ChunkTranslator.LegacyChunk chunk=ChunkTranslator.decodeChunk(
                    new DataInputStream(new ByteArrayInputStream(bytes)),worldMinY,worldHeight,viewportBaseY);
                authority.apply(chunk,viewportBaseY);
                ChunkTranslator.sendOldChunk(chunk,this,true);
                renderedChunks.put(chunkKey(chunk.x,chunk.z),chunk);
                chunks++;
                // 26.2 servers gate player input until PLAYER_LOADED arrives.
                // Send only after the first successfully translated terrain chunk.
                if(alphaLoggedIn && !playerLoadedSent) {
                    playerLoadedSent=true;
                    wire.send(GameIds.SERVERBOUND_PLAYER_LOADED,o->{});
                    System.out.println(AlphaModernAgent.PREFIX+"First terrain chunk rendered; sent Player Loaded");
                }
            } catch(Exception e) {
                rejectedChunks++;
                if(rejectedChunks<=6 || rejectedChunks%128==0) {
                    String reason=e.toString();
                    System.err.println(AlphaModernAgent.PREFIX+"Rejected chunk ("+readChunkX(bytes)+","+readChunkZ(bytes)+") "+
                        " #"+rejectedChunks+", packet="+bytes.length+" bytes: "+reason);
                    if(rejectedChunks==1) {
                        e.printStackTrace(System.err);
                        System.err.println(AlphaModernAgent.PREFIX+"To preserve one rejected chunk for diagnosis, launch with " +
                            "-Dalpha.modern.captureBadChunks=true (the capture can contain server/world data).");
                    }
                }
                if(!captureWritten && Boolean.getBoolean("alpha.modern.captureBadChunks")) {
                    captureWritten=true;
                    try {
                        java.nio.file.Path folder=AuthManager.defaultPath().resolve("debug");
                        java.nio.file.Files.createDirectories(folder);
                        String target="bad-chunk-"+readChunkX(bytes)+"_"+readChunkZ(bytes)+".bin";
                        java.nio.file.Path path=folder.resolve(target);
                        java.nio.file.Files.write(path,bytes);
                        System.err.println(AlphaModernAgent.PREFIX+"Saved rejected modern packet to "+path+
                            " (contains server/world data; review before sharing)");
                    }catch(Exception failure){System.err.println(AlphaModernAgent.PREFIX+"Could not save diagnostic chunk: "+failure);}
                }
            }
        }
        private int readChunkX(byte[] packet) {return ((packet[0]&255)<<24)|((packet[1]&255)<<16)|((packet[2]&255)<<8)|(packet[3]&255);}
        private int readChunkZ(byte[] packet) {return ((packet[4]&255)<<24)|((packet[5]&255)<<16)|((packet[6]&255)<<8)|(packet[7]&255);}
        private void unloadCachedChunks() throws IOException {
            renderedChunks.clear();
            for(Long key:chunkPackets.keySet()) {
                final int x=(int)(key>>32),z=(int)(long)key;
                legacy(50,o->{o.writeInt(x);o.writeInt(z);o.writeBoolean(false);});
            }
        }
        private void resendCachedChunks() throws IOException {
            for(byte[] b:new ArrayList<byte[]>(chunkPackets.values()))publishChunk(b);
        }
        // Do not alter actual server terrain at spawn. Earlier experimental
        // clearance mutated arbitrary stone blocks and could make server/client
        // collision disagree. Modern non-full blocks instead need safe mapping.
        private void handleLightUpdate(DataInputStream in) throws IOException {
            int cx=Wire.var(in),cz=Wire.var(in);
            ChunkTranslator.LegacyChunk chunk=renderedChunks.get(chunkKey(cx,cz));
            if(!viewportReady || chunk==null)return;
            try {
                ChunkTranslator.updateLight(cx,cz,in,chunk,worldMinY,worldHeight,viewportBaseY);
                ChunkTranslator.sendOldChunk(chunk,this,false);
            }catch(IOException e){System.err.println(AlphaModernAgent.PREFIX+"Ignored incompatible light update "+cx+","+cz+": "+e.getMessage());}
        }
        private void handleSectionBlockUpdates(DataInputStream in) throws IOException {
            long section=in.readLong();
            int sx=(int)(section>>42), sz=(int)(section<<22>>42), sy=(int)(section<<44>>44);
            int count=Wire.var(in);
            if(count<0||count>4096)throw new IOException("Invalid section block update count "+count);
            for(int i=0;i<count;i++) {
                long entry=Wire.varLong(in);
                int state=(int)(entry>>>12),local=(int)(entry&4095);
                int x=(sx<<4)|((local>>>8)&15);
                int z=(sz<<4)|((local>>>4)&15);
                int y=(sy<<4)|(local&15);
                final int projected=y-viewportBaseY, packed=ChunkTranslator.toOldPacked(state);
                authority.record(new ServerBlockAuthority.Change(x,y,z,packed),renderedChunks,viewportBaseY);
                if(viewportReady&&projected>=0&&projected<128)legacy(53,o->{
                    o.writeInt(x);o.writeByte(projected);o.writeInt(z);
                    o.writeByte(packed&255);o.writeByte((packed>>>8)&15);
                });
            }
        }
        private void receivePlayerChat(DataInputStream in) throws IOException {
            // 26.2 ClientboundPlayerChatPacket: globalIndex, sender, index,
            // optional 256-byte signature, PackedSignedMessageBody.
            try {
                Wire.var(in); // global chat index
                java.util.UUID sender=new java.util.UUID(in.readLong(),in.readLong());
                Wire.var(in); // sender-local index
                if(in.readBoolean()){
                    byte[] signature=new byte[256];in.readFully(signature);
                }
                String message=Wire.str(in);
                in.readLong();in.readLong(); // timestamp, salt
                int seen=Wire.var(in);
                if(seen<0||seen>20)throw new IOException("Invalid last-seen count "+seen);
                for(int i=0;i<seen;i++){
                    int packed=Wire.var(in);
                    if(packed==0){byte[] signature=new byte[256];in.readFully(signature);}
                }
                // Remaining fields (unsigned component, filter, chat type) can be
                // safely skipped because the modern connection is packet framed.
                if(message.isEmpty() || message.length()>4096)return;
                String senderName=entities.profileName(sender);
                if(senderName==null) senderName="Player";
                sendLegacyChat("<"+senderName+"> "+message);
            }catch(IOException bad){
                System.err.println(AlphaModernAgent.PREFIX+"Player chat could not be decoded: "+bad.getMessage());
            }
        }
        private static String alphaSafeChat(String input) {
            if(input==null)return "";
            StringBuilder result=new StringBuilder(Math.min(input.length(),16384));
            for(int i=0;i<input.length();i++) {
                char c=input.charAt(i);
                if(c=='\u00a7') {
                    if(i+1<input.length()) {
                        char code=Character.toLowerCase(input.charAt(i+1));
                        i++;
                        // Alpha supports only the original sixteen color codes.
                        if("0123456789abcdef".indexOf(code)>=0)result.append('\u00a7').append(code);
                    }
                } else if(c=='\n'||c=='\t'||c>=32)result.append(c);
            }
            // Minecraft Alpha's original font renderer unconditionally jumps to
            // charAt() after a final color code, causing StringIndexOutOfBounds.
            while(result.length()>=2 && result.charAt(result.length()-2)=='\u00a7')
                result.setLength(result.length()-2);
            return result.toString();
        }
        private void sendLegacyChat(String modern) throws IOException {
            String normalized=alphaSafeChat(modern);
            if(normalized.trim().isEmpty())return;
            for(String line:normalized.split("\n",-1)) {
                if(line.length()==0)continue;
                int offset=0;
                char color='f';
                while(offset<line.length()) {
                    int last=Math.min(offset+250,line.length());
                    // Never cut inside a formatting code.
                    if(last<line.length() && last>offset && line.charAt(last-1)=='\u00a7')last--;
                    if(last<=offset)last=Math.min(offset+2,line.length());
                    String payload=line.substring(offset,last);
                    String part=alphaSafeChat((offset==0?"":"\u00a7"+color)+payload);
                    for(int i=0;i+1<payload.length();i++)if(payload.charAt(i)=='\u00a7') {
                        char c=payload.charAt(i+1);
                        if("0123456789abcdef".indexOf(c)>=0)color=c;
                    }
                    if(part.replaceAll("\u00a7[0-9a-f]", "").trim().length()>0)
                        legacy(3,o->o.writeUTF(part));
                    offset=last;
                }
            }
        }
        synchronized void legacy(int id,Wire.Writer writer) throws IOException {
            if(!active)return;
            alphaOut.writeByte(id);writer.write(alphaOut);alphaOut.flush();
        }
        private void pumpAlpha() {
            try {
                while(active) {
                    int id=alphaIn.readUnsignedByte();
                    switch(id) {
                        case 0: break; // legacy keepalive has no payload
                        case 3: {String chat=alphaIn.readUTF();
                            if(chat.equalsIgnoreCase("/amdebug")){
                                String info="AlphaModern: server Y="+String.format(java.util.Locale.ROOT,"%.1f",posY)+
                                    ", Alpha Y="+String.format(java.util.Locale.ROOT,"%.1f",posY-viewportBaseY)+
                                    ", shown="+viewportBaseY+".."+(viewportBaseY+127)+", rendered="+renderedChunks.size()+", rejected="+rejectedChunks+
                    ", lightJobsDeferred="+WorldLightGuard.dropped()+
                    ", players="+entities.shown()+"/"+entities.tracked()+
                    ", pendingBlocks="+authority.pendingCount()+", blockAcks="+authority.acknowledgedCount()+
                    ", blockCorrections="+authority.correctionCount()+
                    ", ticks="+ticksSent+", keepaliveAge="+
                    (lastServerKeepAliveAt==0?"none":((System.currentTimeMillis()-lastServerKeepAliveAt)/1000)+"s");
                                sendLegacyChat(info);
                            }else if(playing)sendChat(chat);
                            break;}
                        case 10: {boolean ground=alphaIn.readBoolean();if(playing&&viewportReady)wire.send(GameIds.SERVERBOUND_MOVE_PLAYER_STATUS_ONLY,o->o.writeByte(ground?1:0));break;}
                        case 11: {double x=alphaIn.readDouble(),y=alphaIn.readDouble(),stance=alphaIn.readDouble(),z=alphaIn.readDouble();boolean ground=alphaIn.readBoolean();
                            double serverY=y+viewportBaseY;
                            posX=x;posY=serverY;posZ=z;
                            if(playing&&viewportReady)wire.send(GameIds.SERVERBOUND_MOVE_PLAYER_POS,o->{o.writeDouble(x);o.writeDouble(serverY);o.writeDouble(z);o.writeByte(ground?1:0);});break;}
                        case 12: {float yrot=alphaIn.readFloat(),xrot=alphaIn.readFloat();boolean ground=alphaIn.readBoolean();yaw=yrot;pitch=xrot;
                            if(playing&&viewportReady)wire.send(GameIds.SERVERBOUND_MOVE_PLAYER_ROT,o->{o.writeFloat(yrot);o.writeFloat(xrot);o.writeByte(ground?1:0);});break;}
                        case 13: {double x=alphaIn.readDouble(),y=alphaIn.readDouble(),stance=alphaIn.readDouble(),z=alphaIn.readDouble();float yrot=alphaIn.readFloat(),xrot=alphaIn.readFloat();boolean ground=alphaIn.readBoolean();
                            double serverY=y+viewportBaseY;
                            posX=x;posY=serverY;posZ=z;yaw=yrot;pitch=xrot;
                            if(playing&&viewportReady)wire.send(GameIds.SERVERBOUND_MOVE_PLAYER_POS_ROT,o->{o.writeDouble(x);o.writeDouble(serverY);o.writeDouble(z);o.writeFloat(yrot);o.writeFloat(xrot);o.writeByte(ground?1:0);});break;}
                        case 14: {int action=alphaIn.readUnsignedByte(),x=alphaIn.readInt(),y=alphaIn.readUnsignedByte(),z=alphaIn.readInt(),face=alphaIn.readUnsignedByte();
                            // Do not modify the local world. Modern 26.2 validates
                            // the action, then sends block changes/acknowledgements.
                            if(playing&&viewportReady&&(action==0||action==1||action==2)){
                                final int serverY=y+viewportBaseY;
                                final int modernAction=action==0?0:(action==1?1:2);
                                final int side=face<6?face:1;
                                final int sequence=authority.sequence(x,serverY,z,-1);
                                wire.send(GameIds.SERVERBOUND_PLAYER_ACTION,o->{
                                    Wire.var(o,modernAction);o.writeLong(Wire.pos(x,serverY,z));
                                    o.writeByte(side);Wire.var(o,sequence);
                                });
                            }
                            break;}
                        case 15: {short item=alphaIn.readShort();int x=alphaIn.readInt();int y=alphaIn.readUnsignedByte();int z=alphaIn.readInt();int face=alphaIn.readUnsignedByte();
                            // Alpha 0x0F has no hit-cursor coordinates. Use the
                            // centre of the clicked face, but let the server
                            // decide whether the item held can place anything.
                            if(playing&&viewportReady){
                                if(face>=0&&face<=5&&y<128){
                                    final int serverY=y+viewportBaseY, side=face;
                                    final int seq=authority.sequence(x,serverY,z,side);
                                    wire.send(GameIds.SERVERBOUND_USE_ITEM_ON,o->{
                                        Wire.var(o,0);o.writeLong(Wire.pos(x,serverY,z));Wire.var(o,side);
                                        o.writeFloat(0.5f);o.writeFloat(0.5f);o.writeFloat(0.5f);
                                        o.writeBoolean(false);o.writeBoolean(false);Wire.var(o,seq);
                                    });
                                }else if(face==255){
                                    final int seq=authority.sequence(x,y,z,-1);
                                    wire.send(GameIds.SERVERBOUND_USE_ITEM,o->{
                                        Wire.var(o,0);Wire.var(o,seq);o.writeFloat(yaw);o.writeFloat(pitch);
                                    });
                                }
                            }
                            break;}
                        case 16: {int entity=alphaIn.readInt();short selected=alphaIn.readShort();
                            // Alpha 0x10 is held item change; modern hotbar uses
                            // 0-8, but old packet sends item ID rather than slot.
                            // Never infer a slot from an item ID.
                            break;}
                        case 17: {alphaIn.readShort();alphaIn.readByte();alphaIn.readShort();break;}
                        case 18: {
                            alphaIn.readInt();int animation=alphaIn.readUnsignedByte();
                            if(playing&&animation==1)wire.send(GameIds.SERVERBOUND_SWING,o->Wire.var(o,0));
                            break;
                        }
                        case 255: {active=false;return;}
                        default:throw new IOException("Unmapped Alpha outgoing packet " + id + " (closed safely)");
                    }
                }
            }catch(EOFException ignored){active=false;try{server.close();}catch(IOException e){}
            }catch(Exception e){if(active)System.err.println(AlphaModernAgent.PREFIX+"Alpha input: "+e);active=false;try{server.close();}catch(IOException ignored){}}
        }
        private void sendChat(String chat) throws IOException {
            if(chat.length()>256)chat=chat.substring(0,256);
            if(chat.startsWith("/")){
                final String command=chat.substring(1);wire.send(GameIds.SERVERBOUND_CHAT_COMMAND,o->Wire.str(o,command));
            }else{
                final String message=chat;
                wire.send(GameIds.SERVERBOUND_CHAT,o->{Wire.str(o,message);o.writeLong(System.currentTimeMillis());o.writeLong(0);o.writeBoolean(false);Wire.var(o,0);o.write(new byte[3]);o.writeByte(0);});
            }
        }
        static String debugText(DataInputStream in) throws IOException {
            byte[] data=AlphaModernAgent.readAll(in);
            if(data.length==0)return "(empty)";
            // Chat components in 26.2 are NBT-encoded; this is intentionally only a diagnostic view.
            String s=new String(data,StandardCharsets.UTF_8);
            StringBuilder b=new StringBuilder();
            for(char c:s.toCharArray())if(c=='\n'||c=='\r'||c=='\t'||c>=32)b.append(c);
            return shorten(b.toString().trim(),180);
        }
    }
}
