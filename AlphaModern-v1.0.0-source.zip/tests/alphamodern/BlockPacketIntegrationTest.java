package alphamodern;

import java.io.*;
import java.net.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.*;

/** Tests real Alpha/modern packets through Gateway.Session, not a mock ledger. */
public final class BlockPacketIntegrationTest {
    static void ok(boolean b,String s){if(!b)throw new AssertionError(s);}
    static void set(Gateway.Session s,String field,Object v)throws Exception {
        Field f=Gateway.Session.class.getDeclaredField(field);f.setAccessible(true);f.set(s,v);
    }
    @SuppressWarnings("unchecked")
    static Map<Long,ChunkTranslator.LegacyChunk> chunks(Gateway.Session s)throws Exception {
        Field f=Gateway.Session.class.getDeclaredField("renderedChunks");f.setAccessible(true);
        return (Map<Long,ChunkTranslator.LegacyChunk>)f.get(s);
    }
    static byte[] bytes(Wire.Writer w)throws IOException {
        ByteArrayOutputStream b=new ByteArrayOutputStream();DataOutputStream o=new DataOutputStream(b);w.write(o);o.flush();return b.toByteArray();
    }
    static void deliver(Gateway.Session s,int id,Wire.Writer w)throws Exception {
        Method handler=Gateway.Session.class.getDeclaredMethod("handlePlay",Wire.Packet.class);handler.setAccessible(true);
        try{handler.invoke(s,new Wire.Packet(id,new DataInputStream(new ByteArrayInputStream(bytes(w)))));}
        catch(InvocationTargetException ex){throw (Exception)ex.getCause();}
    }
    static void assertBlockPacket(DataInputStream in,int x,int y,int z,int id,int meta)throws IOException {
        ok(in.readUnsignedByte()==53,"expected authoritative block packet 0x35");
        ok(in.readInt()==x&&in.readUnsignedByte()==y&&in.readInt()==z,"block location mismatch");
        ok(in.readUnsignedByte()==id&&in.readUnsignedByte()==meta,"wrong authoritative block state");
    }
    public static void main(String[] args)throws Exception {
        ByteArrayOutputStream toAlpha=new ByteArrayOutputStream();
        PipedOutputStream alphaSender=new PipedOutputStream();
        PipedInputStream alphaReceiver=new PipedInputStream(alphaSender,32768);
        try(ServerSocket port=new ServerSocket(0,1,InetAddress.getLoopbackAddress());
            Socket client=new Socket(InetAddress.getLoopbackAddress(),port.getLocalPort());
            Socket peer=port.accept()) {
            peer.setSoTimeout(5000);
            Wire serverWire=new Wire(peer);
            Gateway.Session session=new Gateway.Session(new DataInputStream(alphaReceiver),
                new DataOutputStream(toAlpha),client,"Tester","localhost",port.getLocalPort());
            set(session,"playing",true);set(session,"alphaLoggedIn",true);
            set(session,"viewportReady",true);set(session,"viewportBaseY",16);
            Map<Long,ChunkTranslator.LegacyChunk> rendered=chunks(session);
            ChunkTranslator.LegacyChunk chunk=new ChunkTranslator.LegacyChunk(0,0,new byte[ChunkTranslator.OLD_LENGTH]);
            rendered.put(ServerBlockAuthority.key(0,0),chunk);
            // Modern single block state update must also modify full-chunk cache.
            deliver(session,GameIds.CLIENTBOUND_BLOCK_UPDATE,o->{o.writeLong(Wire.pos(2,84,3));Wire.var(o,1);});
            DataInputStream legacy=new DataInputStream(new ByteArrayInputStream(toAlpha.toByteArray()));
            assertBlockPacket(legacy,2,68,3,1,0);
            ok((chunk.data[ServerBlockAuthority.atIndex(2,68,3)]&255)==1,"single update not reflected in cached chunk");
            toAlpha.reset();
            // Section-wide updates must also alter cache and tell the Alpha client.
            int sectionY=84>>4, packedLocal=(2<<8)|(3<<4)|(84&15);
            long packedSection=(long)sectionY;
            deliver(session,GameIds.CLIENTBOUND_SECTION_BLOCKS_UPDATE,o->{
                o.writeLong(packedSection);Wire.var(o,1);
                Wire.writeVarLong(o,(((long)0)<<12)|packedLocal); // air
            });
            legacy=new DataInputStream(new ByteArrayInputStream(toAlpha.toByteArray()));
            assertBlockPacket(legacy,2,68,3,0,0);
            ok((chunk.data[ServerBlockAuthority.atIndex(2,68,3)]&255)==0,"section update not reflected in cache");
            toAlpha.reset();
            // Alpha user actions should go to the modern server, NOT alter blocks.
            Thread fromAlpha=new Thread(()->{
                try{
                    Method pump=Gateway.Session.class.getDeclaredMethod("pumpAlpha");pump.setAccessible(true);
                    pump.invoke(session);
                }catch(Exception ex){throw new RuntimeException(ex);}
            });fromAlpha.setDaemon(true);fromAlpha.start();
            DataOutputStream a=new DataOutputStream(alphaSender);
            a.writeByte(14);a.writeByte(0);a.writeInt(2);a.writeByte(68);a.writeInt(3);a.writeByte(1);
            a.writeByte(15);a.writeShort(5);a.writeInt(2);a.writeByte(68);a.writeInt(3);a.writeByte(1);
            a.flush();
            Wire.Packet dig=serverWire.recv();
            ok(dig.id==GameIds.SERVERBOUND_PLAYER_ACTION,"dig was not forwarded");
            ok(Wire.var(dig.data)==0,"dig start action wrong");
            ok(dig.data.readLong()==Wire.pos(2,84,3),"incorrect modern Y coordinate");
            ok(dig.data.readUnsignedByte()==1,"wrong dig face");
            int seq1=Wire.var(dig.data);
            Wire.Packet placement=serverWire.recv();
            ok(placement.id==GameIds.SERVERBOUND_USE_ITEM_ON,"placement packet was dropped");
            ok(Wire.var(placement.data)==0,"wrong main hand");
            ok(placement.data.readLong()==Wire.pos(2,84,3),"wrong block interaction position");
            ok(Wire.var(placement.data)==1,"wrong placement face");
            for(int i=0;i<3;i++)ok(placement.data.readFloat()==0.5f,"missing hit cursor position");
            ok(!placement.data.readBoolean()&&!placement.data.readBoolean(),"incorrect hit flags");
            int seq2=Wire.var(placement.data);ok(seq1>0&&seq2==seq1+1,"invalid prediction sequences");
            ok((chunk.data[ServerBlockAuthority.atIndex(2,68,3)]&255)==0,"local placement created a phantom block");
            // When the server rejects the attempt, ACK resends authoritative air.
            deliver(session,GameIds.CLIENTBOUND_BLOCK_CHANGED_ACK,o->Wire.var(o,seq2));
            legacy=new DataInputStream(new ByteArrayInputStream(toAlpha.toByteArray()));
            assertBlockPacket(legacy,2,68,3,0,0);
            ok((chunk.data[ServerBlockAuthority.atIndex(2,68,3)]&255)==0,"rejected attempt changed server cache");
            session.close();
            alphaSender.close();fromAlpha.join(500);
        }
        System.out.println("PASS: modern block and section updates, Alpha dig/place packet translation, nonzero increasing sequences and reject correction");
    }
}
