package alphamodern;

import java.io.DataInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Translates modern player entities to Alpha protocol-13 packets.
 * Uses entity type ID 156 from the Minecraft 26.2 registry.
 * Alpha can render players but does not have modern skins, poses or metadata.
 */
final class EntityTranslator {
    static final int PLAYER_TYPE_ID = 156;
    private static final int MAX_PLAYERS = 1024;
    private final Gateway.Session destination;
    private final Map<UUID,String> profileNames=new HashMap<UUID,String>();
    private final Map<Integer,Player> players=new HashMap<Integer,Player>();
    private final Set<Integer> visible=new HashSet<Integer>();

    static final class Player {
        final int entityId;
        final UUID uuid;
        double x,y,z;
        byte yaw,pitch;
        Player(int id, UUID uuid,double x,double y,double z,byte yaw,byte pitch) {
            entityId=id;this.uuid=uuid;this.x=x;this.y=y;this.z=z;this.yaw=yaw;this.pitch=pitch;
        }
    }
    EntityTranslator(Gateway.Session destination) {this.destination=destination;}
    void reset() throws IOException {
        for(int id:visible)destroy(id);
        visible.clear();players.clear();profileNames.clear();
    }
    String profileName(UUID id) {return profileNames.get(id);}
    int tracked() {return players.size();}
    int shown() {return visible.size();}
    private static UUID uuid(DataInputStream in)throws IOException {return new UUID(in.readLong(),in.readLong());}
    static void skipLpVelocity(DataInputStream in)throws IOException {
        int low=in.readUnsignedByte();
        if(low!=0) {
            in.readUnsignedByte();in.readInt();
            if((low&4)!=0)Wire.var(in);
        }
    }
    void playerInfo(DataInputStream in) throws IOException {
        int flags=in.readUnsignedByte(); // 8 ordered enum actions, FixedBitSet<8>
        int count=Wire.var(in);
        if(count<0||count>MAX_PLAYERS)throw new IOException("PlayerInfo count invalid: "+count);
        for(int i=0;i<count;i++) {
            UUID id=uuid(in);
            String name=null;
            if((flags&1)!=0) {
                name=Wire.str(in);
                int properties=Wire.var(in);
                if(properties<0||properties>64)throw new IOException("Too many profile properties: "+properties);
                for(int p=0;p<properties;p++) {
                    Wire.str(in); Wire.str(in);
                    if(in.readBoolean())Wire.str(in);
                }
            }
            if((flags&2)!=0 && in.readBoolean()) {
                uuid(in);in.readLong();Wire.bytes(in,8192);Wire.bytes(in,8192);
            }
            if((flags&4)!=0)Wire.var(in); // game mode
            if((flags&8)!=0)in.readBoolean(); // listed
            if((flags&16)!=0)Wire.var(in); // latency
            if((flags&32)!=0 && in.readBoolean())TextComponent.readFormatted(in); // displayed name
            if((flags&64)!=0)Wire.var(in); // tab priority
            if((flags&128)!=0)in.readBoolean(); // hat
            if(name!=null && !name.isEmpty()) {
                name=name.length()>16?name.substring(0,16):name;
                profileNames.put(id,name);
                for(Player player:players.values())if(player.uuid.equals(id))show(player);
            }
        }
    }
    void playerInfoRemove(DataInputStream in)throws IOException {
        int n=Wire.var(in);
        if(n<0||n>MAX_PLAYERS)throw new IOException("PlayerInfoRemove count invalid: "+n);
        for(int i=0;i<n;i++)profileNames.remove(uuid(in));
    }
    void addEntity(DataInputStream in)throws IOException {
        int entityId=Wire.var(in);
        UUID id=uuid(in);
        int type=Wire.var(in);
        double x=in.readDouble(),y=in.readDouble(),z=in.readDouble();
        skipLpVelocity(in);
        byte pitch=in.readByte(),yaw=in.readByte();in.readByte(); // head yaw
        Wire.var(in); // entity type-specific data
        if(type!=PLAYER_TYPE_ID || entityId==destination.localEntityId())return;
        if(!Double.isFinite(x)||!Double.isFinite(y)||!Double.isFinite(z))return;
        Player player=new Player(entityId,id,x,y,z,yaw,pitch);
        players.put(entityId,player);show(player);
    }
    private boolean inside(Player player) {
        double y=player.y-destination.baseY();
        return destination.ready() && y>=0 && y<127;
    }
    private static int fixed(double v) {
        if(!Double.isFinite(v))return 0;
        return (int)Math.max(Integer.MIN_VALUE+1024L,Math.min(Integer.MAX_VALUE-1024L,Math.floor(v*32.0)));
    }
    private void show(Player player) throws IOException {
        if(!inside(player)||visible.contains(player.entityId))return;
        String name=profileNames.get(player.uuid);
        if(name==null||name.isEmpty())return;
        visible.add(player.entityId);
        final int entity=player.entityId;
        final int x=fixed(player.x),y=fixed(player.y-destination.baseY()),z=fixed(player.z);
        final byte yaw=player.yaw,pitch=player.pitch;
        destination.legacy(20,o->{
            o.writeInt(entity);o.writeUTF(name);o.writeInt(x);o.writeInt(y);o.writeInt(z);
            o.writeByte(yaw);o.writeByte(pitch);o.writeShort(0);
        });
    }
    private void destroy(int id)throws IOException {destination.legacy(29,o->o.writeInt(id));}
    void reprojection() throws IOException {
        for(Integer id:visible)destroy(id);
        visible.clear();
        for(Player player:players.values())show(player);
    }
    void removeEntities(DataInputStream in)throws IOException {
        int n=Wire.var(in);
        if(n<0||n>4096)throw new IOException("RemoveEntities count invalid: "+n);
        for(int i=0;i<n;i++){
            int id=Wire.var(in);players.remove(id);
            if(visible.remove(id))destroy(id);
        }
    }
    void relative(DataInputStream in,int packetId)throws IOException {
        int id=Wire.var(in);
        Player p=players.get(id);
        boolean move=packetId==GameIds.CLIENTBOUND_MOVE_ENTITY_POS||packetId==GameIds.CLIENTBOUND_MOVE_ENTITY_POS_ROT;
        boolean rot=packetId==GameIds.CLIENTBOUND_MOVE_ENTITY_ROT||packetId==GameIds.CLIENTBOUND_MOVE_ENTITY_POS_ROT;
        double dx=0,dy=0,dz=0;
        if(move){dx=in.readShort()/4096.0;dy=in.readShort()/4096.0;dz=in.readShort()/4096.0;}
        byte yaw=0,pitch=0;
        if(rot){yaw=in.readByte();pitch=in.readByte();}
        in.readBoolean();
        if(p==null)return;
        double oldX=p.x,oldY=p.y,oldZ=p.z;
        if(move){p.x+=dx;p.y+=dy;p.z+=dz;}
        if(rot){p.yaw=yaw;p.pitch=pitch;}
        update(p,oldX,oldY,oldZ,move,rot);
    }
    private void update(Player p,double oldX,double oldY,double oldZ,boolean move,boolean rot)throws IOException {
        if(!inside(p)){
            if(visible.remove(p.entityId))destroy(p.entityId);
            return;
        }
        if(!visible.contains(p.entityId)){show(p);return;}
        if(move){
            int dx=fixed(p.x)-fixed(oldX),dy=fixed(p.y)-fixed(oldY),dz=fixed(p.z)-fixed(oldZ);
            if(dx<-128||dx>127||dy<-128||dy>127||dz<-128||dz>127){absolute(p);return;}
            final int id=p.entityId,xd=dx,yd=dy,zd=dz;
            if(rot)destination.legacy(33,o->{o.writeInt(id);o.writeByte(xd);o.writeByte(yd);o.writeByte(zd);o.writeByte(p.yaw);o.writeByte(p.pitch);});
            else destination.legacy(31,o->{o.writeInt(id);o.writeByte(xd);o.writeByte(yd);o.writeByte(zd);});
        } else if(rot){
            final int id=p.entityId;
            destination.legacy(32,o->{o.writeInt(id);o.writeByte(p.yaw);o.writeByte(p.pitch);});
        }
    }
    private void absolute(Player p)throws IOException {
        if(!visible.contains(p.entityId)){show(p);return;}
        final int id=p.entityId, x=fixed(p.x),y=fixed(p.y-destination.baseY()),z=fixed(p.z);
        destination.legacy(34,o->{o.writeInt(id);o.writeInt(x);o.writeInt(y);o.writeInt(z);o.writeByte(p.yaw);o.writeByte(p.pitch);});
    }
    void absoluteSync(DataInputStream in,boolean relative)throws IOException {
        int id=Wire.var(in);
        double x=in.readDouble(),y=in.readDouble(),z=in.readDouble();
        in.readDouble();in.readDouble();in.readDouble(); // delta velocity
        float yaw=in.readFloat(),pitch=in.readFloat();
        int flags=relative?in.readInt():0;
        in.readBoolean();
        Player player=players.get(id);
        if(player==null)return;
        if(relative){
            if((flags&1)!=0)x+=player.x;if((flags&2)!=0)y+=player.y;if((flags&4)!=0)z+=player.z;
            if((flags&8)!=0)yaw+=player.yaw*360.0f/256.0f;
            if((flags&16)!=0)pitch+=player.pitch*360.0f/256.0f;
        }
        player.x=x;player.y=y;player.z=z;
        player.yaw=(byte)Math.round(yaw*256/360.0);
        player.pitch=(byte)Math.round(pitch*256/360.0);
        if(!inside(player)){
            if(visible.remove(id))destroy(id);
        }else absolute(player);
    }
    void head(DataInputStream in)throws IOException {
        int id=Wire.var(in);byte yaw=in.readByte();Player player=players.get(id);
        if(player!=null)player.yaw=yaw;
    }
}
