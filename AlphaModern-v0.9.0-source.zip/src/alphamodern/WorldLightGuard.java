package alphamodern;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * In protocol-bridged sessions, modern chunks already carry light nibble arrays.
 * Alpha's recursive relighting scheduler is not compatible with the quantity of
 * translated world changes: it produced >113 million work requests in one live
 * session even with a capped queue. Reject them before constructing kb jobs.
 *
 * Outside the bridge, delegate to the ORIGINAL cj.d(x,y,z) check, preserving
 * vanilla Alpha's behavior and normal singleplayer lighting. The original
 * method is looked up once per class, not reflectively invoked per job.
 */
public final class WorldLightGuard {
    private static final AtomicInteger ACTIVE = new AtomicInteger();
    private static final AtomicLong SKIPPED = new AtomicLong();
    private static final ClassValue<MethodHandle> ORIGINAL_CAN_LIGHT = new ClassValue<MethodHandle>() {
        @Override protected MethodHandle computeValue(Class<?> type) {
            try {
                MethodType signature = MethodType.methodType(boolean.class,
                    int.class,int.class,int.class);
                return MethodHandles.publicLookup().findVirtual(type,"d",signature)
                    .asType(MethodType.methodType(boolean.class,Object.class,
                        int.class,int.class,int.class));
            } catch (NoSuchMethodException e) {
                throw new IllegalStateException("Unknown Alpha world lighting method",e);
            } catch (IllegalAccessException e) {
                throw new IllegalStateException("Cannot access original Alpha world lighting check",e);
            }
        }
    };

    private WorldLightGuard() {}

    static void beginBridge() {
        if(ACTIVE.incrementAndGet()==1) {
            SKIPPED.set(0);
            System.out.println(AlphaModernAgent.PREFIX+
                "Modern lighting mode: disabled Alpha's recursive relighting scheduler");
        }
    }
    static void endBridge() {
        while(true) {
            int n=ACTIVE.get();
            if(n==0)return;
            if(ACTIVE.compareAndSet(n,n-1))return;
        }
    }

    /**
     * Replaces only the invokevirtual cj.d(III)Z at bytecode index 24 in
     * cj.a(bu,IIIIIIZ)V. Inputs are the original receiver and arguments.
     * The bridge check happens before Alpha scans, allocates and queues any
     * legacy lighting work. On ordinary Alpha worlds, run the actual method.
     */
    public static boolean allowOriginalLight(Object world, int x, int y, int z) {
        if(ACTIVE.get()!=0) {
            SKIPPED.incrementAndGet();
            return false;
        }
        try {
            return (boolean)ORIGINAL_CAN_LIGHT.get(world.getClass())
                .invokeExact(world,x,y,z);
        } catch(Throwable e) {
            throw new IllegalStateException("Alpha original light eligibility check failed",e);
        }
    }

    /** Failsafe for rare list-add paths; never schedule bridged relighting. */
    @SuppressWarnings({"rawtypes", "unchecked"})
    public static boolean offer(List jobs,Object job) {
        if(ACTIVE.get()!=0)return false;
        return jobs.add(job);
    }

    static long dropped() {return SKIPPED.get();}
    static int active() {return ACTIVE.get();}
}
