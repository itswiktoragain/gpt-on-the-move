package alphamodern;

import java.io.*;
import java.lang.instrument.ClassFileTransformer;
import java.nio.charset.StandardCharsets;
import java.security.ProtectionDomain;
import java.util.HashMap;
import java.util.Map;

/**
 * Surgical, size-neutral Alpha 1.0.15 cj.class patch.
 *
 * At BCI 24 in cj.a(Lbu;IIIIIIZ)V change the original
 *   invokevirtual cj.d:(III)Z
 * to an equal-length
 *   invokestatic WorldLightGuard.allowOriginalLight:(Ljava/lang/Object;III)Z.
 *
 * The original world instance and x,y,z are already on the stack; the helper
 * skips the scheduler in modern multiplayer and delegates to the real cj.d in
 * vanilla worlds. No other method's geometry, jumps or stack depths change.
 *
 * At BCI 155, keep the failsafe List.add bridge guard introduced in v0.8.1.
 */
final class WorldLightPatch implements ClassFileTransformer {
    @Override public byte[] transform(ClassLoader loader,String name,Class<?> cls,
                                       ProtectionDomain pd,byte[] bytes) {
        if(!"cj".equals(name))return null;
        try {
            byte[] patched=patch(bytes);
            System.out.println(AlphaModernAgent.PREFIX+
                "Patched Alpha relighting at source (cj); no more legacy light storms");
            return patched;
        } catch(Exception e) {
            System.err.println(AlphaModernAgent.PREFIX+"World-light patch rejected: "+e);
            return null;
        }
    }

    static byte[] patch(byte[] original) throws IOException {
        DataInputStream in=new DataInputStream(new ByteArrayInputStream(original));
        ByteArrayOutputStream output=new ByteArrayOutputStream(original.length+256);
        DataOutputStream out=new DataOutputStream(output);
        if(in.readInt()!=0xcafebabe)throw new IOException("Not classfile");
        int minor=in.readUnsignedShort(),major=in.readUnsignedShort();
        if(major!=49)throw new IOException("Expected Alpha 1.0.15 Java 5 classfile");
        out.writeInt(0xcafebabe);out.writeShort(minor);out.writeShort(major);
        int oldCount=in.readUnsignedShort();
        if(oldCount>65525)throw new IOException("Constant pool exhausted");
        out.writeShort(oldCount+10);
        Map<Integer,String> utf=new HashMap<Integer,String>();
        for(int i=1;i<oldCount;i++) {
            int tag=in.readUnsignedByte();out.writeByte(tag);
            switch(tag) {
                case 1: {
                    int n=in.readUnsignedShort();byte[] b=new byte[n];in.readFully(b);
                    utf.put(i,new String(b,StandardCharsets.UTF_8));
                    out.writeShort(n);out.write(b);break;
                }
                case 3:case 4:case 9:case 10:case 11:case 12:case 17:case 18:copy(in,out,4);break;
                case 5:case 6:copy(in,out,8);i++;break;
                case 7:case 8:case 16:case 19:case 20:copy(in,out,2);break;
                case 15:copy(in,out,3);break;
                default:throw new IOException("Unknown constant type "+tag);
            }
        }
        // 10 new pool entries: one Class and two static Methodref entries.
        utf8(out,"alphamodern/WorldLightGuard");
        out.writeByte(7);out.writeShort(oldCount);
        utf8(out,"allowOriginalLight");
        utf8(out,"(Ljava/lang/Object;III)Z");
        out.writeByte(12);out.writeShort(oldCount+2);out.writeShort(oldCount+3);
        out.writeByte(10);out.writeShort(oldCount+1);out.writeShort(oldCount+4);
        int eligibilityRef=oldCount+5;
        utf8(out,"offer");
        utf8(out,"(Ljava/util/List;Ljava/lang/Object;)Z");
        out.writeByte(12);out.writeShort(oldCount+6);out.writeShort(oldCount+7);
        out.writeByte(10);out.writeShort(oldCount+1);out.writeShort(oldCount+8);
        int offerRef=oldCount+9;
        copy(in,out,6);
        int interfaces=in.readUnsignedShort();out.writeShort(interfaces);copy(in,out,interfaces*2);
        int fields=in.readUnsignedShort();out.writeShort(fields);
        for(int i=0;i<fields;i++)member(in,out,utf,false,eligibilityRef,offerRef);
        int methods=in.readUnsignedShort();out.writeShort(methods);
        int patched=0;
        for(int i=0;i<methods;i++)patched+=member(in,out,utf,true,eligibilityRef,offerRef);
        if(patched!=2)throw new IOException("Expected two Alpha lighting sites, got "+patched);
        int attrs=in.readUnsignedShort();out.writeShort(attrs);
        for(int i=0;i<attrs;i++)attribute(in,out,utf,false,eligibilityRef,offerRef);
        if(in.read()!=-1)throw new IOException("Trailing data after cj.class");
        out.flush();return output.toByteArray();
    }
    private static int member(DataInputStream in,DataOutputStream out,
                              Map<Integer,String> utf,boolean method,int eligibilityRef,int offerRef) throws IOException {
        out.writeShort(in.readUnsignedShort());
        int name=in.readUnsignedShort(),desc=in.readUnsignedShort();
        out.writeShort(name);out.writeShort(desc);
        boolean target=method && "a".equals(utf.get(name)) && "(Lbu;IIIIIIZ)V".equals(utf.get(desc));
        int attrs=in.readUnsignedShort();out.writeShort(attrs);
        int hits=0;
        for(int i=0;i<attrs;i++)hits+=attribute(in,out,utf,target,eligibilityRef,offerRef);
        if(target&&hits!=2)throw new IOException("Cannot identify original lighting scheduler code");
        return hits;
    }
    private static int attribute(DataInputStream in,DataOutputStream out,
                                 Map<Integer,String> utf,boolean target,int eligibilityRef,int offerRef) throws IOException {
        int name=in.readUnsignedShort(),size=in.readInt();
        if(size<0||size>10000000)throw new IOException("Invalid attribute size "+size);
        byte[] body=new byte[size];in.readFully(body);
        int changed=0;
        if(target&&"Code".equals(utf.get(name))) {
            if(size<8)throw new IOException("Missing method code");
            int codeLength=((body[4]&255)<<24)|((body[5]&255)<<16)|((body[6]&255)<<8)|(body[7]&255);
            if(codeLength!=198||codeLength+8>size)throw new IOException("Unexpected cj.a code length "+codeLength);
            if((body[8+17]&255)!=0x2a || (body[8+18]&255)!=0x15 || (body[8+19]&255)!=0x09 ||
                (body[8+20]&255)!=0x10 || (body[8+21]&255)!=64 ||
                (body[8+22]&255)!=0x15 || (body[8+23]&255)!=10 ||
                (body[8+24]&255)!=0xb6 || (body[8+27]&255)!=0x9a ||
                (body[8+30]&255)!=0xb1)
                throw new IOException("Alpha early-relight signature mismatch");
            int early=8+24;
            body[early]=(byte)0xb8;
            body[early+1]=(byte)(eligibilityRef>>>8);
            body[early+2]=(byte)eligibilityRef;
            changed++;
            int add=8+155;
            if((body[add]&255)!=0xb9 || (body[add+3]&255)!=2 || (body[add+4]&255)!=0 ||
               (body[8+160]&255)!=0x57 || (body[8+189]&255)!=0x2a ||
               (body[8+190]&255)!=0xb6 || (body[8+194]&255)!=0xa7)
                throw new IOException("Alpha lighting list guard signature mismatch");
            body[add]=(byte)0xb8;
            body[add+1]=(byte)(offerRef>>>8);
            body[add+2]=(byte)offerRef;
            body[add+3]=0;body[add+4]=0;
            changed++;
        }
        out.writeShort(name);out.writeInt(size);out.write(body);
        return changed;
    }
    private static void utf8(DataOutputStream out,String s)throws IOException {
        byte[] b=s.getBytes(StandardCharsets.UTF_8);
        out.writeByte(1);out.writeShort(b.length);out.write(b);
    }
    private static void copy(DataInputStream in,DataOutputStream out,int n)throws IOException {
        byte[] b=new byte[n];in.readFully(b);out.write(b);
    }
}
