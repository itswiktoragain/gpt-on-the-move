package alphamodern;

import java.io.*;
import java.net.*;
import java.util.*;
import java.lang.reflect.Field;

public class EntityAndStatesTest {
    static void ok(boolean yes,String message){if(!yes)throw new AssertionError(message);}
    static byte[] packet(Wire.Writer writer)throws IOException {
        ByteArrayOutputStream b=new ByteArrayOutputStream();DataOutputStream o=new DataOutputStream(b);writer.write(o);o.flush();return b.toByteArray();
    }
    static void set(Object o,String field,Object value)throws Exception {
        Field f=o.getClass().getDeclaredField(field);f.setAccessible(true);f.set(o,value);
    }
    static void testPlayer()throws Exception {
        ByteArrayOutputStream toAlpha=new ByteArrayOutputStream();
        try(ServerSocket server=new ServerSocket(0,1,InetAddress.getLoopbackAddress());
            Socket client=new Socket(InetAddress.getLoopbackAddress(),server.getLocalPort());
            Socket remote=server.accept()){
            Gateway.Session session=new Gateway.Session(new DataInputStream(new ByteArrayInputStream(new byte[0])),
                new DataOutputStream(toAlpha),client,"Tester","localhost",server.getLocalPort());
            set(session,"alphaLoggedIn",true);set(session,"viewportReady",true);set(session,"viewportBaseY",176);set(session,"localEntityId",99);
            EntityTranslator entities=new EntityTranslator(session);
            UUID id=UUID.fromString("01234567-89ab-cdef-0123-456789abcdef");
            byte[] info=packet(o->{o.writeByte(1);Wire.var(o,1);Wire.uuid(o,id);Wire.str(o,"OtherPlayer");Wire.var(o,0);});
            entities.playerInfo(new DataInputStream(new ByteArrayInputStream(info)));
            byte[] spawn=packet(o->{Wire.var(o,23);Wire.uuid(o,id);Wire.var(o,156);
                o.writeDouble(30.5);o.writeDouble(250.0);o.writeDouble(-10.25);
                o.writeByte(0); // LpVec3.ZERO
                o.writeByte(20);o.writeByte(40);o.writeByte(40);Wire.var(o,0);
            });
            entities.addEntity(new DataInputStream(new ByteArrayInputStream(spawn)));
            DataInputStream alpha=new DataInputStream(new ByteArrayInputStream(toAlpha.toByteArray()));
            ok(alpha.readUnsignedByte()==20,"Alpha named entity spawn missing");
            ok(alpha.readInt()==23,"entity ID missing");
            ok("OtherPlayer".equals(alpha.readUTF()),"profile info name lost");
            ok(alpha.readInt()==976&&alpha.readInt()==2368&&alpha.readInt()==-328,"wrong player fixed point");
            ok(alpha.readUnsignedByte()==40 && alpha.readUnsignedByte()==20,"rotation ordering swapped");
            ok(alpha.readShort()==0,"held item must default 0");
            ok(entities.shown()==1,"player not visible");
            toAlpha.reset();
            byte[] move=packet(o->{Wire.var(o,23);o.writeShort(2048);o.writeShort(0);o.writeShort(-1024);o.writeBoolean(true);});
            entities.relative(new DataInputStream(new ByteArrayInputStream(move)),GameIds.CLIENTBOUND_MOVE_ENTITY_POS);
            alpha=new DataInputStream(new ByteArrayInputStream(toAlpha.toByteArray()));
            ok(alpha.readUnsignedByte()==31,"Alpha relative player movement not translated");
            ok(alpha.readInt()==23&&alpha.readByte()==16&&alpha.readByte()==0&&alpha.readByte()==-8,"bad relative offsets");
            toAlpha.reset();
            byte[] remove=packet(o->{Wire.var(o,1);Wire.var(o,23);});
            entities.removeEntities(new DataInputStream(new ByteArrayInputStream(remove)));
            alpha=new DataInputStream(new ByteArrayInputStream(toAlpha.toByteArray()));
            ok(alpha.readUnsignedByte()==29&&alpha.readInt()==23,"player was not despawned");
            ok(entities.shown()==0,"player tracking stale");
            session.close();
        }
        System.out.println("PASS: 26.2 player-info, spawn, rotation, movement and removal translated into real Alpha packet layout");
    }
    static void testOrientations(){
        int[] northSouthWestEast={3,2,1,0};
        for(int facing=0;facing<4;facing++){
            int state=3907+facing*20;
            ok(ChunkTranslator.toOld(state)==53,"wrong block id for oak stairs " +state);
            ok(ChunkTranslator.toMeta(state)==northSouthWestEast[facing],"stair orientation mismatch "+state);
        }
        for(int facing=0;facing<4;facing++){
            int state=5747+facing*20;
            ok(ChunkTranslator.toMeta(state)==northSouthWestEast[facing],"cobble stair orientation mismatch "+state);
        }
        ok(ChunkTranslator.toOld(13330)==44,"wood slabs must not be rendered as full cubes");
        ok(ChunkTranslator.toOld(8646)==0,"fence gates must not be rendered as full cubes");
        System.out.println("PASS: wood and cobble stairs preserve N/S/W/E; slabs and thin modern blocks no longer full-cube obstacles");
    }
    public static void main(String[] args)throws Exception {testOrientations();testPlayer();}
}
