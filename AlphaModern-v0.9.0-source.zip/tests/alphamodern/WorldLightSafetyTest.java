package alphamodern;

import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

/** v0.8.2 regression for ~113 million unwanted Alpha lighting requests. */
public final class WorldLightSafetyTest {
    static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
    public static final class FakeAlphaWorld {
        public int calls;
        public boolean d(int x,int y,int z){calls++;return y>=0&&y<128&&x==z;}
    }
    public static void main(String[] args) throws Exception {
        FakeAlphaWorld world=new FakeAlphaWorld();
        List<Object> jobs=new ArrayList<Object>();
        check(WorldLightGuard.allowOriginalLight(world,5,64,5),"vanilla world check must work");
        check(!WorldLightGuard.allowOriginalLight(world,5,200,5),"vanilla world check must reject height");
        check(world.calls==2,"vanilla method must be delegated to exactly once per call");
        check(WorldLightGuard.offer(jobs,new Object()),"vanilla world list.add must be unchanged");
        check(jobs.size()==1,"vanilla light list missing item");
        jobs.clear();
        WorldLightGuard.beginBridge();
        try {
            // The live 0.8.1 log had 113+ million delayed light requests.
            // They must be short-circuited before the old world check and
            // List.add, with no expensive allocations or queue buildup.
            for(int i=0;i<2_000_000;i++) {
                if(WorldLightGuard.allowOriginalLight(world,5,64,5))throw new AssertionError("bridge queued light");
                if((i%50000)==0)check(!WorldLightGuard.offer(jobs,new Object()),"bridge accepted a job");
            }
            check(world.calls==2,"bridge called original light calculation");
            check(jobs.isEmpty(),"bridge produced legacy light jobs");
            check(WorldLightGuard.dropped()==2_000_000L,"skipped early requests not counted");
        }finally{WorldLightGuard.endBridge();}
        check(WorldLightGuard.allowOriginalLight(world,5,64,5),"original check not restored after bridge");
        check(WorldLightGuard.offer(jobs,new Object()),"original list.add not restored");
        check(world.calls==3,"restored delegate didn't call vanilla world");

        Path alpha=Paths.get(args.length>0?args[0]:"/mnt/data/minecraft-a1.0.15-client.jar");
        if(Files.isRegularFile(alpha)){
            byte[] orig,patched;
            try(ZipFile zip=new ZipFile(alpha.toFile());InputStream in=zip.getInputStream(zip.getEntry("cj.class"))){
                orig=AlphaModernAgent.readAll(in);
            }
            patched=WorldLightPatch.patch(orig);
            check(patched.length>orig.length,"methodrefs must be in constant pool");
            String data=new String(patched,"ISO-8859-1");
            check(data.contains("allowOriginalLight")&&data.contains("(Ljava/lang/Object;III)Z"),"early guard not installed");
            check(data.contains("offer")&&data.contains("(Ljava/util/List;Ljava/lang/Object;)Z"),"list failsafe not installed");
            try(URLClassLoader loader=new URLClassLoader(new URL[]{alpha.toUri().toURL()},WorldLightSafetyTest.class.getClassLoader()){
                @Override protected Class<?> findClass(String name)throws ClassNotFoundException{
                    if(name.equals("cj"))return defineClass(name,patched,0,patched.length);
                    return super.findClass(name);
                }
            }){
                Class<?> type=Class.forName("cj",false,loader);
                type.getDeclaredMethod("a",Class.forName("bu",false,loader),int.class,int.class,
                    int.class,int.class,int.class,int.class,boolean.class);
            }
            System.out.println("PASS: patched original Alpha cj.class links and retains bytecode layout");
        }else System.out.println("SKIP: Alpha original JAR not available for bytecode test");
        System.out.println("PASS: 2,000,000 legacy light requests bypassed with zero jobs; vanilla delegation intact");
        System.out.println("ALL LIGHTING PERFORMANCE TESTS PASSED");
    }
}
