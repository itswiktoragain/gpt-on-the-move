package alphamodern;

import java.io.*;
import java.lang.instrument.ClassFileTransformer;
import java.nio.charset.StandardCharsets;
import java.security.ProtectionDomain;
import java.util.HashMap;
import java.util.Map;

/** Fixes the Alpha 1.0.15 FontRenderer (§ color-code) out-of-bounds crash.
 *  The original implementation jumps to bytecode offset 152 (String.charAt)
 *  after consuming a color code, instead of 143 (loop length check).
 *  Patch only the exact known Java 5 class method with a verified byte signature.
 */
final class FontRendererPatch implements ClassFileTransformer {
    @Override public byte[] transform(ClassLoader loader,String name,Class<?> cls,ProtectionDomain pd,byte[] data) {
        if(!"js".equals(name))return null;
        try {
            byte[] result=patch(data);
            System.out.println(AlphaModernAgent.PREFIX+"Patched Alpha font renderer color-code crash (js)");
            return result;
        } catch(Exception e) {
            System.err.println(AlphaModernAgent.PREFIX+"Font renderer patch rejected: "+e);
            return null;
        }
    }
    static byte[] patch(byte[] bytes) throws IOException {
        DataInputStream in=new DataInputStream(new ByteArrayInputStream(bytes));
        ByteArrayOutputStream buf=new ByteArrayOutputStream(bytes.length);
        DataOutputStream out=new DataOutputStream(buf);
        if(in.readInt()!=0xcafebabe)throw new IOException("Not a JVM class file");
        out.writeInt(0xcafebabe);
        int minor=in.readUnsignedShort(),major=in.readUnsignedShort();
        if(major!=49)throw new IOException("Expected original Alpha Java 5 class");
        out.writeShort(minor);out.writeShort(major);
        int cpCount=in.readUnsignedShort();out.writeShort(cpCount);
        Map<Integer,String> utf=new HashMap<Integer,String>();
        boolean fontSignature=false;
        for(int i=1;i<cpCount;i++) {
            int tag=in.readUnsignedByte();out.writeByte(tag);
            switch(tag) {
                case 1: {
                    int n=in.readUnsignedShort();byte[] b=new byte[n];in.readFully(b);
                    String value=new String(b,StandardCharsets.UTF_8);
                    if(value.equals("0123456789abcdef"))fontSignature=true;
                    utf.put(i,value);out.writeShort(n);out.write(b);break;
                }
                case 3:case 4:case 9:case 10:case 11:case 12:case 17:case 18: copy(in,out,4);break;
                case 5:case 6:copy(in,out,8);i++;break;
                case 7:case 8:case 16:case 19:case 20:copy(in,out,2);break;
                case 15:copy(in,out,3);break;
                default:throw new IOException("Unexpected class constant "+tag);
            }
        }
        if(!fontSignature)throw new IOException("Not the expected Alpha font renderer");
        copy(in,out,6);
        int interfaces=in.readUnsignedShort();out.writeShort(interfaces);copy(in,out,interfaces*2);
        int fields=in.readUnsignedShort();out.writeShort(fields);
        for(int i=0;i<fields;i++)copyMember(in,out,utf,false);
        int methods=in.readUnsignedShort();out.writeShort(methods);
        int patched=0;
        for(int i=0;i<methods;i++)patched+=copyMember(in,out,utf,true);
        if(patched!=1)throw new IOException("Expected one crash-prone font drawing method, patched "+patched);
        int attrs=in.readUnsignedShort();out.writeShort(attrs);
        for(int i=0;i<attrs;i++)copyAttr(in,out,utf,false);
        if(in.read()!=-1)throw new IOException("Unexpected class trailer");
        out.flush();return buf.toByteArray();
    }
    private static int copyMember(DataInputStream in,DataOutputStream out,Map<Integer,String> utf,boolean method) throws IOException {
        out.writeShort(in.readUnsignedShort());
        int name=in.readUnsignedShort(),desc=in.readUnsignedShort();out.writeShort(name);out.writeShort(desc);
        boolean target=method && "a".equals(utf.get(name)) && "(Ljava/lang/String;IIIZ)V".equals(utf.get(desc));
        int attrs=in.readUnsignedShort();out.writeShort(attrs);
        int hits=0;
        for(int i=0;i<attrs;i++)hits+=copyAttr(in,out,utf,target);
        if(target&&hits!=1)throw new IOException("Could not identify font renderer bytecode");
        return hits;
    }
    private static int copyAttr(DataInputStream in,DataOutputStream out,Map<Integer,String> utf,boolean target) throws IOException {
        int name=in.readUnsignedShort(),size=in.readInt();
        if(size<0||size>10_000_000)throw new IOException("Invalid class attribute size");
        byte[] body=new byte[size];in.readFully(body);
        int changed=target&&"Code".equals(utf.get(name))?1:0;
        if(changed!=0){
            // Code attribute layout: max_stack:u2, max_locals:u2, length:u4, code[length].
            DataInputStream code=new DataInputStream(new ByteArrayInputStream(body));
            code.readUnsignedShort();code.readUnsignedShort();int length=code.readInt();
            if(length!=373 || body.length<8+length)throw new IOException("Unexpected Alpha font draw method length "+length);
            // Original: iinc 6,2; goto 152. Fixed: goto 143 (loop condition).
            if((body[8+273]&255)!=0x84||(body[8+274]&255)!=6||(body[8+275]&255)!=2 ||
               (body[8+276]&255)!=0xa7||(body[8+277]&255)!=0xff||(body[8+278]&255)!=0x84 ||
               (body[8+143]&255)!=0x15)
                throw new IOException("Font bytecode signature mismatch; refusing unsafe patch");
            body[8+278]=0x7b; // 276 + signed(-133) = 143
        }
        out.writeShort(name);out.writeInt(body.length);out.write(body);return changed;
    }
    private static void copy(DataInputStream in,DataOutputStream out,int size) throws IOException {
        byte[] b=new byte[size];in.readFully(b);out.write(b);
    }
}
