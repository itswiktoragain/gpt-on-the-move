package alphamodern;

import java.awt.Desktop;
import java.awt.Toolkit;
import java.awt.datatransfer.DataFlavor;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.function.BooleanSupplier;

/** Render and keyboard handling on Alpha's connecting screen. No Microsoft passwords are collected. */
public final class AuthOverlay {
    private AuthOverlay() {}
    static volatile State state;
    static final class State {
        final String heading,site,code,detail,email;
        final long until;
        State(String h,String s,String c,String d,String email,long expiry){
            heading=h;site=s;code=c;detail=d;this.email=email;until=expiry;
        }
    }
    private static final Object EMAIL_LOCK=new Object();
    private static final class EmailRequest {
        final StringBuilder text=new StringBuilder();
        String error="", accepted;
    }
    private static EmailRequest pendingEmail;
    private static volatile boolean gameMode;
    private static volatile String testEmail;

    static void enableInGameInput(){gameMode=true;}
    /** Package-private override used only by local integration tests, never by production launch paths. */
    static void setEmailForTests(String email){testEmail=email;}

    static void status(String heading,String detail) {
        state=new State(heading,"","",detail,"",0);
        System.out.println(AlphaModernAgent.PREFIX+heading+(detail.isEmpty()?"":" - "+detail));
    }
    static void code(String url,String code,long expiresAt) {code(url,code,expiresAt,"");}
    static void code(String url,String code,long expiresAt,String email) {
        state=new State("Link Microsoft account",url,code,"Enter code on the official Microsoft page",email,expiresAt);
        System.out.println(AlphaModernAgent.PREFIX+"Microsoft device login: " + url + "  CODE: " + code);
        openVerification(url);
    }
    static void clear(){state=null;}

    /** Email is an on-screen account hint, NOT an input to Microsoft's device-code endpoint. */
    static String requestEmail(BooleanSupplier active) throws IOException {
        if(testEmail!=null){
            if(!validEmail(testEmail))throw new IOException("Invalid local test email");
            return testEmail;
        }
        if(!gameMode)return readConsoleEmail(active);
        EmailRequest request=new EmailRequest();
        synchronized(EMAIL_LOCK){
            if(pendingEmail!=null)throw new IOException("Another email entry is already active");
            pendingEmail=request;
            updateEmailState(request);
        }
        try {
            while(true){
                if(!active.getAsBoolean())throw new IOException("Email entry cancelled");
                synchronized(EMAIL_LOCK){
                    if(request.accepted!=null)return request.accepted;
                    try{EMAIL_LOCK.wait(150L);}
                    catch(InterruptedException e){Thread.currentThread().interrupt();throw new IOException("Email entry interrupted",e);}
                }
            }
        }finally{
            synchronized(EMAIL_LOCK){if(pendingEmail==request)pendingEmail=null;}
        }
    }
    private static String readConsoleEmail(BooleanSupplier active) throws IOException {
        BufferedReader reader=new BufferedReader(new InputStreamReader(System.in,StandardCharsets.UTF_8));
        for(int attempt=0;attempt<5;attempt++){
            if(!active.getAsBoolean())throw new IOException("Email entry cancelled");
            System.out.print(AlphaModernAgent.PREFIX+"Enter the Microsoft account email to use on the verification page: ");
            String input=reader.readLine();
            if(input==null)throw new IOException("No email provided. Run from a terminal to link your Microsoft account.");
            String email=input.trim();
            if(validEmail(email))return email;
            System.out.println(AlphaModernAgent.PREFIX+"That doesn't look like an email address. Try again.");
        }
        throw new IOException("No valid email supplied");
    }
    static boolean validEmail(String email){
        if(email==null||email.length()<5||email.length()>254||!email.equals(email.trim()))return false;
        int at=email.indexOf('@');
        if(at<1||at>64||at!=email.lastIndexOf('@')||at>=email.length()-3)return false;
        String domain=email.substring(at+1);
        if(domain.startsWith(".")||domain.endsWith(".")||domain.indexOf('.')<1||domain.contains(".."))return false;
        for(int i=0;i<email.length();i++) {
            char c=email.charAt(i);
            if(Character.isISOControl(c)||Character.isWhitespace(c))return false;
        }
        return true;
    }
    /** Injected into mb.a(CI)V, formerly an empty method. keyCode is LWJGL's keyboard code. */
    public static void key(char typed,int keyCode) {
        synchronized(EMAIL_LOCK){
            EmailRequest request=pendingEmail;
            if(request==null||request.accepted!=null)return;
            if(keyCode==28||keyCode==156) { // Enter and numpad Enter
                String email=request.text.toString().trim();
                if(validEmail(email)){
                    request.accepted=email;
                    state=new State("Requesting sign-in code","","","Use the chosen email on the Microsoft website",email,0);
                    EMAIL_LOCK.notifyAll();
                }else{
                    request.error="Enter a valid email address before pressing Enter";
                    updateEmailState(request);
                }
                return;
            }
            if(keyCode==14) { // Backspace
                if(request.text.length()>0)request.text.setLength(request.text.length()-1);
                request.error="";
            }else if((keyCode==47&&controlHeld())||typed==22) { // Ctrl+V
                try{
                    Object data=Toolkit.getDefaultToolkit().getSystemClipboard().getData(DataFlavor.stringFlavor);
                    if(data instanceof String)appendEmail(request,(String)data);
                }catch(Exception ignored){}
            }else if(keyCode==30&&controlHeld()){ // Ctrl+A to replace typed address
                request.text.setLength(0);
                request.error="";
            }else if(typed>=32&&typed!=127&&!Character.isISOControl(typed)&&!controlHeld()) {
                appendEmail(request,String.valueOf(typed));
            }
            updateEmailState(request);
        }
    }
    private static void appendEmail(EmailRequest request,String text){
        for(int i=0;i<text.length()&&request.text.length()<254;i++){
            char c=text.charAt(i);
            if(!Character.isISOControl(c)&&!Character.isWhitespace(c))request.text.append(c);
        }
        request.error="";
    }
    private static boolean controlHeld(){
        try{
            Class<?> keyboard=Class.forName("org.lwjgl.input.Keyboard");
            Method isDown=keyboard.getMethod("isKeyDown",Integer.TYPE);
            return (Boolean)isDown.invoke(null,29)||(Boolean)isDown.invoke(null,157);
        }catch(Throwable ignored){return false;}
    }
    private static void updateEmailState(EmailRequest request){
        state=new State("Microsoft account email","","",
            request.error.isEmpty()?"Press Enter for a sign-in code; Backspace edits":request.error,
            request.text.toString(),0);
    }
    private static void openVerification(String url) {
        try {
            URI u=new URI(url);
            String host=u.getHost()==null?"":u.getHost().toLowerCase(Locale.ROOT);
            if(!"https".equalsIgnoreCase(u.getScheme())||!(host.equals("microsoft.com")||host.equals("www.microsoft.com")))
                throw new IllegalArgumentException("Not an official Microsoft verification URL");
            if(Boolean.getBoolean("alpha.modern.noBrowser"))return;
            if(Desktop.isDesktopSupported()&&Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)){
                Desktop.getDesktop().browse(u);return;
            }
            String os=System.getProperty("os.name","").toLowerCase(Locale.ROOT);
            if(os.contains("linux"))new ProcessBuilder("xdg-open",url).start();
            else if(os.contains("mac"))new ProcessBuilder("open",url).start();
            else if(os.contains("win"))new ProcessBuilder("rundll32","url.dll,FileProtocolHandler",url).start();
        }catch(Exception e){System.out.println(AlphaModernAgent.PREFIX+"Open the Microsoft login link manually if it did not launch: "+url);}
    }
    private static volatile boolean renderErrorReported;
    private static volatile Class<?> cachedClass;
    private static Field width,height,font;
    private static Method draw,rectangle;
    private static synchronized void init(Object screen) throws Exception {
        if(screen.getClass()==cachedClass)return;
        Class<?> bd=screen.getClass().getSuperclass();
        Class<?> la=bd.getSuperclass();
        width=bd.getDeclaredField("c");height=bd.getDeclaredField("d");font=bd.getDeclaredField("g");
        width.setAccessible(true);height.setAccessible(true);font.setAccessible(true);
        Class<?> js=font.getType();
        draw=la.getDeclaredMethod("a",js,String.class,Integer.TYPE,Integer.TYPE,Integer.TYPE);
        draw.setAccessible(true);
        try {
            rectangle=la.getDeclaredMethod("a",Integer.TYPE,Integer.TYPE,Integer.TYPE,Integer.TYPE,Integer.TYPE);
            rectangle.setAccessible(true);
        }catch(NoSuchMethodException ignored){rectangle=null;}
        cachedClass=screen.getClass();
    }
    /** Injected into mb.a(IIF)V; this method runs on Alpha's game/render thread. */
    public static void render(Object connectionScreen) {
        State s=state;
        if(s==null)return;
        try {
            if(cachedClass!=connectionScreen.getClass())init(connectionScreen);
            int w=width.getInt(connectionScreen),h=height.getInt(connectionScreen);
            int cx=w/2,cy=h/2;
            Object f=font.get(connectionScreen);
            if(f==null)return;
            int y=Math.max(14,cy-145);
            if(rectangle!=null){
                int left=Math.max(4,cx-Math.min(210,w/2-5));
                int right=Math.min(w-4,cx+Math.min(210,w/2-5));
                rectangle.invoke(connectionScreen,left,y-10,right,Math.min(h-6,y+96),0xd9000000);
            }
            line(connectionScreen,f,s.heading,cx,y,0xffd27f);
            if("Microsoft account email".equals(s.heading)) {
                line(connectionScreen,f,"Type the email you will sign in with:",cx,y+17,0xdddddd);
                String value=s.email.isEmpty()?"[ enter email address ]":shortEmail(s.email,Math.max(18,(w-28)/6));
                line(connectionScreen,f,value+(System.currentTimeMillis()/500%2==0?"_":""),cx,y+35,0xffffff);
                line(connectionScreen,f,s.detail,cx,y+55,s.detail.startsWith("Enter a valid")?0xff7777:0xaaaaaa);
                line(connectionScreen,f,"Microsoft issues the code; no password is entered here",cx,y+73,0xaaaaaa);
            } else if(!s.site.isEmpty()) {
                if(!s.email.isEmpty())line(connectionScreen,f,"Sign in as: "+shortEmail(s.email,45),cx,y+17,0xdddddd);
                line(connectionScreen,f,s.site.replace("https://", ""),cx,y+34,0xffffff);
                line(connectionScreen,f,"CODE: " + s.code,cx,y+51,0xffff55);
                line(connectionScreen,f,s.detail,cx,y+68,0xcccccc);
                if(s.until>0){long left=Math.max(0,(s.until-System.currentTimeMillis())/1000);line(connectionScreen,f,"Expires in "+(left/60)+":"+String.format(Locale.ROOT,"%02d",left%60),cx,y+85,0xaaaaaa);}
            }else {
                if(!s.email.isEmpty())line(connectionScreen,f,shortEmail(s.email,45),cx,y+20,0xdddddd);
                line(connectionScreen,f,s.detail,cx,y+40,0xcccccc);
            }
        }catch(Throwable e){
            if(!renderErrorReported){renderErrorReported=true;
                System.err.println(AlphaModernAgent.PREFIX+"Could not render Microsoft login UI in Alpha: "+e);}
        }
    }
    private static String shortEmail(String email,int max){
        if(email.length()<=max)return email;
        int end=Math.min(max/2,email.length());
        return email.substring(0,max-end-3)+"..."+email.substring(email.length()-end);
    }
    private static void line(Object screen,Object font,String s,int x,int y,int rgb) throws Exception {
        draw.invoke(screen,font,s,x,y,rgb);
    }
}
