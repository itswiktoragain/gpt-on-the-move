package alphamodern;

/**
 * Project a tall modern dimension into Alpha's strict 0..127 block range.
 * The offset is a multiple of 16 so section boundaries stay aligned.
 */
final class VerticalViewport {
    static final int LEGACY_HEIGHT = 128;
    static final int CENTER = 64;
    private VerticalViewport() {}

    static int chooseBase(double playerY, int minY, int height) {
        if (!Double.isFinite(playerY) || height < 128 || height > 1024 || (height & 15) != 0 || (minY & 15) != 0)
            throw new IllegalArgumentException("Unsupported dimension geometry: minY=" + minY + " height=" + height);
        int lower = minY;
        int upper = minY + height - LEGACY_HEIGHT;
        double clampedY = Math.max(-30000000.0, Math.min(30000000.0, playerY));
        int wanted = (int) (Math.floor((clampedY - CENTER) / 16.0) * 16.0);
        return Math.max(lower, Math.min(upper, wanted));
    }

    static boolean shouldRecenter(double playerY, int baseY, int minY, int height) {
        if (!Double.isFinite(playerY)) return false;
        final double alphaY = playerY - baseY;
        return (alphaY < 20.0 || alphaY > 108.0) && chooseBase(playerY, minY, height) != baseY;
    }
}
