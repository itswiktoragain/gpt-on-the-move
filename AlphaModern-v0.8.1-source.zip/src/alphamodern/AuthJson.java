package alphamodern;

import java.io.IOException;
import java.util.*;

/** Dependency-free JSON parser for OAuth and Minecraft Services responses. */
final class AuthJson {
    private final String input;
    private int offset;
    private AuthJson(String s) { input=s; }
    static Object parse(String s) throws IOException {
        AuthJson p=new AuthJson(s);
        Object parsed=p.value(0);
        p.ws();
        if(p.offset!=s.length())throw new IOException("Extra JSON content");
        return parsed;
    }
    @SuppressWarnings("unchecked")
    static Map<String,Object> object(Object value) throws IOException {
        if(!(value instanceof Map))throw new IOException("Expected JSON object");
        return (Map<String,Object>)value;
    }
    static String string(Map<String,Object> obj,String name) throws IOException {
        Object value=obj.get(name);
        if(!(value instanceof String))throw new IOException("Missing/invalid JSON field "+name);
        return (String)value;
    }
    static String optional(Map<String,Object> obj,String name,String fallback) {
        Object value=obj.get(name);
        return value instanceof String ? (String)value : fallback;
    }
    static long number(Map<String,Object> obj,String name,long fallback) {
        Object n=obj.get(name);
        return n instanceof Number ? ((Number)n).longValue() : fallback;
    }
    @SuppressWarnings("unchecked")
    static List<Object> array(Object value) throws IOException {
        if(!(value instanceof List))throw new IOException("Expected JSON array");
        return (List<Object>)value;
    }
    static String quote(String s) {
        StringBuilder b=new StringBuilder("\"");
        for(int i=0;i<s.length();i++){
            char c=s.charAt(i);
            if(c=='"'||c=='\\')b.append('\\').append(c);
            else if(c=='\n')b.append("\\n");
            else if(c=='\r')b.append("\\r");
            else if(c=='\t')b.append("\\t");
            else if(c<32){String hex=Integer.toHexString(c);b.append("\\u");for(int j=hex.length();j<4;j++)b.append('0');b.append(hex);}
            else b.append(c);
        }
        return b.append('"').toString();
    }
    private void ws() {while(offset<input.length()&&Character.isWhitespace(input.charAt(offset)))offset++;}
    private char next() throws IOException {if(offset>=input.length())throw new IOException("Truncated JSON");return input.charAt(offset++);}
    private Object value(int depth) throws IOException {
        if(depth>64)throw new IOException("JSON nesting limit exceeded");
        ws();char c=next();
        if(c=='"')return parseString();
        if(c=='{'){
            Map<String,Object> map=new LinkedHashMap<String,Object>();ws();
            if(offset<input.length()&&input.charAt(offset)=='}'){offset++;return map;}
            do {
                ws();if(next()!='"')throw new IOException("Invalid JSON object key");
                String key=parseString();ws();if(next()!=':')throw new IOException("Expected JSON colon");
                map.put(key,value(depth+1));ws();c=next();
                if(c=='}')return map;
                if(c!=',')throw new IOException("Expected JSON comma");
            }while(true);
        }
        if(c=='['){
            List<Object> values=new ArrayList<Object>();ws();
            if(offset<input.length()&&input.charAt(offset)==']'){offset++;return values;}
            do {values.add(value(depth+1));ws();c=next();if(c==']')return values;if(c!=',')throw new IOException("Expected JSON comma");}while(true);
        }
        if(c=='t'){literal("rue");return Boolean.TRUE;}
        if(c=='f'){literal("alse");return Boolean.FALSE;}
        if(c=='n'){literal("ull");return null;}
        if(c=='-'||(c>='0'&&c<='9')){
            int start=offset-1;
            while(offset<input.length()&&"0123456789.eE+-".indexOf(input.charAt(offset))>=0)offset++;
            try{return Double.valueOf(input.substring(start,offset));}catch(NumberFormatException e){throw new IOException("Invalid JSON number");}
        }
        throw new IOException("Invalid JSON value");
    }
    private void literal(String expected) throws IOException {for(int i=0;i<expected.length();i++)if(next()!=expected.charAt(i))throw new IOException("Invalid JSON literal");}
    private String parseString() throws IOException {
        StringBuilder b=new StringBuilder();
        while(true){
            char c=next();if(c=='"')return b.toString();
            if(c=='\\'){
                char e=next();switch(e){
                    case '"':case '\\':case '/':b.append(e);break;
                    case 'b':b.append('\b');break;
                    case 'f':b.append('\f');break;
                    case 'n':b.append('\n');break;
                    case 'r':b.append('\r');break;
                    case 't':b.append('\t');break;
                    case 'u':{
                        if(offset+4>input.length())throw new IOException("Truncated Unicode escape");
                        try{b.append((char)Integer.parseInt(input.substring(offset,offset+4),16));}catch(NumberFormatException ex){throw new IOException("Invalid Unicode escape");}
                        offset+=4;break;
                    }
                    default:throw new IOException("Invalid string escape");
                }
            }else {
                if(c<32)throw new IOException("Invalid JSON control character");
                b.append(c);
            }
        }
    }
}
