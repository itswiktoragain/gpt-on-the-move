package alphamodern;

import java.io.*;
import java.lang.instrument.ClassFileTransformer;
import java.nio.charset.StandardCharsets;
import java.security.ProtectionDomain;
import java.util.*;

/** Adds drawing and keyboard input hooks to Alpha 1.0.15's mb.class connection UI.
 *  Does not require external bytecode libraries; retains original Java 5 class version.
 */
final class InGamePatch implements ClassFileTransformer {
    public byte[] transform(ClassLoader loader,String className,Class<?> clazz,ProtectionDomain domain,byte[] data) {
        if(!"mb".equals(className))return null;
        try {
            byte[] patched=patch(data);
            System.out.println(AlphaModernAgent.PREFIX+"Injected in-game email entry and device-code overlay (mb)");
            return patched;
        }catch(Exception e){System.err.println(AlphaModernAgent.PREFIX+"Could not patch Alpha sign-in screen: "+e);return null;}
    }
    static byte[] patch(byte[] bytes) throws IOException {
        DataInputStream in=new DataInputStream(new ByteArrayInputStream(bytes));
        ByteArrayOutputStream bytesOut=new ByteArrayOutputStream(bytes.length+170);
        DataOutputStream out=new DataOutputStream(bytesOut);
        if(in.readInt()!=0xcafebabe)throw new IOException("Not a class file");
        out.writeInt(0xcafebabe);
        int minor=in.readUnsignedShort(),major=in.readUnsignedShort();
        if(major!=49)throw new IOException("Not Alpha 1.0.15's Java 5 bytecode");
        out.writeShort(minor);out.writeShort(major);
        int count=in.readUnsignedShort();
        if(count+10>=65535)throw new IOException("Constant pool full");
        out.writeShort(count+10);
        Map<Integer,String> names=new HashMap<Integer,String>();
        boolean knownVersion=false;
        for(int i=1;i<count;i++){
            int tag=in.readUnsignedByte();out.writeByte(tag);
            switch(tag){
                case 1:{
                    int len=in.readUnsignedShort();byte[] value=new byte[len];in.readFully(value);
                    out.writeShort(len);out.write(value);
                    String name=new String(value,StandardCharsets.UTF_8);names.put(i,name);
                    if(name.equals("Connecting to the server..."))knownVersion=true;
                    break;
                }
                case 3:case 4:case 9:case 10:case 11:case 12:case 17:case 18:copy(in,out,4);break;
                case 5:case 6:copy(in,out,8);i++;break;
                case 7:case 8:case 16:case 19:case 20:copy(in,out,2);break;
                case 15:copy(in,out,3);break;
                default:throw new IOException("Unsupported class constant "+tag);
            }
        }
        if(!knownVersion)throw new IOException("Original Alpha connection GUI signature absent");
        int classUtf=count, classRef=count+1, renderUtf=count+2, renderDesc=count+3;
        int renderNameType=count+4, renderRef=count+5;
        int keyUtf=count+6, keyDesc=count+7, keyNameType=count+8, keyRef=count+9;
        utf(out,"alphamodern/AuthOverlay");out.writeByte(7);out.writeShort(classUtf);
        utf(out,"render");utf(out,"(Ljava/lang/Object;)V");
        out.writeByte(12);out.writeShort(renderUtf);out.writeShort(renderDesc);
        out.writeByte(10);out.writeShort(classRef);out.writeShort(renderNameType);
        utf(out,"key");utf(out,"(CI)V");
        out.writeByte(12);out.writeShort(keyUtf);out.writeShort(keyDesc);
        out.writeByte(10);out.writeShort(classRef);out.writeShort(keyNameType);
        copy(in,out,6); // access flags, this class, super class
        int interfaces=in.readUnsignedShort();out.writeShort(interfaces);copy(in,out,interfaces*2);
        int fields=in.readUnsignedShort();out.writeShort(fields);
        for(int i=0;i<fields;i++)member(in,out,names,false,renderRef,keyRef);
        int methods=in.readUnsignedShort();out.writeShort(methods);
        int renderCount=0,keyCount=0;
        for(int i=0;i<methods;i++){
            int modified=member(in,out,names,true,renderRef,keyRef);
            if(modified==1)renderCount++;
            if(modified==2)keyCount++;
        }
        if(renderCount!=1||keyCount!=1)throw new IOException("Expected mb rendering and keyboard handlers, got "+renderCount+"/"+keyCount);
        int attributes=in.readUnsignedShort();out.writeShort(attributes);
        for(int i=0;i<attributes;i++)attribute(in,out,names,0,renderRef,keyRef);
        if(in.read()!=-1)throw new IOException("Unconsumed Alpha class bytes");
        out.flush();return bytesOut.toByteArray();
    }
    /** mode: 0=none, 1=render, 2=email key handler */
    private static int member(DataInputStream in,DataOutputStream out,Map<Integer,String> names,boolean method,int renderRef,int keyRef) throws IOException {
        out.writeShort(in.readUnsignedShort());
        int name=in.readUnsignedShort(),descriptor=in.readUnsignedShort();out.writeShort(name);out.writeShort(descriptor);
        int mode=0;
        if(method&&"a".equals(names.get(name))){
            if("(IIF)V".equals(names.get(descriptor)))mode=1;
            if("(CI)V".equals(names.get(descriptor)))mode=2;
        }
        int attributes=in.readUnsignedShort();out.writeShort(attributes);
        boolean changed=false;
        for(int i=0;i<attributes;i++)if(attribute(in,out,names,mode,renderRef,keyRef))changed=true;
        if(mode!=0&&!changed)throw new IOException("Missing Code attribute for mb method "+names.get(descriptor));
        return changed?mode:0;
    }
    private static boolean attribute(DataInputStream in,DataOutputStream out,Map<Integer,String> names,int mode,int renderRef,int keyRef) throws IOException {
        int index=in.readUnsignedShort(),size=in.readInt();
        if(size<0||size>10485760)throw new IOException("Invalid class attribute length");
        byte[] original=new byte[size];in.readFully(original);
        boolean changed=mode!=0&&"Code".equals(names.get(index));
        byte[] replaced=changed?addHook(original,mode==1?renderRef:keyRef,mode):original;
        out.writeShort(index);out.writeInt(replaced.length);out.write(replaced);
        return changed;
    }
    private static byte[] addHook(byte[] attr,int ref,int mode) throws IOException {
        DataInputStream in=new DataInputStream(new ByteArrayInputStream(attr));
        ByteArrayOutputStream bytes=new ByteArrayOutputStream(attr.length+8);DataOutputStream out=new DataOutputStream(bytes);
        int maxStack=in.readUnsignedShort(),locals=in.readUnsignedShort();
        out.writeShort(Math.max(maxStack,mode==2?2:1));out.writeShort(locals);
        int len=in.readInt();
        if(len<1||len>attr.length)throw new IOException("Invalid Alpha method length");
        byte[] code=new byte[len];in.readFully(code);
        if((code[len-1]&255)!=0xb1)throw new IOException("Alpha handler does not finish with RETURN");
        if(mode==1){
            if(len<5)throw new IOException("Invalid render method");
            out.writeInt(len+4);
            out.write(code,0,len-1);
            out.writeByte(0x2a); // aload_0: original GUI instance
            out.writeByte(0xb8); // invokestatic AuthOverlay.render(Object)
            out.writeShort(ref);
            out.writeByte(0xb1); // original return
        }else{
            // Alpha mb.a(char,int) originally contains one RETURN and no other instructions.
            if(len!=1)throw new IOException("Expected empty Alpha keyboard handler");
            out.writeInt(6);
            out.writeByte(0x1b); // iload_1 (char)
            out.writeByte(0x1c); // iload_2 (LWJGL key code)
            out.writeByte(0xb8);out.writeShort(ref); // invokestatic AuthOverlay.key(CI)V
            out.writeByte(0xb1); // return
        }
        // All original LineNumberTable, local variable and exception offsets still valid.
        out.write(AlphaModernAgent.readAll(in));out.flush();return bytes.toByteArray();
    }
    private static void utf(DataOutputStream out,String s) throws IOException {
        byte[] b=s.getBytes(StandardCharsets.UTF_8);out.writeByte(1);out.writeShort(b.length);out.write(b);
    }
    private static void copy(DataInputStream in,DataOutputStream out,int len) throws IOException {
        byte[] b=new byte[len];in.readFully(b);out.write(b);
    }
}
