package alphamodern;
import java.net.*;
import java.io.*;
/** In-place drop-in for new Socket(InetAddress,int), injected into Alpha's gn.class. */
public class BridgeSocket extends Socket {
    public BridgeSocket(InetAddress remote, int port) throws IOException {
        super(InetAddress.getLoopbackAddress(), Gateway.port());
        if (port < 1 || port > 65535) { close(); throw new IOException("Invalid target port"); }
        setTcpNoDelay(true);
        DataOutputStream d = new DataOutputStream(getOutputStream());
        d.writeUTF(remote.getHostName());
        d.writeInt(port);
        d.flush();
    }
}
