package alphamodern;
import java.io.*;
import java.net.*;
public final class StatusPing {
    public static String ping(String host, int port) throws IOException {
        Socket socket = new Socket();socket.connect(new InetSocketAddress(host,port), 6000);socket.setSoTimeout(6000);
        try {Wire wire=new Wire(socket);
            wire.send(0, w->{Wire.var(w,776);Wire.str(w,host);w.writeShort(port);Wire.var(w,1);});
            wire.send(0,w->{});
            Wire.Packet response=wire.recv();if(response.id!=0)throw new IOException("Unexpected status packet id "+response.id);
            return Wire.str(response.data);
        }finally{socket.close();}
    }
}
