package alphamodern;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.function.BooleanSupplier;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Optional, permission-respecting registration of a genuine Microsoft OAuth
 * public-client application using the user's own Azure CLI/Entra account.
 *
 * Important: a GUID made with UUID.randomUUID() IS NOT a registered client ID.
 * The only working identifier is the appId returned by Entra after successful
 * registration. Entra permissions and Minecraft/Xbox app approval are separate.
 */
final class AzureClientRegistrar {
    private static final String CLIENT_ID_REGEX = "(?i)[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}";
    private static final Pattern DEVICE_CODE = Pattern.compile(
            "(?i)(?:enter|use)\\s+(?:the\\s+)?code\\s+([A-Z0-9-]{6,16})(?:\\s|$)");
    private static final Pattern VERIFY_URL = Pattern.compile(
            "https://(?:www\\.)?microsoft\\.com/(?:devicelogin|link)", Pattern.CASE_INSENSITIVE);
    private static final long COMMAND_TIMEOUT = 45000L;
    private static final long LOGIN_TIMEOUT = 360000L;
    private static final long REGISTER_TIMEOUT = 90000L;

    private final String az;
    private AzureClientRegistrar(String exe) { this.az = exe; }
    static AzureClientRegistrar local() {
        // This override exists for unusual Azure CLI installations and local tests.
        String configured = System.getProperty("alpha.modern.azureCli", "").trim();
        return new AzureClientRegistrar(configured.isEmpty() ? "az" : configured);
    }

    static boolean looksLikeRegisteredId(String id) {
        return id != null && id.matches(CLIENT_ID_REGEX);
    }

    /** Creates and persists an application only if a genuine Entra registration succeeds. */
    String register(Path configDir, BooleanSupplier active) throws IOException {
        AuthOverlay.status("Microsoft application setup", "Checking Azure CLI for account registration");
        try {
            RunResult version = command(active, 12000L, "version", "--output", "none");
            if (version.exit != 0) throw new IOException("Azure CLI is not available");
        } catch (IOException e) {
            AuthOverlay.status("Microsoft app setup required", "Azure CLI not installed - see AlphaModern README");
            throw new IOException("Cannot create a Microsoft OAuth client ID on this device: Azure CLI (az) is not available. " +
                    "Install Azure CLI and sign into an Entra account permitted to register applications, " +
                    "or register an app manually and use 'configure <CLIENT_ID>'. " +
                    "A random locally generated ID would be rejected by Microsoft.", e);
        }

        RunResult account = command(active, COMMAND_TIMEOUT, "account", "show", "--only-show-errors", "--output", "none");
        if (account.exit != 0) {
            AuthOverlay.status("Microsoft application setup", "Sign into Azure to register the application");
            RunResult login = command(active, LOGIN_TIMEOUT,
                    "login", "--use-device-code", "--allow-no-subscriptions", "--output", "none");
            if (login.exit != 0) {
                AuthOverlay.status("Azure account login failed", "See the AlphaModern console for setup instructions");
                throw new IOException("Azure CLI could not sign in to an Entra account (exit " + login.exit +"). " +
                        "The account must have permission to register applications. " +
                        "Run 'az login --use-device-code --allow-no-subscriptions' to investigate.");
            }
        }

        AuthOverlay.status("Registering Microsoft app", "Creating a public-client identity in Microsoft Entra");
        // Only the Entra-issued appId is saved. There is never a generated/fake client ID.
        String displayName = "AlphaModern Alpha Login " + UUID.randomUUID().toString().substring(0, 8);
        RunResult created = command(active, REGISTER_TIMEOUT,
                "ad", "app", "create", "--display-name", displayName,
                "--sign-in-audience", "AzureADandPersonalMicrosoftAccount",
                "--is-fallback-public-client", "true",
                "--public-client-redirect-uris", "http://localhost",
                "--query", "appId", "--output", "tsv", "--only-show-errors");
        if (created.exit != 0) {
            AuthOverlay.status("App registration denied", "Account needs Entra app registration permissions");
            throw new IOException("Microsoft Entra did not register the OAuth application (Azure CLI exit " + created.exit + "). " +
                    "Check Entra app registration permissions and your tenant's supported account types. " +
                    "You can also register a public-client app manually and use 'configure <CLIENT_ID>'.");
        }
        String appId = null;
        for (String line : created.lines()) {
            String candidate = line.trim();
            if (looksLikeRegisteredId(candidate)) appId = candidate.toLowerCase(Locale.ROOT);
        }
        if (appId == null) {
            throw new IOException("Entra registration did not return a valid application/client ID. " +
                    "No client ID was saved; check the app registration in Microsoft Entra.");
        }
        AuthManager.saveClientId(configDir, appId);
        AuthOverlay.status("Microsoft app ID stored", "Requesting Minecraft sign-in code");
        System.out.println(AlphaModernAgent.PREFIX+"Registered public Microsoft application " + appId +
                " and saved its client ID to " + configDir.resolve("config.properties"));
        return appId;
    }

    private RunResult command(BooleanSupplier active, long timeoutMs, String... arguments) throws IOException {
        String[] argv = new String[arguments.length + 1];
        argv[0] = az;
        System.arraycopy(arguments, 0, argv, 1, arguments.length);
        ProcessBuilder pb = new ProcessBuilder(argv);
        pb.redirectErrorStream(true);
        // Avoid Azure CLI's newer interactive subscription picker after device-code auth.
        pb.environment().put("AZURE_CORE_LOGIN_EXPERIENCE_V2", "off");
        pb.environment().put("AZURE_CORE_NO_COLOR", "1");
        final Process process = pb.start();
        final StringBuilder captured = new StringBuilder();
        final boolean isLogin = arguments.length>0 && "login".equals(arguments[0]);
        Thread output = new Thread(new Runnable() {
            @Override public void run() {
                try (BufferedReader in = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = in.readLine()) != null) {
                        synchronized(captured) {
                            if (captured.length() < 32768) captured.append(line, 0, Math.min(line.length(), 1024)).append('\n');
                        }
                        if (isLogin) {
                            Matcher code = DEVICE_CODE.matcher(line);
                            Matcher url = VERIFY_URL.matcher(line);
                            if (code.find()) {
                                String verification = url.find()?url.group():"https://microsoft.com/devicelogin";
                                AuthOverlay.code(verification, code.group(1), System.currentTimeMillis()+300000L);
                            }
                        }
                    }
                } catch(IOException ignored) { /* A cancelled process may close its pipe. */ }
            }
        }, "AlphaModern-AzureCLI-Output");
        output.setDaemon(true);
        output.start();
        long deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(timeoutMs);
        try {
            while (true) {
                if (!active.getAsBoolean()) throw new IOException("Microsoft application setup cancelled");
                if (process.waitFor(200, TimeUnit.MILLISECONDS)) break;
                if (System.nanoTime() > deadline) throw new IOException("Azure CLI timed out during Microsoft application setup");
            }
            output.join(1000L);
            String text;
            synchronized(captured) { text = captured.toString(); }
            return new RunResult(process.exitValue(), text);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Microsoft application setup interrupted", e);
        } finally {
            if (process.isAlive()) {
                process.destroy();
                try { if (!process.waitFor(1000, TimeUnit.MILLISECONDS)) process.destroyForcibly(); }
                catch (InterruptedException e) { process.destroyForcibly(); Thread.currentThread().interrupt(); }
            }
        }
    }

    private static final class RunResult {
        final int exit;
        final String output;
        RunResult(int exit, String output) { this.exit=exit;this.output=output; }
        List<String> lines() {return Arrays.asList(output.split("\\r?\\n"));}
    }
}
