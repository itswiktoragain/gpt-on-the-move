package alphamodern;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Safely decode the nameless network NBT text-component tree used by 26.2. */
final class TextComponent {
    private static final int MAX_TAG_BYTES=262144, MAX_LIST=16384, MAX_DEPTH=36, MAX_RENDERED=12000;
    private static final String[] COLOR_NAMES={"black","dark_blue","dark_green","dark_aqua","dark_red","dark_purple","gold","gray","dark_gray","blue","green","aqua","red","light_purple","yellow","white"};
    private static final int[] COLOR_RGB={0x000000,0x0000AA,0x00AA00,0x00AAAA,0xAA0000,0xAA00AA,0xFFAA00,0xAAAAAA,0x555555,0x5555FF,0x55FF55,0x55FFFF,0xFF5555,0xFF55FF,0xFFFF55,0xFFFFFF};
    private static final String CODES="0123456789abcdef";
    private TextComponent() {}

    /** Reads exactly one network-NBT root tag; leaves any packet fields untouched. */
    static String readFormatted(DataInputStream in) throws IOException {
        int tag=in.readUnsignedByte();
        if(tag==0)return "";
        Object value=readPayload(in,tag,0);
        StringBuilder out=new StringBuilder();
        render(value,out,'f',0);
        return sanitize(out.toString());
    }

    static String sanitize(String message) {
        StringBuilder clean=new StringBuilder(Math.min(message.length(),MAX_RENDERED));
        for(int i=0;i<message.length()&&clean.length()<MAX_RENDERED;i++) {
            char c=message.charAt(i);
            if(c=='\r')continue;
            if(c=='\n'||c=='\t'||c>=32)clean.append(c);
        }
        return clean.toString();
    }

    private static String utf(DataInputStream in) throws IOException {
        int count=in.readUnsignedShort();
        if(count>MAX_TAG_BYTES)throw new IOException("Oversized NBT string");
        byte[] bytes=new byte[count];in.readFully(bytes);
        return new String(bytes,StandardCharsets.UTF_8);
    }
    private static void skip(DataInputStream in,int count) throws IOException {
        if(count<0||count>MAX_TAG_BYTES)throw new IOException("Oversized NBT field");
        byte[] scratch=new byte[Math.min(count,4096)];
        while(count>0){int part=Math.min(count,scratch.length);in.readFully(scratch,0,part);count-=part;}
    }
    private static Object readPayload(DataInputStream in,int tag,int depth) throws IOException {
        if(depth>MAX_DEPTH)throw new IOException("Excessive component nesting");
        switch(tag) {
            case 0: return "";
            case 1: return in.readByte();
            case 2: return in.readShort();
            case 3: return in.readInt();
            case 4: return in.readLong();
            case 5: return in.readFloat();
            case 6: return in.readDouble();
            case 7: {int len=in.readInt();skip(in,len);return "";}
            case 8: return utf(in);
            case 9: {
                int element=in.readUnsignedByte(), len=in.readInt();
                if(len<0||len>MAX_LIST || element==0&&len!=0)throw new IOException("Invalid NBT list");
                List<Object> arr=new ArrayList<Object>(Math.min(len,64));
                for(int i=0;i<len;i++)arr.add(readPayload(in,element,depth+1));
                return arr;
            }
            case 10: {
                Map<String,Object> map=new LinkedHashMap<String,Object>();
                for(int i=0;i<MAX_LIST;i++) {
                    int t=in.readUnsignedByte();if(t==0)return map;
                    String key=utf(in);
                    Object value=readPayload(in,t,depth+1);
                    if(map.size()<512)map.put(key,value);
                }
                throw new IOException("Unterminated/oversized NBT compound");
            }
            case 11: {int len=in.readInt();if(len<0||len>MAX_TAG_BYTES/4)throw new IOException("Oversized NBT int array");skip(in,len*4);return "";}
            case 12: {int len=in.readInt();if(len<0||len>MAX_TAG_BYTES/8)throw new IOException("Oversized NBT long array");skip(in,len*8);return "";}
            default: throw new IOException("Invalid NBT tag " + tag);
        }
    }
    private static String string(Object value) {return value instanceof String?(String)value:"";}
    private static char color(String name,char inherited) {
        if(name.isEmpty())return inherited;
        for(int i=0;i<COLOR_NAMES.length;i++)if(name.equals(COLOR_NAMES[i]))return CODES.charAt(i);
        if(name.matches("#[0-9a-fA-F]{6}")) {
            int rgb=Integer.parseInt(name.substring(1),16),r=(rgb>>16)&255,g=(rgb>>8)&255,b=rgb&255;
            int best=15,bestDistance=Integer.MAX_VALUE;
            for(int i=0;i<COLOR_RGB.length;i++) {
                int rr=(COLOR_RGB[i]>>16)&255,gg=(COLOR_RGB[i]>>8)&255,bb=COLOR_RGB[i]&255;
                int dr=r-rr,dg=g-gg,db=b-bb,dist=dr*dr+dg*dg+db*db;
                if(dist<bestDistance){best=i;bestDistance=dist;}
            }
            return CODES.charAt(best);
        }
        return inherited;
    }
    private static void appendText(StringBuilder out,String text,char inheritedColor) {
        if(text.isEmpty() || out.length()>MAX_RENDERED) return;
        out.append('\u00a7').append(inheritedColor).append(text);
    }
    @SuppressWarnings("unchecked")
    private static void render(Object data,StringBuilder out,char inheritedColor,int depth) {
        if(depth>MAX_DEPTH||out.length()>MAX_RENDERED||data==null)return;
        if(data instanceof String){appendText(out,(String)data,inheritedColor);return;}
        if(data instanceof List) {
            for(Object child:(List<Object>)data)render(child,out,inheritedColor,depth+1);
            return;
        }
        if(!(data instanceof Map))return;
        Map<String,Object> obj=(Map<String,Object>)data;
        char current=color(string(obj.get("color")),inheritedColor);
        String content=string(obj.get("text"));
        if(obj.get("text") instanceof Number) content=String.valueOf(obj.get("text"));
        if(obj.containsKey("translate")) content=translate(obj,current,depth+1);
        else if(obj.containsKey("keybind"))content=string(obj.get("keybind"));
        else if(obj.containsKey("selector"))content=string(obj.get("selector"));
        else if(obj.containsKey("score") && obj.get("score") instanceof Map) {
            Object value=((Map<?,?>)obj.get("score")).get("value");if(value!=null)content=String.valueOf(value);
        }
        appendText(out,content,current);
        Object children=obj.get("extra");
        if(children!=null)render(children,out,current,depth+1);
    }
    @SuppressWarnings("unchecked")
    private static String translate(Map<String,Object> obj,char current,int depth) {
        String key=string(obj.get("translate")),fmt=string(obj.get("fallback"));
        if(fmt.isEmpty())fmt=lookup(key);
        Object raw=obj.get("with");
        List<Object> args=raw instanceof List?(List<Object>)raw:Collections.emptyList();
        List<String> rendered=new ArrayList<String>();
        for(Object arg:args) {
            StringBuilder b=new StringBuilder();render(arg,b,current,depth+1);rendered.add(b.toString());
        }
        StringBuilder out=new StringBuilder();
        int next=0;
        for(int i=0;i<fmt.length();) {
            char c=fmt.charAt(i);
            if(c!='%'||i+1>=fmt.length()){out.append(c);i++;continue;}
            if(fmt.charAt(i+1)=='%'){out.append('%');i+=2;continue;}
            int end=i+1,explicit=-1;
            while(end<fmt.length()&&Character.isDigit(fmt.charAt(end)))end++;
            if(end>i+1&&end+1<fmt.length()&&fmt.charAt(end)=='$'&&fmt.charAt(end+1)=='s') {
                try{explicit=Integer.parseInt(fmt.substring(i+1,end))-1;}catch(NumberFormatException ignored){}
                i=end+2;
            } else if(fmt.charAt(i+1)=='s') {i+=2;}
            else{out.append('%');i++;continue;}
            int index=explicit>=0?explicit:next++;
            if(index>=0&&index<rendered.size())out.append(rendered.get(index));
        }
        return out.toString();
    }
    private static String lookup(String key) {
        switch(key) {
            case "chat.type.text":return "<%s> %s";
            case "chat.type.announcement":return "[%s] %s";
            case "chat.type.emote":return "* %s %s";
            case "chat.type.team.text":return "[%s] <%s> %s";
            case "multiplayer.player.joined":return "%s joined the game";
            case "multiplayer.player.left":return "%s left the game";
            case "commands.message.display.incoming":return "%s whispers to you: %s";
            case "commands.message.display.outgoing":return "You whisper to %s: %s";
            case "death.attack.generic":return "%s died";
            default:return key; // unknown translation keys are honest fallbacks
        }
    }
}
