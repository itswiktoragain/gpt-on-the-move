package alphamodern;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.zip.*;
import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.SecretKey;

final class Wire {
    interface Writer { void write(DataOutputStream out) throws IOException; }
    static final int MAX_PACKET = 8*1024*1024;
    private InputStream in;
    private OutputStream out;
    private final Socket socket;
    private volatile int compression = -1;
    Wire(Socket s) throws IOException {socket=s;in=new BufferedInputStream(s.getInputStream());out=new BufferedOutputStream(s.getOutputStream());}
    static void var(DataOutputStream o,int x) throws IOException {
        while((x&~0x7f)!=0){o.writeByte((x&0x7f)|0x80);x >>>= 7;}o.writeByte(x);
    }
    static int var(InputStream in) throws IOException {
        int value=0;for(int j=0;j<5;j++){int b=in.read();if(b<0)throw new EOFException();value|=(b&127)<<(j*7);if((b&128)==0)return value;}
        throw new IOException("VarInt too big");
    }
    static long varLong(InputStream in) throws IOException {
        long value=0;
        for(int i=0;i<10;i++) {
            int b=in.read();if(b<0)throw new EOFException();
            value|=(long)(b&127)<<(i*7);
            if((b&128)==0)return value;
        }
        throw new IOException("VarLong too big");
    }
    static void writeVarLong(DataOutputStream out,long x) throws IOException {
        while((x & ~0x7fL)!=0){out.writeByte((int)(x&0x7f)|0x80);x>>>=7;}
        out.writeByte((int)x);
    }
    static void str(DataOutputStream o,String s) throws IOException {byte[] b=s.getBytes(StandardCharsets.UTF_8);if(b.length>32767)throw new IOException("String too long");var(o,b.length);o.write(b);}
    static String str(DataInputStream in) throws IOException {int n=var(in);if(n<0||n>1048576)throw new IOException("Bad string size "+n);byte[] b=new byte[n];in.readFully(b);return new String(b,StandardCharsets.UTF_8);}
    static byte[] bytes(DataInputStream in,int max) throws IOException {int n=var(in);if(n<0||n>max)throw new IOException("Byte array size out of bounds");byte[] a=new byte[n];in.readFully(a);return a;}
    static void bytes(DataOutputStream out,byte[] data) throws IOException {var(out,data.length);out.write(data);}
    static void uuid(DataOutputStream o,java.util.UUID id) throws IOException {o.writeLong(id.getMostSignificantBits());o.writeLong(id.getLeastSignificantBits());}
    static long pos(int x,int y,int z){return (((long)x&0x3ffffff)<<38)|(((long)z&0x3ffffff)<<12)|((long)y&0xfff);}
    static int unpackX(long p){return (int)(p>>38);}
    static int unpackY(long p){return (int)(p<<52>>52);}
    static int unpackZ(long p){return (int)(p<<26>>38);}
    synchronized void send(int id,Writer writer) throws IOException {
        ByteArrayOutputStream data=new ByteArrayOutputStream(160);
        DataOutputStream dout=new DataOutputStream(data);
        var(dout,id);writer.write(dout);dout.flush();sendRaw(data.toByteArray());
    }
    synchronized void sendRaw(byte[] bytes) throws IOException {
        if(bytes.length>MAX_PACKET)throw new IOException("Outgoing packet too large");
        DataOutputStream dout=new DataOutputStream(out);
        if(compression>=0) {
            ByteArrayOutputStream payload=new ByteArrayOutputStream();
            DataOutputStream p=new DataOutputStream(payload);
            if(bytes.length>=compression) {
                var(p,bytes.length);
                Deflater z=new Deflater(Deflater.DEFAULT_COMPRESSION);
                z.setInput(bytes);z.finish();byte[] b=new byte[8192];while(!z.finished()){int n=z.deflate(b);if(n==0)break;p.write(b,0,n);}z.end();
            } else {var(p,0);p.write(bytes);}
            p.flush();byte[] frame=payload.toByteArray();var(dout,frame.length);dout.write(frame);
        }else{var(dout,bytes.length);dout.write(bytes);}
        dout.flush();
    }
    Packet recv() throws IOException {
        int size=var(in);if(size<1||size>MAX_PACKET)throw new IOException("Packet size invalid "+size);
        byte[] frame=new byte[size];new DataInputStream(in).readFully(frame);
        if(compression>=0) {
            ByteArrayInputStream source=new ByteArrayInputStream(frame);
            int uncompressedSize=var(source);
            if(uncompressedSize<0||uncompressedSize>MAX_PACKET)throw new IOException("Inflated packet size too large");
            if(uncompressedSize==0)frame=AlphaModernAgent.readAll(source);
            else {
                if(uncompressedSize<compression)throw new IOException("Below compression threshold");
                Inflater z=new Inflater();z.setInput(AlphaModernAgent.readAll(source));byte[] dst=new byte[uncompressedSize];
                try{int actual=0;while(actual<dst.length){int n=z.inflate(dst,actual,dst.length-actual);if(n==0)break;actual+=n;}
                    if(actual!=dst.length||!z.finished())throw new IOException("Invalid zlib content");
                }catch(DataFormatException e){throw new IOException("Bad compressed packet",e);}finally{z.end();}
                frame=dst;
            }
        }
        ByteArrayInputStream buf=new ByteArrayInputStream(frame);int id=var(buf);
        return new Packet(id,new DataInputStream(buf));
    }
    void compression(int threshold){compression=threshold;}
    synchronized void encrypt(SecretKey key) throws Exception {
        Cipher encrypt=Cipher.getInstance("AES/CFB8/NoPadding");Cipher decrypt=Cipher.getInstance("AES/CFB8/NoPadding");
        IvParameterSpec iv=new IvParameterSpec(key.getEncoded());
        encrypt.init(Cipher.ENCRYPT_MODE,key,iv);decrypt.init(Cipher.DECRYPT_MODE,key,iv);
        out.flush();in=new CipherInputStream(in,decrypt);out=new CipherOutputStream(out,encrypt);
    }
    static final class Packet {
        final int id; final DataInputStream data;
        Packet(int id, DataInputStream data){this.id=id;this.data=data;}
    }
}
