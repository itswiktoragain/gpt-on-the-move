package alphamodern;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermission;
import java.util.*;
import java.util.function.BooleanSupplier;

/** Microsoft device-code login -> Xbox Live -> XSTS -> Minecraft Java profile. */
final class AuthManager {
    private static volatile AuthManager singleton;
    // Public Xbox/Minecraft device-code application identifier described by
    // azalea-auth / mcauth-go.  This is NOT generated, owned, or registered by
    // AlphaModern, and Microsoft can disable this interoperability at any time.
    static final String SWITCH_CLIENT_ID="00000000441cc96b";
    private static final String LIVE_SCOPE="service::user.auth.xboxlive.com::MBI_SSL";
    private static final String ENTRA_SCOPE="XboxLive.signin offline_access";
    private static final long EXPIRY_SKEW=120000L;
    private final Endpoints endpoints;
    private final Path directory, credentialFile;
    private final String suppliedClientId;

    static final class Endpoints {
        final String device,token,xbox,xsts,minecraft,profile,join;
        Endpoints(String d,String t,String x,String xs,String mc,String p,String j) {
            device=d;token=t;xbox=x;xsts=xs;minecraft=mc;profile=p;join=j;
        }
        static Endpoints entra() {
            return new Endpoints(
                "https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode",
                "https://login.microsoftonline.com/consumers/oauth2/v2.0/token",
                "https://user.auth.xboxlive.com/user/authenticate",
                "https://xsts.auth.xboxlive.com/xsts/authorize",
                "https://api.minecraftservices.com/authentication/login_with_xbox",
                "https://api.minecraftservices.com/minecraft/profile",
                "https://sessionserver.mojang.com/session/minecraft/join");
        }
        static Endpoints live() {
            return new Endpoints(
                "https://login.live.com/oauth20_connect.srf",
                "https://login.live.com/oauth20_token.srf",
                "https://user.auth.xboxlive.com/user/authenticate",
                "https://xsts.auth.xboxlive.com/xsts/authorize",
                "https://api.minecraftservices.com/authentication/login_with_xbox",
                "https://api.minecraftservices.com/minecraft/profile",
                "https://sessionserver.mojang.com/session/minecraft/join");
        }
    }
    static final class Profile {
        final String name, uuid, minecraftToken, refreshToken, clientId;
        final long minecraftExpires;
        Profile(String n,String id,String mc,String refresh,String app,long exp) {
            name=n;uuid=id;minecraftToken=mc;refreshToken=refresh;clientId=app;minecraftExpires=exp;
        }
        UUID id() { return UUID.fromString(uuid); }
        boolean valid() {return !minecraftToken.isEmpty()&&minecraftExpires-System.currentTimeMillis()>EXPIRY_SKEW;}
    }
    static final class Response {
        final int status;
        final Map<String,Object> data;
        Response(int status,Map<String,Object> json){this.status=status;this.data=json;}
        boolean ok(){return status>=200&&status<300;}
    }
    private static final class OAuthToken {
        final String access,refresh;
        OAuthToken(String a,String r){access=a;refresh=r;}
    }
    static AuthManager shared() {
        AuthManager local=singleton;
        if(local==null) {
            synchronized(AuthManager.class) {
                local=singleton;
                if(local==null)singleton=local=new AuthManager(defaultPath(),null,null);
            }
        }
        return local;
    }
    /** Package-private injection point used by loopback-only tests. */
    static void setForTests(AuthManager manager) {singleton=manager;}
    static Path defaultPath() {
        String override=System.getProperty("alpha.modern.home","").trim();
        if(!override.isEmpty())return Paths.get(override);
        String user=System.getProperty("user.home", ".");
        String os=System.getProperty("os.name","").toLowerCase(Locale.ROOT);
        if(os.contains("win")) {
            String appdata=System.getenv("APPDATA");
            if(appdata!=null&&!appdata.isEmpty())return Paths.get(appdata,".minecraft","alphamodern");
        }
        if(os.contains("mac"))return Paths.get(user,"Library","Application Support","minecraft","alphamodern");
        return Paths.get(user,".minecraft","alphamodern");
    }
    AuthManager(Path dir,String clientId,Endpoints urls) {
        directory=dir;credentialFile=dir.resolve("credentials.properties");
        // Read dynamically: first-run Entra registration can save an ID during login.
        suppliedClientId=clientId==null?"":clientId.trim();
        endpoints=urls;
    }
    static String configuredClientId(Path dir) { return readConfigClientId(dir); }
    private static String readConfigClientId(Path dir) {
        String setting=System.getProperty("alpha.modern.clientId","").trim();
        if(!setting.isEmpty())return setting;
        String fromEnv=System.getenv("ALPHAMODERN_CLIENT_ID");
        if(fromEnv!=null&&!fromEnv.trim().isEmpty())return fromEnv.trim();
        Path config=dir.resolve("config.properties");
        if(Files.exists(config))try(InputStream in=Files.newInputStream(config)) {
            Properties props=new Properties();props.load(in);return props.getProperty("clientId","").trim();
        }catch(IOException e){System.err.println(AlphaModernAgent.PREFIX+"Cannot load authentication configuration: "+e.getMessage());}
        return "";
    }
    private static String checkedId(String id) throws IOException {
        if(!isLiveClient(id)&&!AzureClientRegistrar.looksLikeRegisteredId(id))throw new IOException(
            "Invalid Microsoft OAuth application ID. Supply an approved Entra GUID " +
            "or the documented Xbox device-code client ID (see README).");
        return id;
    }
    private static boolean isLiveClient(String app) {
        return SWITCH_CLIENT_ID.equalsIgnoreCase(app);
    }
    private Endpoints urlsFor(String app) {
        // Explicit fake URLs are injected by loopback tests; real requests use
        // the endpoint family matching the application's authentication flow.
        return endpoints!=null?endpoints:(isLiveClient(app)?Endpoints.live():Endpoints.entra());
    }
    private static String scopeFor(String app) {return isLiveClient(app)?LIVE_SCOPE:ENTRA_SCOPE;}
    synchronized Profile peek() {
        if(!Files.isRegularFile(credentialFile))return null;
        try(InputStream input=Files.newInputStream(credentialFile)) {
            Properties p=new Properties();p.load(input);
            String name=p.getProperty("name","");
            String id=p.getProperty("uuid","");
            if(!name.matches("[a-zA-Z0-9_]{3,16}"))return null;
            UUID uuid=UUID.fromString(id);
            String app=p.getProperty("clientId","");
            String configured=!suppliedClientId.isEmpty()?suppliedClientId:readConfigClientId(directory);
            if(!configured.isEmpty()&&!app.equalsIgnoreCase(configured))return null;
            long expiry=Long.parseLong(p.getProperty("minecraftExpires","0"));
            return new Profile(name,uuid.toString(),p.getProperty("minecraftToken",""),p.getProperty("refreshToken",""),app,expiry);
        }catch(Exception e){System.err.println(AlphaModernAgent.PREFIX+"Saved login cannot be read; reauthentication will be required.");return null;}
    }
    synchronized Profile ensure(BooleanSupplier connected) throws Exception {
        checkRunning(connected);
        Profile existing=peek();
        if(existing!=null&&existing.valid())return existing;
        String app=!suppliedClientId.isEmpty()?suppliedClientId:readConfigClientId(directory);
        if(app.isEmpty()&&existing!=null)app=existing.clientId;
        if(app.isEmpty()) {
            // Use the existing public Xbox device-code application, not an
            // impossible locally-generated client ID or an Azure CLI install.
            app=SWITCH_CLIENT_ID;
            saveClientId(directory,app);
            AuthOverlay.status("Microsoft login", "Using Xbox-style link code (no Azure CLI)");
        }
        app=checkedId(app);
        if(existing!=null&&!existing.refreshToken.isEmpty()) {
            AuthOverlay.status("Refreshing Microsoft login","Using the saved account credentials");
            try {
                OAuthToken refresh=refresh(app,existing.refreshToken);
                Profile p=complete(app,refresh,connected);
                save(p);AuthOverlay.status("Signed in as "+p.name,"Joining the multiplayer server");
                return p;
            }catch(IOException e){
                System.err.println(AlphaModernAgent.PREFIX+"Saved session could not be refreshed: "+e.getMessage());
                checkRunning(connected);
                AuthOverlay.status("Microsoft login required","Getting a new sign-in code");
            }
        }
        String email=AuthOverlay.requestEmail(connected);
        checkRunning(connected);
        Profile p=signIn(app,connected,email);
        save(p);AuthOverlay.status("Signed in as "+p.name,"Joining the multiplayer server");
        return p;
    }
    private Profile signIn(String app, BooleanSupplier connected,String email) throws Exception {
        Endpoints urls=urlsFor(app);
        Map<String,String> request=map("client_id",app,"scope",scopeFor(app));
        // The established Xbox device-code endpoint requires this flag;
        // Microsoft's Entra v2 devicecode endpoint does not.
        if(isLiveClient(app))request.put("response_type","device_code");
        Response begin=form(urls.device,request);
        if(!begin.ok()&&isLiveClient(app))throw new IOException(
            "Microsoft did not accept the public Xbox link-code request ("+
            authError(begin,"device login").getMessage()+"). " +
            "This public client may be restricted; configure an approved Microsoft OAuth app as an alternative.");
        requireSuccess(begin,"Requesting Microsoft device code");
        Map<String,Object> d=begin.data;
        String device=AuthJson.string(d,"device_code");
        String code=AuthJson.string(d,"user_code");
        String url=AuthJson.string(d,"verification_uri");
        int interval=(int)Math.min(30,Math.max(1,AuthJson.number(d,"interval",5)));
        long expires=Math.min(1800,Math.max(1,AuthJson.number(d,"expires_in",900)));
        long until=System.currentTimeMillis()+expires*1000;
        // The email is only a local UI hint. The Microsoft device-code request itself
        // accepts a registered client_id and scope, not the account email.
        // Reject unexpected auth URLs, to prevent a bad proxy from phishing players.
        URI uri=URI.create(url);
        String hostname=uri.getHost()==null?"":uri.getHost().toLowerCase(Locale.ROOT);
        if(!"https".equalsIgnoreCase(uri.getScheme())||!(hostname.equals("microsoft.com")||hostname.equals("www.microsoft.com")))
            throw new IOException("Microsoft provided an unexpected device verification URL");
        AuthOverlay.code(url,code,until,email);
        while(System.currentTimeMillis()<until){
            pause(interval*1000L,connected);
            Response result=form(urls.token,map(
                "client_id",app,
                "grant_type","urn:ietf:params:oauth:grant-type:device_code",
                "device_code",device));
            if(result.ok()){
                OAuthToken tokens=tokens(result,null);
                AuthOverlay.status("Microsoft account linked","Getting Minecraft Java account profile");
                return complete(app,tokens,connected);
            }
            String err=AuthJson.optional(result.data,"error","unknown_error");
            if("authorization_pending".equals(err))continue;
            if("slow_down".equals(err)){interval=Math.min(60,interval+5);continue;}
            if("expired_token".equals(err))throw new IOException("The Microsoft login code expired. Connect again for a new code.");
            if("access_denied".equals(err)||"authorization_declined".equals(err))
                throw new IOException("Microsoft account linking was declined.");
            throw authError(result,"Microsoft device-code authorization");
        }
        throw new IOException("Microsoft login code expired; reconnect to request another.");
    }
    private OAuthToken refresh(String app,String refreshToken) throws IOException {
        Response response=form(urlsFor(app).token,map("client_id",app,
            "grant_type","refresh_token", "refresh_token",refreshToken, "scope",scopeFor(app)));
        requireSuccess(response,"Refreshing Microsoft login");
        return tokens(response,refreshToken);
    }
    private static OAuthToken tokens(Response r,String previous) throws IOException {
        String access=AuthJson.string(r.data,"access_token");
        String refresh=AuthJson.optional(r.data,"refresh_token",previous==null?"":previous);
        if(access.isEmpty()||refresh.isEmpty())throw new IOException("Microsoft didn't return a usable access/refresh token");
        return new OAuthToken(access,refresh);
    }
    private Profile complete(String app,OAuthToken tokens,BooleanSupplier connected) throws IOException {
        checkRunning(connected);
        Endpoints urls=urlsFor(app);
        // Legacy Xbox first-party access tokens use the raw ticket; tokens
        // from a custom Entra application use the 'd=' prefix.
        String ticket=(isLiveClient(app)?"":"d=")+tokens.access;
        String payload="{\"Properties\":{\"AuthMethod\":\"RPS\",\"SiteName\":\"user.auth.xboxlive.com\",\"RpsTicket\":"+
            AuthJson.quote(ticket)+"},\"RelyingParty\":\"http://auth.xboxlive.com\",\"TokenType\":\"JWT\"}";
        Response live=json(urls.xbox,payload,null);requireSuccess(live,"Xbox Live authentication");
        String xbox=AuthJson.string(live.data,"Token");
        checkRunning(connected);
        Response xsts=json(urls.xsts,"{\"Properties\":{\"SandboxId\":\"RETAIL\",\"UserTokens\":["+
            AuthJson.quote(xbox)+"]},\"RelyingParty\":\"rp://api.minecraftservices.com/\",\"TokenType\":\"JWT\"}",null);
        if(!xsts.ok()){
            String xerr=String.valueOf(AuthJson.number(xsts.data,"XErr",0));
            throw new IOException("Xbox Live/XSTS refused the login (HTTP "+xsts.status+", XErr "+xerr+"). Check Xbox account and multiplayer permissions.");
        }
        String xstsToken=AuthJson.string(xsts.data,"Token");
        Map<String,Object> display=AuthJson.object(xsts.data.get("DisplayClaims"));
        List<Object> users=AuthJson.array(display.get("xui"));
        if(users.isEmpty())throw new IOException("Xbox Live returned no user hash");
        String uhs=AuthJson.string(AuthJson.object(users.get(0)),"uhs");
        checkRunning(connected);
        Response javaLogin=json(urls.minecraft,"{\"identityToken\":"+
            AuthJson.quote("XBL3.0 x="+uhs+";"+xstsToken)+"}",null);
        requireSuccess(javaLogin,"Minecraft Java authentication");
        String minecraft=AuthJson.string(javaLogin.data,"access_token");
        long expires=AuthJson.number(javaLogin.data,"expires_in",86400);
        if(expires<120)throw new IOException("Minecraft returned an unusably short session token");
        long until=System.currentTimeMillis()+Math.min(expires,604800L)*1000L;
        checkRunning(connected);
        Response profile=get(urls.profile,minecraft);
        if(profile.status==404)throw new IOException("This Microsoft account has no Minecraft Java profile. A Java Edition license is required.");
        requireSuccess(profile,"Minecraft Java profile");
        String name=AuthJson.string(profile.data,"name");
        String id=AuthJson.string(profile.data,"id");
        if(!name.matches("[a-zA-Z0-9_]{3,16}")||!id.matches("[a-fA-F0-9]{32}"))
            throw new IOException("Minecraft returned a malformed Java profile");
        UUID uuid=UUID.fromString(id.substring(0,8)+"-"+id.substring(8,12)+"-"+id.substring(12,16)+"-"+id.substring(16,20)+"-"+id.substring(20));
        return new Profile(name,uuid.toString(),minecraft,tokens.refresh,app,until);
    }
    void join(Profile profile,String digest) throws IOException {
        if(profile==null||!profile.valid())throw new IOException("No currently valid Minecraft Java session");
        String json="{\"accessToken\":"+AuthJson.quote(profile.minecraftToken)+",\"selectedProfile\":"+
            AuthJson.quote(profile.uuid.replace("-",""))+",\"serverId\":"+AuthJson.quote(digest)+"}";
        Response joined=call(urlsFor(profile.clientId).join,"POST","application/json",json,null);
        if(joined.status!=204)throw new IOException("Minecraft session server denied online-mode login (HTTP "+joined.status+")");
    }
    static Path configureClient(String id) throws IOException {
        Path config=saveClientId(defaultPath(),id);
        singleton=null;
        return config;
    }
    static Path saveClientId(Path dir,String id) throws IOException {
        checkedId(id);
        Files.createDirectories(dir);restrict(dir,true);
        Path config=dir.resolve("config.properties");
        Properties properties=new Properties();properties.setProperty("clientId",id);
        Path temp=Files.createTempFile(dir,".config-",".tmp");
        try {
            restrict(temp,false);
            try(OutputStream output=Files.newOutputStream(temp)){
                properties.store(output,"AlphaModern Microsoft public application ID (not an access token)");
            }
            try{Files.move(temp,config,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}
            catch(AtomicMoveNotSupportedException e){Files.move(temp,config,StandardCopyOption.REPLACE_EXISTING);}
            restrict(config,false);
        }finally{Files.deleteIfExists(temp);}
        return config;
    }
    synchronized void logout() throws IOException {Files.deleteIfExists(credentialFile);}
    Path path() {return credentialFile;}
    private void save(Profile p) throws IOException {
        Files.createDirectories(directory);
        restrict(directory,true);
        Properties props=new Properties();
        props.setProperty("format","1");props.setProperty("name",p.name);
        props.setProperty("uuid",p.uuid);props.setProperty("clientId",p.clientId);
        props.setProperty("minecraftToken",p.minecraftToken);
        props.setProperty("refreshToken",p.refreshToken);
        props.setProperty("minecraftExpires",String.valueOf(p.minecraftExpires));
        Path temp=Files.createTempFile(directory,".auth-",".tmp");
        try {
            restrict(temp,false);
            try(OutputStream out=Files.newOutputStream(temp)) {props.store(out,"AlphaModern account session - KEEP THIS FILE PRIVATE");}
            try{Files.move(temp,credentialFile,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}
            catch(AtomicMoveNotSupportedException e){Files.move(temp,credentialFile,StandardCopyOption.REPLACE_EXISTING);}
            restrict(credentialFile,false);
        }finally{Files.deleteIfExists(temp);}
    }
    private static void restrict(Path p,boolean dir){
        try {
            Set<PosixFilePermission> perms=dir?EnumSet.of(PosixFilePermission.OWNER_READ,PosixFilePermission.OWNER_WRITE,PosixFilePermission.OWNER_EXECUTE):
                EnumSet.of(PosixFilePermission.OWNER_READ,PosixFilePermission.OWNER_WRITE);
            Files.setPosixFilePermissions(p,perms);
        }catch(UnsupportedOperationException ignored) {
            File f=p.toFile();f.setReadable(false,false);f.setWritable(false,false);f.setReadable(true,true);f.setWritable(true,true);
        }catch(IOException e){System.err.println(AlphaModernAgent.PREFIX+"Warning: couldn't restrict login file permissions: "+e.getMessage());}
    }
    private Response form(String url,Map<String,String> params) throws IOException {
        StringBuilder b=new StringBuilder();
        for(Map.Entry<String,String> entry:params.entrySet()){
            if(b.length()>0)b.append('&');
            b.append(URLEncoder.encode(entry.getKey(),"UTF-8")).append('=').append(URLEncoder.encode(entry.getValue(),"UTF-8"));
        }
        return call(url,"POST","application/x-www-form-urlencoded",b.toString(),null);
    }
    private Response json(String url,String data,String bearer) throws IOException{return call(url,"POST","application/json",data,bearer);}
    private Response get(String url,String bearer) throws IOException{return call(url,"GET",null,null,bearer);}
    private Response call(String url,String method,String contentType,String body,String bearer) throws IOException {
        URL target=new URL(url);
        HttpURLConnection conn=(HttpURLConnection)target.openConnection();
        conn.setInstanceFollowRedirects(false);conn.setConnectTimeout(12000);conn.setReadTimeout(12000);
        conn.setRequestMethod(method);conn.setRequestProperty("Accept","application/json");
        conn.setRequestProperty("User-Agent","AlphaModern/0.5 (Minecraft Alpha Java Edition)");
        if(bearer!=null)conn.setRequestProperty("Authorization","Bearer "+bearer);
        if(body!=null){
            conn.setDoOutput(true);conn.setRequestProperty("Content-Type",contentType+"; charset=utf-8");
            byte[] bytes=body.getBytes(StandardCharsets.UTF_8);
            conn.setFixedLengthStreamingMode(bytes.length);
            try(OutputStream output=conn.getOutputStream()){output.write(bytes);}
        }
        int status=conn.getResponseCode();
        try {
            if(status==204)return new Response(status,Collections.<String,Object>emptyMap());
            InputStream input=status<400?conn.getInputStream():conn.getErrorStream();
            if(input==null)return new Response(status,Collections.<String,Object>emptyMap());
            try(InputStream stream=input){
                ByteArrayOutputStream buffer=new ByteArrayOutputStream();byte[] data=new byte[4096];int n;
                while((n=stream.read(data))>=0){if(buffer.size()+n>1048576)throw new IOException("Oversized authorization response");buffer.write(data,0,n);}
                if(buffer.size()==0)return new Response(status,Collections.<String,Object>emptyMap());
                return new Response(status,AuthJson.object(AuthJson.parse(new String(buffer.toByteArray(),StandardCharsets.UTF_8))));
            }
        }finally{conn.disconnect();}
    }
    private static void requireSuccess(Response r,String stage) throws IOException {if(!r.ok())throw authError(r,stage);}
    private static IOException authError(Response r,String stage){
        String code=AuthJson.optional(r.data,"error","HTTP "+r.status);
        // Never echo raw server messages, which might include a credential.
        if(code.length()>80)code=code.substring(0,80);
        return new IOException(stage+" failed (HTTP "+r.status+", "+code+")");
    }
    private static void pause(long millis,BooleanSupplier connected) throws IOException {
        long end=System.currentTimeMillis()+millis;
        while(System.currentTimeMillis()<end){
            checkRunning(connected);
            try{Thread.sleep(Math.min(250,Math.max(1,end-System.currentTimeMillis())));}
            catch(InterruptedException e){Thread.currentThread().interrupt();throw new IOException("Microsoft authentication interrupted",e);}
        }
    }
    private static void checkRunning(BooleanSupplier connected) throws IOException {if(!connected.getAsBoolean())throw new IOException("Login was cancelled");}
    private static LinkedHashMap<String,String> map(String... pairs){
        LinkedHashMap<String,String> m=new LinkedHashMap<String,String>();
        for(int i=0;i<pairs.length;i+=2)m.put(pairs[i],pairs[i+1]);
        return m;
    }
}
