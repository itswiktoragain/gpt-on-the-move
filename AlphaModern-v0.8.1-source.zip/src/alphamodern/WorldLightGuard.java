package alphamodern;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Caps Alpha 1.0.15's recursive lighting-work queue while the 26.2 bridge is
 * active.  Old Alpha's cj.a(bu,...) can recursively invoke cj.e() when its
 * backlog exceeds 100,000 jobs; processing those jobs can schedule more jobs
 * and cause a StackOverflowError (cj.e -> kb.a -> cj.a -> cj.e).
 *
 * The modern server provides chunk/block light arrays, so a bounded legacy
 * relight queue is an acceptable approximation while bridging.  Singleplayer
 * and unbridged Alpha worlds retain the original List.add behavior.
 */
public final class WorldLightGuard {
    private static final AtomicInteger ACTIVE = new AtomicInteger();
    private static final AtomicLong DROPPED = new AtomicLong();
    private static final int LIMIT = Math.max(256,
            Math.min(32768, Integer.getInteger("alpha.modern.lightQueueLimit", 8192)));

    private WorldLightGuard() {}

    static void beginBridge() {
        int count = ACTIVE.incrementAndGet();
        if (count == 1) {
            DROPPED.set(0);
            System.out.println(AlphaModernAgent.PREFIX +
                "Safe lighting queue enabled (max " + LIMIT + " pending jobs)");
        }
    }

    static void endBridge() {
        while (true) {
            int n=ACTIVE.get();
            if (n==0) return;
            if (ACTIVE.compareAndSet(n,n-1)) return;
        }
    }

    /** Same operand types and return value as java.util.List.add(Object). */
    @SuppressWarnings({"rawtypes", "unchecked"})
    public static boolean offer(List jobs, Object job) {
        if (ACTIVE.get() == 0 || jobs.size() < LIMIT) return jobs.add(job);
        long n = DROPPED.incrementAndGet();
        if (n == 1 || (n % 50000) == 0)
            System.out.println(AlphaModernAgent.PREFIX +
                "Deferred " + n + " legacy relighting jobs; modern chunk light is retained");
        return false;
    }

    static int limit() { return LIMIT; }
    static long dropped() { return DROPPED.get(); }
    static int active() { return ACTIVE.get(); }
}
