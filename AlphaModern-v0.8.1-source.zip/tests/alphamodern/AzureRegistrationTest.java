package alphamodern;

import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.PosixFilePermission;
import java.util.Properties;
import java.util.Set;

/** Simulated Azure CLI: does not create any real account or contact Microsoft. */
public final class AzureRegistrationTest {
    private static final String ID="44444444-aaaa-4bbb-8ccc-1234567890ab";
    static void expect(boolean cond,String explanation) {if(!cond)throw new AssertionError(explanation);}
    static Path cli(Path root,String behavior) throws Exception {
        Path command=root.resolve("fake-az-"+behavior+".sh");
        String script="#!/bin/sh\n"+
            "case \"$1\" in\n"+
            "version) exit 0;;\n"+
            "account) exit 1;;\n"+
            "login) echo 'To sign in, use a web browser to open the page https://microsoft.com/devicelogin and enter the code AZURE-789 to authenticate.'; exit 0;;\n"+
            "ad) "+("success".equals(behavior)?"echo '"+ID+"'; exit 0":"echo INVALID_ID; exit 0")+";;\n"+
            "*) exit 8;;\n"+
            "esac\n";
        Files.write(command,script.getBytes(StandardCharsets.UTF_8));
        command.toFile().setExecutable(true,true);
        return command;
    }
    static void checkStored(Path folder) throws Exception {
        Path path=folder.resolve("config.properties");
        expect(Files.isRegularFile(path),"Registered app ID wasn't stored");
        Properties p=new Properties();
        try(java.io.InputStream i=Files.newInputStream(path)){p.load(i);}
        expect(ID.equals(p.getProperty("clientId")),"Unexpected saved Entra app ID");
        try {
            Set<PosixFilePermission> perms=Files.getPosixFilePermissions(path);
            expect(!perms.contains(PosixFilePermission.GROUP_WRITE)&&!perms.contains(PosixFilePermission.OTHERS_WRITE),"App ID file is writable by other users");
        }catch(UnsupportedOperationException ignored){}
    }
    public static void main(String[] args) throws Exception {
        System.setProperty("alpha.modern.noBrowser", "true");
        AuthOverlay.setEmailForTests("test@example.com");
        Path root=Files.createTempDirectory("alpha-azurecli-tests");
        Path good=cli(root,"success"),bad=cli(root,"bad");
        System.setProperty("alpha.modern.azureCli",good.toString());
        HttpServer service=AuthIntegrationTest.fakeAccounts();
        try {
            Path folder=root.resolve("fresh");
            String registered=AzureClientRegistrar.local().register(folder,()->true);
            expect(ID.equals(registered),"Explicit Azure registration returned the wrong ID");
            AuthManager manager=new AuthManager(folder,null,AuthIntegrationTest.urls(service));
            AuthManager.Profile p=manager.ensure(()->true);
            expect(p.valid(),"App registration didn't proceed to mock Minecraft authentication");
            expect(ID.equals(p.clientId),"Device-code login did not use the registered public application ID");
            checkStored(folder);
            expect(Files.isRegularFile(manager.path()),"Minecraft profile not saved after auto-registration");
            AuthManager another=new AuthManager(folder,null,AuthIntegrationTest.urls(service));
            System.setProperty("alpha.modern.azureCli",root.resolve("nonexistent-az").toString());
            expect(another.ensure(()->true).valid(),"Saved public client ID and token were not reused without Azure CLI");
            System.out.println("PASS: Azure CLI interactive device code, real-looking Entra app response, persisted client ID, mocked Minecraft login and reuse without CLI");
            Path invalid=root.resolve("invalid");
            System.setProperty("alpha.modern.azureCli",bad.toString());
            AuthManager missingId=new AuthManager(invalid,null,AuthIntegrationTest.urls(service));
            try {AzureClientRegistrar.local().register(invalid,()->true);throw new AssertionError("Invalid Entra response was accepted");}
            catch(IOException e){expect(e.getMessage().contains("did not return a valid"),"Unexpected error for invalid app response: "+e);}
            expect(!Files.exists(invalid.resolve("config.properties")),"Invalid or fabricated ID was saved");
            System.out.println("PASS: invalid/unregistered-looking Azure app ID is never written to disk");
            Path unavailable=root.resolve("unavailable");
            System.setProperty("alpha.modern.azureCli",root.resolve("nonexistent-az").toString());
            try {AzureClientRegistrar.local().register(unavailable,()->true);
                 throw new AssertionError("Missing Azure CLI unexpectedly worked for explicit registration");}
            catch(IOException e){expect(e.getMessage().contains("Azure CLI"),"Explicit registration should report missing Azure CLI");}
            expect(!Files.exists(unavailable.resolve("config.properties")),"Missing Azure CLI generated a fake client ID");
            System.out.println("PASS: explicit optional registration reports missing Azure CLI and never fabricates a client ID");
            System.out.println("ALL REGISTRATION TESTS PASSED");
        }finally {service.stop(0);System.clearProperty("alpha.modern.azureCli");AuthOverlay.setEmailForTests(null);}
    }
}
