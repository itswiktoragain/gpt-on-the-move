package alphamodern;

import com.sun.net.httpserver.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/** Offline end-to-end mock for the publicly documented Xbox/Switch link-code flow. */
public final class SwitchAuthTest {
    static final AtomicInteger codes=new AtomicInteger(), polls=new AtomicInteger(),refreshes=new AtomicInteger();
    static final AtomicReference<String> shownCode=new AtomicReference<String>("");
    static final String UUID32="1234567890abcdef1234567890abcdef";
    static void check(boolean x,String reason){if(!x)throw new AssertionError(reason);}
    static String body(HttpExchange x)throws IOException{return new String(AlphaModernAgent.readAll(x.getRequestBody()),StandardCharsets.UTF_8);}
    static void reply(HttpExchange x,int code,String value)throws IOException{
        byte[] data=value.getBytes(StandardCharsets.UTF_8);
        x.getResponseHeaders().set("Content-Type","application/json");
        if(code==204){x.sendResponseHeaders(code,-1);x.close();return;}
        x.sendResponseHeaders(code,data.length);
        try(OutputStream out=x.getResponseBody()){out.write(data);}
    }
    public static void main(String[] args)throws Exception{
        System.setProperty("alpha.modern.noBrowser","true");
        AuthOverlay.setEmailForTests("test@example.com");
        Path home=Files.createTempDirectory("alphamodern-switch-");
        HttpServer server=HttpServer.create(new InetSocketAddress(InetAddress.getLoopbackAddress(),0),4);
        server.setExecutor(Executors.newCachedThreadPool(r->{Thread t=new Thread(r,"switch-mock");t.setDaemon(true);return t;}));
        server.createContext("/device",x->{
            String b=body(x);codes.incrementAndGet();
            check(b.contains("client_id="+AuthManager.SWITCH_CLIENT_ID),"Wrong first-party client ID: "+b);
            check(b.contains("scope=service%3A%3Auser.auth.xboxlive.com%3A%3AMBI_SSL"),"Wrong Xbox scope");
            check(b.contains("response_type=device_code"),"Legacy Live endpoint requires response_type=device_code");
            check(!b.contains("example.com"),"Email must not leak to token endpoint");
            reply(x,200,"{\"device_code\":\"SECRET_DEVICE_TOKEN\",\"user_code\":\"NSXW-ABCD\",\"verification_uri\":\"https://www.microsoft.com/link\",\"expires_in\":90,\"interval\":1}");
        });
        server.createContext("/token",x->{
            String b=body(x);
            check(b.contains("client_id="+AuthManager.SWITCH_CLIENT_ID),"Refresh and code requests must reuse the same ID");
            if(b.contains("grant_type=refresh_token")){
                refreshes.incrementAndGet();
                check(b.contains("refresh_token=SWITCH_REFRESH_ONE"),"Wrong original refresh token");
                reply(x,200,"{\"access_token\":\"SWITCH_MSA_TOKEN_REFRESHED\",\"refresh_token\":\"SWITCH_REFRESH_TWO\",\"expires_in\":3600}");
                return;
            }
            check(b.contains("device_code=SECRET_DEVICE_TOKEN"),"Wrong device code used in poll");
            AuthOverlay.State visible=AuthOverlay.state;
            if(visible!=null)shownCode.set(visible.code);
            int n=polls.incrementAndGet();
            if(n==1)reply(x,400,"{\"error\":\"authorization_pending\"}");
            else reply(x,200,"{\"access_token\":\"SWITCH_MSA_TOKEN\",\"refresh_token\":\"SWITCH_REFRESH_ONE\",\"expires_in\":3600}");
        });
        server.createContext("/xbox",x->{
            String b=body(x);
            check(b.contains("\"RpsTicket\":\"SWITCH_MSA_TOKEN"),"First-party Xbox token must use the RAW RpsTicket, not d= prefix");
            check(!b.contains("d=SWITCH_MSA_TOKEN"),"Unexpected custom Entra RpsTicket prefix");
            reply(x,200,"{\"Token\":\"SWITCH_XBOX\"}");
        });
        server.createContext("/xsts",x->{check(body(x).contains("SWITCH_XBOX"),"Missing XBL token");reply(x,200,"{\"Token\":\"SWITCH_XSTS\",\"DisplayClaims\":{\"xui\":[{\"uhs\":\"0123456\"}]}}");});
        server.createContext("/minecraft",x->{check(body(x).contains("XBL3.0 x=0123456;SWITCH_XSTS"),"Missing XSTS user hash");reply(x,200,"{\"access_token\":\"SWITCH_MINECRAFT\",\"expires_in\":7200}");});
        server.createContext("/profile",x->{check("Bearer SWITCH_MINECRAFT".equals(x.getRequestHeaders().getFirst("Authorization")),"Wrong game bearer token");reply(x,200,"{\"id\":\""+UUID32+"\",\"name\":\"TestAccount\"}");});
        server.createContext("/join",x->{reply(x,204,"");});
        server.start();
        String b="http://127.0.0.1:"+server.getAddress().getPort();
        AuthManager.Endpoints urls=new AuthManager.Endpoints(b+"/device",b+"/token",b+"/xbox",b+"/xsts",b+"/minecraft",b+"/profile",b+"/join");
        AuthManager manager=new AuthManager(home,null,urls);
        try{
            check(AuthManager.Endpoints.live().device.equals("https://login.live.com/oauth20_connect.srf"),"Live device endpoint is wrong");
            check(AuthManager.Endpoints.live().token.equals("https://login.live.com/oauth20_token.srf"),"Live token endpoint is wrong");
            AuthManager.Profile profile=manager.ensure(()->true);
            check("TestAccount".equals(profile.name)&&profile.valid(),"Could not authenticate switch mock");
            check(codes.get()==1&&polls.get()==2,"Link flow was not completed");
            check("NSXW-ABCD".equals(shownCode.get()),"Incorrect link code overlay");
            Properties cfg=new Properties();
            try(InputStream in=Files.newInputStream(home.resolve("config.properties"))){cfg.load(in);}
            check(AuthManager.SWITCH_CLIENT_ID.equals(cfg.getProperty("clientId")),"Client ID not stored locally");
            check(manager.ensure(()->true).valid()&&codes.get()==1,"Cached token not reused");
            Properties p=new Properties();try(InputStream in=Files.newInputStream(manager.path())){p.load(in);}
            p.setProperty("minecraftExpires","0");try(OutputStream out=Files.newOutputStream(manager.path())){p.store(out,"test");}
            check(manager.ensure(()->true).valid()&&refreshes.get()==1,"No automatic refresh");
            try(InputStream in=Files.newInputStream(manager.path())){p.load(in);}
            check("SWITCH_REFRESH_TWO".equals(p.getProperty("refreshToken")),"Rotated refresh token not saved");
            System.out.println("PASS: no Azure CLI, Microsoft Xbox/Switch device code, in-game code, raw Xbox ticket, stored client ID, cached session and silent refresh");
        }finally{server.stop(0);AuthOverlay.setEmailForTests(null);}
    }
}
