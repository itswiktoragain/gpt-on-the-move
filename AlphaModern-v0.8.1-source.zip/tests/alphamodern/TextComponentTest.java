package alphamodern;

import java.io.*;
import java.nio.charset.StandardCharsets;

public class TextComponentTest {
    static void check(boolean ok,String why) {if(!ok)throw new AssertionError(why);}
    static void key(DataOutputStream o,int type,String name) throws IOException {
        o.writeByte(type);utf(o,name);
    }
    static void utf(DataOutputStream o,String value) throws IOException {
        byte[] raw=value.getBytes(StandardCharsets.UTF_8);o.writeShort(raw.length);o.write(raw);
    }
    static void item(DataOutputStream o,String text,String color,boolean link) throws IOException {
        key(o,8,"text");utf(o,text);
        key(o,8,"color");utf(o,color);
        if(link) {
            key(o,10,"click_event");
            key(o,8,"action");utf(o,"open_url");
            key(o,8,"url");utf(o,"https://example.com/");
            o.writeByte(0);
        }
        o.writeByte(0);
    }
    static void sendStructured(DataOutputStream o) throws IOException {
        o.writeByte(10); // network root TAG_Compound with no name
        key(o,8,"text");utf(o,"");
        key(o,9,"extra");o.writeByte(10);o.writeInt(3);
        item(o,"TWITTER", "aqua", true);
        item(o," Purchase your ranks, gold, and more ","gold",false);
        item(o,"at store.jartexnetwork.com", "yellow",false);
        o.writeByte(0);
    }
    static String read(byte[] bytes) throws IOException {return TextComponent.readFormatted(new DataInputStream(new ByteArrayInputStream(bytes)));}
    static void testRich() throws IOException {
        ByteArrayOutputStream b=new ByteArrayOutputStream();DataOutputStream o=new DataOutputStream(b);
        sendStructured(o);o.writeBoolean(false);
        DataInputStream in=new DataInputStream(new ByteArrayInputStream(b.toByteArray()));
        String result=TextComponent.readFormatted(in);
        check(result.contains("\u00a7bTWITTER"),"expected aqua colored twitter text: "+result);
        check(result.contains("\u00a76 Purchase your ranks"),"expected gold text: "+result);
        check(result.contains("\u00a7eat store.jartexnetwork.com"),"expected yellow text: "+result);
        check(!result.contains("extra")&&!result.contains("click_event")&&!result.contains("open_url"),"NBT leaked into chat: "+result);
        check(in.readBoolean()==false && in.available()==0,"Didn't consume exactly one component before overlay boolean");
        System.out.println("PASS: NBT compound extras, inline color codes, hidden click events, trailing overlay byte");
    }
    static void testRaw() throws IOException {
        ByteArrayOutputStream b=new ByteArrayOutputStream();DataOutputStream o=new DataOutputStream(b);
        o.writeByte(8);utf(o,"Welcome to the world");
        check(read(b.toByteArray()).contains("Welcome to the world"),"raw tag string not rendered");
        System.out.println("PASS: NBT TAG_String plain chat");
    }
    static void testTranslateAndHex() throws IOException {
        ByteArrayOutputStream b=new ByteArrayOutputStream();DataOutputStream o=new DataOutputStream(b);
        o.writeByte(10);
        key(o,8,"translate");utf(o,"chat.type.text");
        key(o,9,"with");o.writeByte(10);o.writeInt(2);
        item(o,"Player","#55FFFF",false);
        item(o,"hello","gray",false);
        o.writeByte(0);
        String result=read(b.toByteArray());
        check(result.contains("<\u00a7bPlayer> \u00a77hello"),"translation or hex conversion failed: "+result);
        System.out.println("PASS: translate placeholders and RGB -> nearest legacy color");
    }
    static void testMalformed() throws IOException {
        try{read(new byte[]{10,9,0,5,'e','x','t','r','a',8,0,0,0,127});throw new AssertionError("malformed list should be rejected");}
        catch(IOException good){}
        System.out.println("PASS: malformed NBT fails safely");
    }
    public static void main(String[] args) throws IOException {
        testRich();testRaw();testTranslateAndHex();testMalformed();
        System.out.println("ALL CHAT TESTS PASSED");
    }
}
