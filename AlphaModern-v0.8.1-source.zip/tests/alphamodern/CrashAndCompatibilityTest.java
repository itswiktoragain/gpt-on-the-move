package alphamodern;

import java.io.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

/** Regression tests based on PrismLauncher October 24 crash and rejected chunk spam. */
public final class CrashAndCompatibilityTest {
    private static void check(boolean b,String msg) {if(!b)throw new AssertionError(msg);}
    private static byte[] packet(int sections,boolean fluid,boolean lengthPrefix,boolean allAir) throws IOException {
        ByteArrayOutputStream blob=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(blob);
        for(int i=0;i<sections;i++){
            out.writeShort(allAir?0:4096);if(fluid)out.writeShort(0);
            out.writeByte(0);Wire.var(out,allAir?0:8);if(lengthPrefix)Wire.var(out,0);
            out.writeByte(0);Wire.var(out,0);if(lengthPrefix)Wire.var(out,0);
        }
        byte[] buf=blob.toByteArray();
        ByteArrayOutputStream whole=new ByteArrayOutputStream();DataOutputStream pkt=new DataOutputStream(whole);
        pkt.writeInt(9);pkt.writeInt(-9);Wire.var(pkt,0);Wire.var(pkt,buf.length);pkt.write(buf);
        return whole.toByteArray();
    }
    private static void verifyChunk(int sections,boolean fluid,boolean prefix,boolean air) throws Exception {
        byte[] bytes=packet(sections,fluid,prefix,air);
        ChunkTranslator.LegacyChunk c=ChunkTranslator.decodeChunk(new DataInputStream(new ByteArrayInputStream(bytes)),-64,384,16);
        check(c.x==9&&c.z==-9,"chunk coordinate misread");
        int y=64;
        check((c.data[y]&255)==(air?0:2),"Expected "+(air?"air":"stone")+" at translated Y=64");
        check(c.data.length==81920,"old packet size must be 81920 bytes");
        System.out.println("PASS: "+sections+" sections, fluid="+fluid+", packedLongPrefix="+prefix+", air="+air);
    }
    static void verifyFontPatch(Path alpha) throws Exception {
        try(ZipFile in=new ZipFile(alpha.toFile())) {
            ZipEntry e=in.getEntry("js.class");check(e!=null,"missing Alpha font renderer");
            byte[] original,patched;
            try(InputStream src=in.getInputStream(e)){original=AlphaModernAgent.readAll(src);}
            patched=FontRendererPatch.patch(original);
            check(patched.length==original.length,"font patch should not change code length");
            // Exact original and corrected machine-code jump offsets.
            int hits=0;
            for(int i=8;i+5<patched.length;i++){
                if((original[i]&255)==0x84&&(original[i+1]&255)==6&&
                   (original[i+2]&255)==2&&(original[i+3]&255)==0xa7&&
                   (original[i+4]&255)==0xff&&(original[i+5]&255)==0x84) {
                    hits++;check((patched[i+5]&255)==0x7b,"font jump must target condition");
                }
            }
            check(hits==1,"expected one patched loop jump, found "+hits);
            System.out.println("PASS: real Alpha js.class formatting loop now targets bounds check (no out-of-range charAt)");
        }
    }
    private static void verifyChat() throws Exception {
        Method safe=Gateway.Session.class.getDeclaredMethod("alphaSafeChat",String.class);
        safe.setAccessible(true);
        for(String text:new String[]{"\u00a7b", "Hello\u00a7f", "\u00a7cSome text\u00a7b\u00a7f", "\u00a7bA\u00a7e", "Hello\u00a7"}) {
            String v=(String)safe.invoke(null,text);
            check(!v.endsWith("\u00a7"),"isolated sign survived");
            check(!v.matches("(?s).*\u00a7[0-9a-f]$"),"trailing color survived: "+v);
        }
        check("\u00a7bA".equals(safe.invoke(null,"\u00a7bA\u00a7e")),"color content lost");
        System.out.println("PASS: chat removes trailing and incomplete color codes before legacy packets");
    }
    public static void main(String[] args) throws Exception {
        Path alpha=Paths.get(args.length>0 && !args[0].isEmpty()?args[0]:"/mnt/data/minecraft-a1.0.15-client.jar");
        if(Files.isRegularFile(alpha))verifyFontPatch(alpha);
        else System.out.println("SKIP: supply your original Alpha 1.0.15 JAR to verify the font patch byte-for-byte");
        verifyChat();
        verifyChunk(24,true,false,true);
        verifyChunk(24,false,false,false);
        verifyChunk(24,true,true,false);
        verifyChunk(24,false,true,false);
        verifyChunk(16,true,false,false);
        verifyChunk(16,false,false,true);
        byte[] bad=packet(24,true,false,true);
        bad=Arrays.copyOf(bad,bad.length-2);
        try {ChunkTranslator.decodeChunk(new DataInputStream(new ByteArrayInputStream(bad)),-64,384,16);
            throw new AssertionError("malformed section data was accepted");
        }catch(IOException expected){
            check(expected.getMessage()!=null&&(expected.getMessage().contains("section")||expected.getMessage().contains("Truncated chunk")),"missing actionable diagnostics: "+expected);
        }
        System.out.println("PASS: truncated sections are rejected with context, not a null error");
        System.out.println("ALL CRASH AND COMPATIBILITY TESTS PASSED");
    }
}
