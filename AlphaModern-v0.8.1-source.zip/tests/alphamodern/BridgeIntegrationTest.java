package alphamodern;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.zip.*;
import javax.crypto.*;
import java.security.*;
import javax.crypto.spec.*;

public class BridgeIntegrationTest {
    static final int PROTOCOL=776;
    static void expect(boolean b,String msg){if(!b)throw new AssertionError(msg);}
    static byte[] chunkData() throws Exception {
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();DataOutputStream w=new DataOutputStream(bytes);
        for(int sec=0;sec<24;sec++){
            w.writeShort(sec==4?4096:0);
            w.writeShort(0); // protocol 776 fluidCount (new in 26.x)
            w.writeByte(0);Wire.var(w,sec==4?1:0); // block state air or stone
            w.writeByte(0);Wire.var(w,0); // biome plains global id 0
        }
        return bytes.toByteArray();
    }
    static void simulateModernServer(ServerSocket server, boolean encrypt) {
        try (Socket remote=server.accept()) {
            remote.setSoTimeout(12000);Wire modern=new Wire(remote);
            Wire.Packet p=modern.recv();expect(p.id==0,"no handshake");
            int proto=Wire.var(p.data);expect(proto==776,"wrong protocol "+proto);
            String host=Wire.str(p.data);expect(!host.isEmpty(),"empty host");
            p.data.readUnsignedShort();expect(Wire.var(p.data)==2,"not login state");
            p=modern.recv();expect(p.id==0,"no login start");
            String n=Wire.str(p.data);expect(n.equals("Tester"),"wrong username "+n);
            p.data.readLong();p.data.readLong(); // login profile UUID
            if(encrypt) {
                KeyPairGenerator g=KeyPairGenerator.getInstance("RSA");g.initialize(1024);KeyPair keys=g.generateKeyPair();
                byte[] challenge={3,6,1,0,8};
                modern.send(1,o->{Wire.str(o,"");Wire.bytes(o,keys.getPublic().getEncoded());Wire.bytes(o,challenge);o.writeBoolean(false);});
                p=modern.recv();expect(p.id==1,"no key response");
                byte[] encKey=Wire.bytes(p.data,1024),encChallenge=Wire.bytes(p.data,1024);
                Cipher rsa=Cipher.getInstance("RSA/ECB/PKCS1Padding");rsa.init(Cipher.DECRYPT_MODE,keys.getPrivate());
                byte[] secret=rsa.doFinal(encKey);expect(Arrays.equals(rsa.doFinal(encChallenge),challenge),"wrong challenge");
                modern.encrypt(new SecretKeySpec(secret,"AES"));
            }
            modern.send(3,o->Wire.var(o,64));modern.compression(64);
            modern.send(2,o->{Wire.uuid(o,UUID.randomUUID());Wire.str(o,"Tester");Wire.var(o,0);Wire.uuid(o,UUID.randomUUID());});
            int i=0;boolean acknowledged=false;
            while(i++<8&&!acknowledged) {p=modern.recv();if(p.id==3)acknowledged=true;}
            expect(acknowledged,"no login acknowledged");
            modern.send(14,o->Wire.var(o,0));
            int tries=0;boolean packsAck=false;
            while(tries++<8&&!packsAck){p=modern.recv();if(p.id==7)packsAck=true;}
            expect(packsAck,"no known packs response");
            modern.send(3,o->{});
            tries=0;boolean configAck=false;
            while(tries++<8&&!configAck){p=modern.recv();if(p.id==3)configAck=true;}
            expect(configAck,"no config finish ack");
            modern.send(GameIds.CLIENTBOUND_LOGIN,o->{o.writeInt(233);o.writeBoolean(false);
                Wire.var(o,1);Wire.str(o,"minecraft:overworld");Wire.var(o,20);Wire.var(o,8);Wire.var(o,6);
                o.writeBoolean(false);o.writeBoolean(true);o.writeBoolean(false);
                Wire.var(o,0);Wire.str(o,"minecraft:overworld");
            });
            modern.send(GameIds.CLIENTBOUND_PLAYER_POSITION,o->{Wire.var(o,1);o.writeDouble(5);o.writeDouble(70);o.writeDouble(8);
                o.writeDouble(0);o.writeDouble(0);o.writeDouble(0);o.writeFloat(20);o.writeFloat(5);o.writeInt(0);});
            byte[] chunk=chunkData();
            modern.send(GameIds.CLIENTBOUND_LEVEL_CHUNK_WITH_LIGHT,o->{o.writeInt(0);o.writeInt(0);Wire.var(o,0);Wire.var(o,chunk.length);o.write(chunk);});
            modern.send(GameIds.CLIENTBOUND_KEEP_ALIVE,o->o.writeLong(1234567890L));
            // Expect movement, chat, teleport, keepalive echoed back.
            Set<Integer> got=new HashSet<Integer>();
            for(int j=0;j<20&&got.size()<4;j++){p=modern.recv();
                if(p.id==GameIds.SERVERBOUND_ACCEPT_TELEPORTATION||p.id==GameIds.SERVERBOUND_KEEP_ALIVE||
                    p.id==GameIds.SERVERBOUND_MOVE_PLAYER_POS_ROT||p.id==GameIds.SERVERBOUND_CHAT)got.add(p.id);
            }
            expect(got.size()==4,"not all translated play packets received: "+got);
        }catch(Throwable err){throw new RuntimeException("Mock server failed",err);}
    }
    static void simulateAlpha(int p) throws Exception {
        try(Socket alpha=new BridgeSocket(InetAddress.getLoopbackAddress(),p)){
            alpha.setSoTimeout(12000);
            DataOutputStream o=new DataOutputStream(alpha.getOutputStream());
            DataInputStream in=new DataInputStream(alpha.getInputStream());
            o.writeByte(1);o.writeInt(13);o.writeUTF("Tester");o.writeUTF("Password");o.flush();
            boolean login=false,position=false,chunk=false;
            for(int i=0;i<8&&!(login&&position&&chunk);i++){
                int id=in.readUnsignedByte();
                if(id==1){expect(in.readInt()==233,"wrong entity id");in.readUTF();in.readUTF();login=true;}
                else if(id==3){String msg=in.readUTF();expect(msg.contains("AlphaModern"),"bad chat "+msg);}
                else if(id==13){expect(in.readDouble()==5,"wrong x");expect(in.readDouble()==70,"wrong y");in.readDouble();in.readDouble();in.readFloat();in.readFloat();in.readBoolean();position=true;}
                else if(id==50){int cx=in.readInt(),cz=in.readInt();boolean on=in.readBoolean();expect(cx==0&&cz==0&&on,"bad chunk load");}
                else if(id==51){int x=in.readInt(),y=in.readShort(),z=in.readInt(),width=in.readUnsignedByte(),height=in.readUnsignedByte(),depth=in.readUnsignedByte();
                    expect(x==0&&y==0&&z==0&&width==15&&height==127&&depth==15,"wrong chunk bounds");
                    int count=in.readInt();byte[] zip=new byte[count];in.readFully(zip);
                    Inflater zlib=new Inflater();zlib.setInput(zip);byte[] inflated=new byte[81920];int uncompressed=zlib.inflate(inflated);zlib.end();
                    expect(uncompressed==81920,"invalid legacy map length: "+uncompressed);
                    expect(inflated[0]==1 && inflated[16]==0,"incorrect block conversion");
                    chunk=true;
                }else if(id==255){throw new AssertionError("Gateway kicked Alpha: "+in.readUTF());}
                else throw new AssertionError("Unexpected alpha packet "+id);
            }
            expect(login&&position&&chunk,"Missing login, position or chunk packet: "+login+","+position+","+chunk);
            o.writeByte(13);o.writeDouble(7);o.writeDouble(70);o.writeDouble(71.62);o.writeDouble(9);o.writeFloat(90);o.writeFloat(0);o.writeBoolean(true);
            o.writeByte(3);o.writeUTF("hello from Alpha");o.flush();
            Thread.sleep(400);
        }
    }
    public static void main(String[] args) throws Exception {
        Gateway.start();
        for(boolean encrypt:new boolean[]{false,true}){
            ServerSocket mock = new ServerSocket(0,1,InetAddress.getLoopbackAddress());
            final boolean e=encrypt;
            ExecutorService threads=Executors.newSingleThreadExecutor();
            Future<?> server=threads.submit(()->simulateModernServer(mock,e));
            simulateAlpha(mock.getLocalPort());
            server.get(15,TimeUnit.SECONDS);threads.shutdownNow();mock.close();
            System.out.println("PASS: protocol-776 handshake, "+(encrypt?"RSA/AES-CFB8, ":"")+"compression, config, chunk, position, chat and keepalive");
        }
        System.out.println("ALL TESTS PASSED");
    }
}
