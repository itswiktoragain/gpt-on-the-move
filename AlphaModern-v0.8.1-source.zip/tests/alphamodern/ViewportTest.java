package alphamodern;
import java.io.*;
public class ViewportTest {
    static void check(boolean b,String s) {if(!b)throw new AssertionError(s);}
    static byte[] packet(int y,int globalState) throws Exception {
        ByteArrayOutputStream b=new ByteArrayOutputStream();DataOutputStream o=new DataOutputStream(b);
        o.writeInt(4);o.writeInt(-1);Wire.var(o,0); // chunk x,z, empty heightmaps
        ByteArrayOutputStream sections=new ByteArrayOutputStream();DataOutputStream sec=new DataOutputStream(sections);
        int section=(y+64)/16;
        for(int s=0;s<24;s++) {
            sec.writeShort(s==section?1:0);sec.writeShort(0);
            if(s==section) {
                sec.writeByte(4);Wire.var(sec,2);Wire.var(sec,0);Wire.var(sec,globalState);
                int targetWord=((y+64)%16)*16;
                for(int l=0;l<256;l++)sec.writeLong(l==targetWord?1:0);
            } else {sec.writeByte(0);Wire.var(sec,0);}
            sec.writeByte(0);Wire.var(sec,0);
        }
        byte[] payload=sections.toByteArray();Wire.var(o,payload.length);o.write(payload);
        return b.toByteArray();
    }
    public static void main(String[] args) throws Exception {
        check(VerticalViewport.chooseBase(70,-64,384)==0,"normal spawn viewport");
        check(VerticalViewport.chooseBase(250,-64,384)==176,"high spawn viewport");
        check(VerticalViewport.chooseBase(-30,-64,384)==-64,"negative spawn viewport");
        check(VerticalViewport.chooseBase(310,-64,384)==192,"ceiling clamp");
        check(VerticalViewport.shouldRecenter(250,0,-64,384),"high teleport triggers rebase");
        check(!VerticalViewport.shouldRecenter(70,0,-64,384),"normal movement doesn't rebase");
        int[] heights={-30,65,250};
        for(int modernY:heights) {
            int base=VerticalViewport.chooseBase(modernY,-64,384);
            ChunkTranslator.LegacyChunk chunk=ChunkTranslator.decodeChunk(new DataInputStream(new ByteArrayInputStream(packet(modernY,8))),-64,384,base);
            int legacyY=modernY-base;
            check(legacyY>=0&&legacyY<128,"legacy height out of range");
            check((chunk.data[(0<<11)|(0<<7)|legacyY]&255)==2,"grass missing at modern Y="+modernY+" Alpha Y="+legacyY);
            check((chunk.data[(0<<11)|(0<<7)|((legacyY+1)%128)]&255)==0,"phantom extra blocks at modern Y="+modernY);
            System.out.println("PASS: modern Y="+modernY+" becomes Alpha Y="+legacyY+" via offset " +base);
        }
        System.out.println("ALL VERTICAL VIEWPORT TESTS PASSED");
    }
}
