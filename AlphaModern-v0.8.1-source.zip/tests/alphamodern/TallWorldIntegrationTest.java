package alphamodern;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.zip.Inflater;

/** End-to-end protocol-776 server fixture with high-altitude lobby and rich chat. */
public class TallWorldIntegrationTest {
    static void check(boolean value,String msg){if(!value)throw new AssertionError(msg);}
    static void server(ServerSocket listener) {
        try(Socket remote=listener.accept()) {
            remote.setSoTimeout(9000);Wire modern=new Wire(remote);
            Wire.Packet p=modern.recv();check(p.id==0,"handshake");
            check(Wire.var(p.data)==776,"protocol");Wire.str(p.data);p.data.readUnsignedShort();Wire.var(p.data);
            p=modern.recv();check(p.id==0,"login");Wire.str(p.data);p.data.readLong();p.data.readLong();
            modern.send(3,o->Wire.var(o,64));modern.compression(64);
            modern.send(2,o->{Wire.uuid(o,UUID.randomUUID());Wire.str(o,"Tester");Wire.var(o,0);Wire.uuid(o,UUID.randomUUID());});
            // Ignore additional brand and client info messages during the state changes.
            while((p=modern.recv()).id!=3){}
            modern.send(14,o->Wire.var(o,0));
            while((p=modern.recv()).id!=7){}
            modern.send(3,o->{});
            while((p=modern.recv()).id!=3){}
            modern.send(GameIds.CLIENTBOUND_LOGIN,o->{
                o.writeInt(293);o.writeBoolean(false);Wire.var(o,1);Wire.str(o,"minecraft:overworld");
                Wire.var(o,20);Wire.var(o,8);Wire.var(o,6);o.writeBoolean(false);o.writeBoolean(true);o.writeBoolean(false);
                Wire.var(o,0);Wire.str(o,"minecraft:overworld");
            });
            // On purpose: the chunk arrives BEFORE the first teleport/viewport decision.
            byte[] chunk=ViewportTest.packet(250,8);
            modern.send(GameIds.CLIENTBOUND_LEVEL_CHUNK_WITH_LIGHT,o->o.write(chunk));
            modern.send(GameIds.CLIENTBOUND_SYSTEM_CHAT,o->{TextComponentTest.sendStructured(o);o.writeBoolean(false);});
            modern.send(GameIds.CLIENTBOUND_PLAYER_POSITION,o->{Wire.var(o,3);o.writeDouble(64);o.writeDouble(250);o.writeDouble(-16);
                o.writeDouble(0);o.writeDouble(0);o.writeDouble(0);o.writeFloat(0);o.writeFloat(0);o.writeInt(0);});
            modern.send(GameIds.CLIENTBOUND_BLOCK_UPDATE,o->{o.writeLong(Wire.pos(64,252,-16));Wire.var(o,10);});
            // Update an individual block inside one (section) packet.
            long sectionPos=((long)4&0x3fffffL)<<42 | ((long)-1&0x3fffffL)<<20 | ((long)15&0xfffffL);
            modern.send(GameIds.CLIENTBOUND_SECTION_BLOCKS_UPDATE,o->{o.writeLong(sectionPos);Wire.var(o,1);
                Wire.writeVarLong(o,((long)8<<12) | 11); // local xyz=0,11,0: modernY=251
            });
            modern.send(GameIds.CLIENTBOUND_LIGHT_UPDATE,o->{
                Wire.var(o,4);Wire.var(o,-1);
                TerrainRegressionTest.writeMask(o,1L<<20); // section index 19 + 1
                TerrainRegressionTest.writeMask(o,0);
                TerrainRegressionTest.writeMask(o,0);
                TerrainRegressionTest.writeMask(o,0);
                Wire.var(o,1);Wire.var(o,2048);o.write(new byte[2048]); // zero sunlight, expect ambient floor
                Wire.var(o,0);
            });
            // Wait for movement before unloading the loaded chunk.
            boolean moved=false;
            for(int i=0;i<24;i++) {
                p=modern.recv();
                if(p.id==GameIds.SERVERBOUND_MOVE_PLAYER_POS_ROT) {
                    check(p.data.readDouble()==64,"client x");
                    double y=p.data.readDouble();check(y==251.0,"Y translation from Alpha back to server failed: "+y);
                    moved=true;break;
                }
            }
            check(moved,"no Alpha movement delivered");
            modern.send(GameIds.CLIENTBOUND_FORGET_LEVEL_CHUNK,o->o.writeLong((((long)-1)<<32) | 4L));
            // Give the Alpha reader time to process the unload packet.
            Thread.sleep(220);
        }catch(Exception e){throw new RuntimeException(e);}
    }
    static byte[] inflate(DataInputStream alpha) throws Exception {
        int x=alpha.readInt(),y=alpha.readShort(),z=alpha.readInt(),w=alpha.readUnsignedByte(),h=alpha.readUnsignedByte(),d=alpha.readUnsignedByte();
        check(x==64&&y==0&&z==-16&&w==15&&h==127&&d==15,"legacy chunk geometry incorrect");
        int len=alpha.readInt();check(len>0&&len<200000,"compressed chunk length");
        byte[] packed=new byte[len];alpha.readFully(packed);
        Inflater i=new Inflater();i.setInput(packed);byte[] raw=new byte[81920];int total=0;
        while(total<raw.length&&!i.finished()){int n=i.inflate(raw,total,raw.length-total);if(n==0)break;total+=n;}
        i.end();check(total==raw.length,"incomplete legacy chunk data");return raw;
    }
    static void client(int port) throws Exception {
        try(Socket legacy=new BridgeSocket(InetAddress.getLoopbackAddress(),port)){
            legacy.setSoTimeout(10000);DataOutputStream out=new DataOutputStream(legacy.getOutputStream());DataInputStream in=new DataInputStream(legacy.getInputStream());
            out.writeByte(1);out.writeInt(13);out.writeUTF("Tester");out.writeUTF("unused");out.flush();
            boolean world=false,chat=false,updated=false,section=false,light=false,unloaded=false,moved=false;
            int seenChunks=0;
            for(int n=0;n<20;n++) {
                int id=in.readUnsignedByte();
                if(id==1){check(in.readInt()==293,"entity id");in.readUTF();in.readUTF();}
                else if(id==3){String msg=in.readUTF();
                    if(msg.contains("TWITTER")){check(msg.contains("\u00a7bTWITTER"),"chat lost aqua formatting: "+msg);
                        check(!msg.contains("[26.2]")&&!msg.contains("click_event")&&!msg.contains("extra"),"raw NBT / prefix leak: "+msg);
                        chat=true;}}
                else if(id==50){int x=in.readInt(),z=in.readInt();boolean on=in.readBoolean();
                    check(x==4&&z==-1,"unload X/Z reversed: "+x+","+z);
                    if(!on){unloaded=true;break;}}
                else if(id==51){byte[] raw=inflate(in);seenChunks++;
                    if(seenChunks==1){check((raw[74]&255)==2,"terrain grass at modern Y250 did not project to Alpha Y74");world=true;}
                    else if(seenChunks==2){int sky=raw[ChunkTranslator.SKYLIGHT_OFFSET+(74>>1)]&255;
                        check((sky&15)>=8,"zero skylight was not floored for Alpha: "+sky);light=true;}
                }
                else if(id==13){in.readDouble();double y=in.readDouble();in.readDouble();in.readDouble();in.readFloat();in.readFloat();in.readBoolean();
                    check(y==74.0,"Alpha player Y should be 74 not "+y);
                    if(!moved){out.writeByte(13);out.writeDouble(64);out.writeDouble(75);out.writeDouble(76.62);out.writeDouble(-16);
                        out.writeFloat(0);out.writeFloat(0);out.writeBoolean(true);out.flush();moved=true;}}
                else if(id==53){int x=in.readInt(),y=in.readUnsignedByte(),z=in.readInt(),block=in.readUnsignedByte(),meta=in.readUnsignedByte();
                    check(x==64&&z==-16&&meta==0,"block update position metadata");
                    if(y==76){check(block==3,"single update dirt");updated=true;}
                    if(y==75){check(block==2,"section update grass");section=true;}}
                else if(id==255)throw new AssertionError("Server kicked Alpha: "+in.readUTF());
                else throw new AssertionError("Unexpected Alpha packet id " +id);
            }
            check(world&&chat&&updated&&section&&light&&unloaded&&moved,
                "Missing results: world="+world+", chat="+chat+", single="+updated+", section="+section+", light="+light+", unload="+unloaded+", movement="+moved);
            System.out.println("PASS: high Y250 world, early chunk buffering, NBT color chat without prefix, movement Y offset, modern block/light updates and packed chunk unload");
        }
    }
    public static void main(String[] args) throws Exception {
        Gateway.start();
        try(ServerSocket ss=new ServerSocket(0,1,InetAddress.getLoopbackAddress())) {
            ExecutorService workers=Executors.newSingleThreadExecutor();Future<?> work=workers.submit(()->server(ss));
            client(ss.getLocalPort());work.get(12,TimeUnit.SECONDS);workers.shutdownNow();
        }
        System.out.println("ALL TALL-WORLD INTEGRATION TESTS PASSED");
    }
}
