package alphamodern;

import java.io.*;
import java.util.*;

/** Realistic protocol-776 chunk section fixture, with the 26.2 fluid counter. */
public class TerrainRegressionTest {
    private static void check(boolean condition,String what) {if(!condition)throw new AssertionError(what);}
    private static void place(int[] section,int x,int y,int z,int paletteIndex) {
        section[(y<<8)|(z<<4)|x]=paletteIndex;
    }
    static byte[] buildSectionBlob(boolean extraByte,boolean global) throws Exception {
        ByteArrayOutputStream buf=new ByteArrayOutputStream();DataOutputStream o=new DataOutputStream(buf);
        for(int s=0;s<24;s++) {
            o.writeShort(s==8?2500:0); // nonEmptyBlockCount
            o.writeShort(s==8?122:0); // 26.2 fluidCount. MUST be consumed.
            if(s!=8) {
                o.writeByte(0);Wire.var(o,0); // air-only section
            } else {
                int[] palette={0,1,8,10,86,136,252,2294};
                int[] states=new int[4096];
                place(states,2,1,3,2); // grass at world y=65
                place(states,3,2,4,3); // dirt at y=66
                place(states,4,4,5,4); // water at y=68
                place(states,5,5,6,5); // log at y=69
                place(states,6,6,7,6); // leaves at y=70
                place(states,8,7,9,7); // orange wool at y=71
                place(states,10,8,11,1); // stone at y=72
                int bits=global?15:4;
                o.writeByte(bits);
                if(!global){Wire.var(o,palette.length);for(int p:palette)Wire.var(o,p);}
                int perWord=64/bits;
                for(int i=0;i<4096;i+=perWord) {
                    long packed=0;
                    for(int j=0;j<perWord&&i+j<4096;j++) {
                        int n=states[i+j];
                        packed|=((long)(global?palette[n]:n)) << (j*bits);
                    }
                    o.writeLong(packed);
                }
            }
            o.writeByte(0);Wire.var(o,0); // biome id 0: plains
        }
        if(extraByte)o.writeByte(0x88);
        return buf.toByteArray();
    }
    static void writeMask(DataOutputStream o,long flags) throws IOException {
        Wire.var(o,flags==0?0:1);if(flags!=0)o.writeLong(flags);
    }
    static byte[] fullPacket(boolean extraByte,boolean global) throws Exception {
        ByteArrayOutputStream buf=new ByteArrayOutputStream();DataOutputStream o=new DataOutputStream(buf);
        o.writeInt(2);o.writeInt(-3);
        Wire.var(o,1);Wire.var(o,0);Wire.var(o,1);o.writeLong(0L); // heightmap
        byte[] sections=buildSectionBlob(extraByte,global);
        Wire.var(o,sections.length);o.write(sections);
        Wire.var(o,1); // one named block entity
        o.writeByte(0x21);o.writeShort(70);Wire.var(o,1);
        o.writeByte(10); // unnamed root NBT compound
        o.writeByte(8);o.writeShort(3);o.writeBytes("foo"); // TAG_String named foo
        o.writeShort(3);o.writeBytes("bar");
        o.writeByte(0); // TAG_End
        long lightSection=1L<<9; // 0 is below-minY; section 8 => bit 9
        writeMask(o,lightSection);writeMask(o,lightSection);
        writeMask(o,0);writeMask(o,0);
        byte[] sky=new byte[2048];Arrays.fill(sky,(byte)0xff);
        int pos=(1<<8)|(3<<4)|2; // x=2,z=3,y=1 sky light 9
        sky[pos>>>1]=(byte)((sky[pos>>>1]&0xf0)|9);
        Wire.var(o,1);Wire.var(o,sky.length);o.write(sky);
        byte[] block=new byte[2048];
        pos=(7<<8)|(9<<4)|8; // x=8,z=9,y=7 emissive light 13
        block[pos>>>1]=(byte)((block[pos>>>1]&0xf0)|13);
        Wire.var(o,1);Wire.var(o,block.length);o.write(block);
        return buf.toByteArray();
    }
    static int id(byte[] old,int x,int y,int z){return old[(x<<11)|(z<<7)|y]&0xff;}
    static int nibble(byte[] old,int offset,int x,int y,int z){int n=(x<<11)|(z<<7)|y;return ((old[offset+(n>>1)]&255)>>>((n&1)*4))&15;}
    static void verifyValid(boolean global) throws Exception {
        ChunkTranslator.LegacyChunk chunk=ChunkTranslator.decodeChunk(new DataInputStream(new ByteArrayInputStream(fullPacket(false,global))),-64,384);
        byte[] out=chunk.data;
        check(out.length==81920,"Alpha packet data MUST be 81920 bytes");
        check(chunk.x==2&&chunk.z==-3,"chunk coordinates incorrect");
        check(id(out,2,65,3)==2,"grass should be grass, not stone");
        check(id(out,3,66,4)==3,"dirt should be dirt");
        check(id(out,4,68,5)==9,"water should be water");
        check(id(out,5,69,6)==17,"tree trunks should be wood");
        check(id(out,6,70,7)==18,"tree leaves should be leaves");
        check(id(out,8,71,9)==35,"orange wool id should be 35");
        check(nibble(out,ChunkTranslator.META_OFFSET,8,71,9)==1,"orange wool metadata should be 1");
        check(id(out,10,72,11)==1,"stone should be stone");
        check(id(out,2,86,3)==0,"above terrain must be AIR (no black ceiling)");
        check(id(out,6,31,7)==0,"lower empty sections must be air");
        check(nibble(out,ChunkTranslator.SKYLIGHT_OFFSET,2,65,3)==9,"skylight must have correct nibble ordering");
        check(nibble(out,ChunkTranslator.BLOCKLIGHT_OFFSET,8,71,9)==13,"block light must have correct nibble ordering");
        check(nibble(out,ChunkTranslator.SKYLIGHT_OFFSET,5,69,6)==15,"nonzero sunlight preserved");
        System.out.println("PASS: "+(global?"global":"indirect")+" palettes, fluidCount, blocks, metadata, modern light and old YZX geometry");
    }
    public static void main(String[] args) throws Exception {
        check(ChunkTranslator.toOld(0)==0,"air state");
        check(ChunkTranslator.toOld(8)==2,"grass state");
        check(ChunkTranslator.toOld(86)==9,"water state");
        check(ChunkTranslator.toOld(136)==17,"log state");
        check(ChunkTranslator.toOld(252)==18,"leaf state");
        check(ChunkTranslator.toOld(2294)==35 && ChunkTranslator.toMeta(2294)==1,"wool metadata");
        verifyValid(false);
        verifyValid(true);
        try {
            ChunkTranslator.decodeChunk(new DataInputStream(new ByteArrayInputStream(fullPacket(true,false))),-64,384);
            throw new AssertionError("extra undecoded bytes should be rejected");
        } catch(IOException expected) {
            check(expected.getMessage().contains("mismatch"),"Wrong strict-decoder error: "+expected);
        }
        System.out.println("PASS: invalid chunk payload rejected, preventing giant malformed terrain");
        System.out.println("ALL TERRAIN REGRESSION TESTS PASSED");
    }
}
