package alphamodern;

import java.util.*;
import java.util.concurrent.*;

/** Verifies Alpha GUI rendering and its newly intercepted text-entry keyboard handler. */
public final class AuthOverlayTest {
    static final class Font {}
    static class GuiBase {
        final List<String> text=new ArrayList<String>();
        public void a(Font font,String msg,int centerX,int y,int color){text.add(centerX+":"+y+":"+msg);}
        protected void a(int x1,int y1,int x2,int y2,int color){}
    }
    static class GuiScreen extends GuiBase {
        public int c=640,d=480;
        protected Font g=new Font();
    }
    static class Connecting extends GuiScreen {}
    private static void expect(boolean good,String msg){if(!good)throw new AssertionError(msg);}
    public static void main(String[] args) throws Exception {
        System.setProperty("alpha.modern.noBrowser","true");
        Connecting gameScreen=new Connecting();
        AuthOverlay.enableInGameInput();
        FutureTask<String> entered=new FutureTask<String>(() -> AuthOverlay.requestEmail(()->true));
        Thread t=new Thread(entered,"test-minecraft-typing");t.start();
        for(int i=0;i<100&&!(AuthOverlay.state!=null&&"Microsoft account email".equals(AuthOverlay.state.heading));i++)Thread.sleep(10);
        expect(AuthOverlay.state!=null&&"Microsoft account email".equals(AuthOverlay.state.heading),"No in-game email prompt");
        AuthOverlay.render(gameScreen);
        expect(gameScreen.text.toString().contains("Type the email"),"Email instructions weren't visible");
        // Invalid email should NOT allow proceeding to device-code issuance.
        for(char c:"not-an-email".toCharArray())AuthOverlay.key(c,0);
        AuthOverlay.key('\n',28);
        expect(!entered.isDone(),"Malformed email was accepted");
        expect(AuthOverlay.state.detail.contains("valid email"),"Email validation error missing");
        for(int i=0;i<12;i++)AuthOverlay.key('\b',14);
        for(char c:"wiktor@example.com".toCharArray())AuthOverlay.key(c,0);
        AuthOverlay.render(gameScreen);
        expect(gameScreen.text.toString().contains("wiktor@example.com"),"Typed email not drawn");
        AuthOverlay.key('\n',28);
        expect("wiktor@example.com".equals(entered.get(3,TimeUnit.SECONDS)),"Typed email wasn't submitted");
        expect(AuthOverlay.validEmail("user+mc@outlook.com"),"Plus alias rejected");
        expect(!AuthOverlay.validEmail("wrong-address"),"Malformed address accepted");
        AuthOverlay.code("https://microsoft.com/devicelogin","T5G9-N2YP",System.currentTimeMillis()+120000,"wiktor@example.com");
        gameScreen.text.clear();AuthOverlay.render(gameScreen);
        String rendered=gameScreen.text.toString();
        expect(rendered.contains("T5G9-N2YP")&&rendered.contains("microsoft.com/devicelogin")&&rendered.contains("Expires in"),
            "Device code wasn't drawn: "+rendered);
        expect(rendered.contains("wiktor@example.com"),"Email hint not shown on device-code screen");
        AuthOverlay.status("Signed in as TestAccount","Joining the multiplayer server");
        gameScreen.text.clear();AuthOverlay.render(gameScreen);
        expect(gameScreen.text.toString().contains("Signed in as TestAccount"),"Success UI didn't render");
        AuthOverlay.clear();gameScreen.text.clear();AuthOverlay.render(gameScreen);
        expect(gameScreen.text.isEmpty(),"Auth overlay not removed after login");
        System.out.println("PASS: keyboard email entry, validation, account hint, device code, expiry and success via Alpha GUI");
    }
}
